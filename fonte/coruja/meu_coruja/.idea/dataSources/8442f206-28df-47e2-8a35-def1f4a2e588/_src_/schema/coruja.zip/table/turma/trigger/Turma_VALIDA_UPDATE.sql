CREATE TRIGGER Turma_VALIDA_UPDATE
BEFORE UPDATE ON turma
FOR EACH ROW
  begin
    declare cont INT;
    declare var_id_turma INT;
    declare CUR_INSCR_TURMA_FINALIZADA cursor for select count(*) from Inscricao i
        inner join Turma t on t.idTurma = i.idTurma
        where t.idTurma = var_id_turma and
            i.situacaoInscricao not in ('NEG','AP','RM','RF','ID', 'EXC');
    declare CUR_INSCR_TURMA_CONFIRMADA cursor for select count(*) from Inscricao i
        inner join Turma t on t.idTurma = i.idTurma
        where t.idTurma = var_id_turma and
            i.situacaoInscricao not in ('NEG','CUR','AP','RF','RM','ID', 'EXC');
	select new.idTurma into var_id_turma;

    -- Se campo tipoSituacaoTurma for FINALIZADA, nenhuma inscricao
    -- pode estar diferente de AP,RM,RF, NEG ou ID
    if new.tipoSituacaoTurma='FINALIZADA' then
        open CUR_INSCR_TURMA_FINALIZADA;
        fetch CUR_INSCR_TURMA_FINALIZADA into cont;
        close CUR_INSCR_TURMA_FINALIZADA;
        if cont <> 0 then
            call fail('A turma nao pode ser finalizada devido a pendencias.');
        end if;
    end if;

    -- Se campo tipoSituacaoTurma for CONFIRMADA, nenhuma inscricao
    -- pode estar diferente de NEG, ID, CUR
    if new.tipoSituacaoTurma='CONFIRMADA' and old.tipoSituacaoTurma<>'CONFIRMADA'  then
        open CUR_INSCR_TURMA_CONFIRMADA;
        fetch CUR_INSCR_TURMA_CONFIRMADA into cont;
        close CUR_INSCR_TURMA_CONFIRMADA;
        if cont <> 0 then
            call fail('A turma nao pode ser confirmada devido a pendencias.');
        end if;
    end if;
    
    -- Se campo tipoSituacaoTurma for CONFIRMADA ou FINALIZADA,
    -- o campo matriculaProfessor NÃO pode ser nulo
    if new.tipoSituacaoTurma='CONFIRMADA' or new.tipoSituacaoTurma='FINALIZADA' then
        if new.matriculaProfessor is null then
            call fail('O professor da turma deve ser especificado.');
        end if;
    end if;
    
end;
