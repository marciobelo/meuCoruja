CREATE TRIGGER MatriculaAluno_VALIDA_INSERT
BEFORE INSERT ON matriculaaluno
FOR EACH ROW
  begin
	-- Campo matriculaAluno só deve aceitar dígitos numéricos
	if new.matriculaAluno is not null then
		if new.matriculaAluno REGEXP '[^0-9]+' then
			call fail('Campo matricula do aluno esta incorreto.');
		end if;
	end if;

end;
