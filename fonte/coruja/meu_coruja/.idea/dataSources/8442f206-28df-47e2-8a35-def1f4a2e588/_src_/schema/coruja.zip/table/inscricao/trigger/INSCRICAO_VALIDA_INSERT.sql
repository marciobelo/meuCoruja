CREATE TRIGGER INSCRICAO_VALIDA_INSERT
BEFORE INSERT ON inscricao
FOR EACH ROW
  begin
    declare cont INT;
    declare var_id_turma INT;
	declare var_matricula_aluno VARCHAR(15);
    declare CUR_INSCR_TURMA_PLANEJADA cursor for select count(*) from Turma t 
        where t.idTurma = var_id_turma and t.tipoSituacaoTurma='PLANEJADA';
    declare CUR_MATR_NAO_CURSANDO_E_TRANCADO cursor for select count(*) from MatriculaAluno ma 
        where ma.matriculaAluno = var_matricula_aluno and
		ma.situacaoMatricula<>'CURSANDO' and ma.situacaoMatricula<>'TRANCADO';
	select new.idTurma into var_id_turma;
	select new.matriculaAluno into var_matricula_aluno;
    	
	-- Verifica que se o campo Inscricao.situacaoInscricao estiver com os valores 'AP', 'RM' ou 'RF',
	-- o campo mediaFinal e totalFaltas devem obrigatoriamente estar preenchidos	
	if new.situacaoInscricao in ('AP','RM','RF') and
		(new.mediaFinal is null or new.totalFaltas is null) then
		call fail('Os campos media e total de faltas devem estar preenchidos.');
	end if;

	-- Verifica que se o campo Inscricao.mediaFinal, quando estiver preenchido, tem valor entre 0 e 10
	if new.mediaFinal is not null then
		if not (new.mediaFinal >= 0 and new.mediaFinal <= 10) then
			call fail('O campo media final deve ter valor entre 0 e 10.');
		end if;
	end if;
    
    -- Nenhuma inscrição pode ser feita em turma PLANEJADA
    open CUR_INSCR_TURMA_PLANEJADA;
    fetch CUR_INSCR_TURMA_PLANEJADA into cont;
    close CUR_INSCR_TURMA_PLANEJADA;
    if cont <> 0 then
        call fail('Inscricao nao pode ser feita em turma PLANEJADA.');
    end if;
	
    -- A matricula do aluno não está em situação CURSANDO nem TRANCADO, portanto não pode ser inscrito em turma
    open CUR_MATR_NAO_CURSANDO_E_TRANCADO;
    fetch CUR_MATR_NAO_CURSANDO_E_TRANCADO into cont;
    close CUR_MATR_NAO_CURSANDO_E_TRANCADO;
    if cont > 0 then
        call fail('A matricula desse aluno nao consta como cursando nem com trancado.');
    end if;
    
end;
