CREATE TRIGGER EventoPeriodoLetivo_VALIDA_UPDATE
BEFORE UPDATE ON eventoperiodoletivo
FOR EACH ROW
  begin
    declare cont INT;
    declare var_seq_evento INT;
	declare var_id_periodo_letivo INT;
	declare var_tipo_evento VARCHAR(120);
	declare var_data_evento DATETIME;
    declare CUR_TIPO_EVENTO_UNICO cursor for select count(*) from  EventoPeriodoLetivo epl
        where epl.idPeriodoLetivo = var_id_periodo_letivo and
			epl.tipoEvento = var_tipo_evento and 
			epl.seqEvento <> var_seq_evento;
    declare CUR_EVENTO_DENTRO_PERIODO cursor for select count(*) from PeriodoLetivo pl
        where pl.idPeriodoLetivo = var_id_periodo_letivo and
			(var_data_evento < pl.dataInicio or var_data_evento > pl.dataFim);		
	select new.seqEvento into var_seq_evento;
	select new.idPeriodoLetivo into var_id_periodo_letivo;
	select new.tipoEvento into var_tipo_evento;
	select new.`data` into var_data_evento;
	
	-- Valida que se o campo tipoEvento foi preenchido, existe apenas um para um dado período letivo
	if (new.tipoEvento is not NULL) then
        open CUR_TIPO_EVENTO_UNICO;
        fetch CUR_TIPO_EVENTO_UNICO into cont;
        close CUR_TIPO_EVENTO_UNICO;
        if cont > 0 then
            call fail('So pode haver um marco em um dado periodo letivo.');
        end if;
	end if;
	
	-- Valida que a data do evento está dentro do período letivo
	open CUR_EVENTO_DENTRO_PERIODO;
	fetch CUR_EVENTO_DENTRO_PERIODO into cont;
	close CUR_EVENTO_DENTRO_PERIODO;
	if cont > 0 then
		call fail('Data do evento deve estar dentro do periodo letivo.');
	end if;		
	
end;
