CREATE TRIGGER INSCRICAO_VALIDA_UPDATE
BEFORE UPDATE ON inscricao
FOR EACH ROW
  begin
	-- Verifica que se o campo Inscricao.situacaoInscricao estiver com os valores 'AP', 'RM' ou 'RF',
	-- o campo mediaFinal e totalFaltas devem obrigatoriamente estar preenchidos	
	if new.situacaoInscricao in ('AP','RM','RF') and
		(new.mediaFinal is null or new.totalFaltas is null) then
		call fail('Os campos media e total de faltas devem estar preenchidos.');
	end if;
	
	-- Verifica que se o campo Inscricao.mediaFinal, quando estiver preenchido, tem valor entre 0 e 10
	if new.mediaFinal is not null then
		if not (new.mediaFinal >= 0 and new.mediaFinal <= 10) then
			call fail('O campo media final deve ter valor entre 0 e 10.');
		end if;
	end if;
end;
