CREATE PROCEDURE fail(IN `_Message` VARCHAR(128))
  BEGIN
  INSERT INTO Error (Message) VALUES (_Message);
  INSERT INTO Error (Message) VALUES (_Message);
END;
