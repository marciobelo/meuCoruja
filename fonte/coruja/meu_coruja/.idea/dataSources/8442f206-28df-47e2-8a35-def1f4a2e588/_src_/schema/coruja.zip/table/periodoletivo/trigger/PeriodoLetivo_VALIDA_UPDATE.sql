CREATE TRIGGER PeriodoLetivo_VALIDA_UPDATE
BEFORE UPDATE ON periodoletivo
FOR EACH ROW
  begin
    declare cont INT;
	declare var_id_periodo_letivo INT;
	declare var_data_inicio DATE;
	declare var_data_fim DATE;
	declare CUR_ABRANGE_EVENTOS cursor for select count(*) from EventoPeriodoLetivo epl
		where epl.idPeriodoLetivo = var_id_periodo_letivo and
			(epl.data  < var_data_inicio or epl.data > var_data_fim);
	select new.idPeriodoLetivo into var_id_periodo_letivo;
	select new.dataInicio into var_data_inicio;
	select new.dataFim into var_data_fim;
	
	-- Valida que a data do evento está dentro do período letivo
	open CUR_ABRANGE_EVENTOS;
	fetch CUR_ABRANGE_EVENTOS into cont;
	close CUR_ABRANGE_EVENTOS;
	if cont > 0 then
		call fail('Periodo letivo deve abranger todos os eventos dele.');
	end if;		
	
end;
