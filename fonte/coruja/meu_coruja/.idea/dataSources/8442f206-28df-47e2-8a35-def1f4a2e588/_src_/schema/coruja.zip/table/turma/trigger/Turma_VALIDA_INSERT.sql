CREATE TRIGGER Turma_VALIDA_INSERT
BEFORE INSERT ON turma
FOR EACH ROW
  begin
    -- Campo tipoSituacaoTurma deve iniciar como PLANEJADA
    if new.tipoSituacaoTurma<>'PLANEJADA' then
        call fail('A turma recem criada deve ser em situacao PLANEJADA.');
    end if;
end;
