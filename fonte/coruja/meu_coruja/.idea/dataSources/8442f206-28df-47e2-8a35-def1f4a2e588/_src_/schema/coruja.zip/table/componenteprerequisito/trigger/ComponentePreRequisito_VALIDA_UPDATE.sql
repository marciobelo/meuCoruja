CREATE TRIGGER ComponentePreRequisito_VALIDA_UPDATE
BEFORE UPDATE ON componenteprerequisito
FOR EACH ROW
  begin
	-- Campos siglaCurso e idMatriz devem ser iguais aos campos siglaCursoPreRequisito e idMatrizPreRequisito
	if (new.siglaCurso <> new.siglaCursoPreRequisito) or
		(new.idMatriz <> new.idMatrizPreRequisito) then
		call fail('Pre-requisitos so podem ser estabelecidos entre componentes do mesmo curso/matriz');
	end if;
end;
