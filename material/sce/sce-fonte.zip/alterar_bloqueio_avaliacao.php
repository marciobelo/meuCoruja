<?php
    require_once ("../includes/comum.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador") {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }

    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_evento.php");

    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $AtividadeMySqlDAO->updateBloqueado($_GET["id"], $_GET["bloqueado"]);
    $atividade = $AtividadeMySqlDAO->load($_GET["id"]);
    $EventoMySqlDAO = new EventoMySqlDAO;
    $evento = $EventoMySqlDAO->load($atividade->getIdEvento());
    $idEvento = $evento->getId();

    header("Location: detalhe_evento.php?id=$idEvento&pag=1");
?>
