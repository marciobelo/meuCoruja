<?php
    require_once ("../includes/comum.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador") {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ($BASE_DIR . "/sce/includes/require_aspecto.php");

    $AspectoMySqlDAO = new AspectoMySqlDao;
    $aspecto = $AspectoMySqlDAO->load($_GET["id"]);
    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <h4>Altera��o do aspecto <?php echo $aspecto->getNome(); ?></h4>
            <form action="proc_alterar_aspecto.php" method="post" name="alteracao_aspecto">
                <input name="id" type="hidden" value=<?php echo $_GET["id"]; ?> />
                <input name="nome" type="text" value=<?php echo $aspecto->getNome() ?> />
                <input type="submit" value="Cadastrar" name="enviar" />
                <input type="button" value="Voltar" onclick="window.location='manter_aspecto.php'" />
            </form>
            <?php
                include($BASE_DIR . "/sce/includes/legenda.html");
            ?>
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
        ?>
</body>
</html>
