<?php 
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");

    $PessoaMySqlDAO = new PessoaMySqlDAO();
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
    $AtividadeMySqlDAO = new AtividadeMySqlDAO();
    $avaliacoes = $AvaliacaoMySqlDAO->queryByIdAtividade($_GET["id"]);
    $atividade = $AtividadeMySqlDAO->load($_GET["id"]);
    
    $idEvento = $atividade->getIdEvento();
    
    include($BASE_DIR . "/sce/includes/header.html");
?>

<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                $nomeAtividade = $atividade->getNome();
                $horaInicial = $atividade->getHoraInicial();
                $horaFinal = $atividade->getHoraFinal();
                $data = date("d-m-Y", strtotime($atividade->getData()));
                echo "<h3>Avalia��es da atividade $nomeAtividade - $data - $horaInicial/$horaFinal</h3>";
                echo "<form name='form' method='POST' action='proc_validar_avaliacao.php'>";
                $id = $_GET["id"];
                echo "<input type='hidden' value='$id' name='idAvaliacao' />";
                foreach ($avaliacoes as $avaliacao)
                {
                    $aluno = $PessoaMySqlDAO->load($avaliacao->getIdPessoa());
                    if ($avaliacao->getStatus())
                    {
                        echo "<input type='checkbox' name='avaliacao' disabled></input>";
                    } else
                    {
                        $idAvaliacao = $avaliacao->getId();
                        echo "<input type='checkbox' name='avaliacao[]' value='$idAvaliacao'></input>";
                    }
                    $idAvaliacao = $avaliacao->getId();
                    $idAtividade = $GET["id"];
                    echo "<a href=ver_avaliacao.php?id=$idAvaliacao>" . $aluno->getNome() . "</a><br />";
                }
                echo "<br />";
                echo "<br />";
                echo "<input type='submit' value='Validar'></input>";
                echo "<input type='reset' value='Limpar'></input>";
                echo "<input type='button' value='Voltar'"
                     . " onclick='window.location=\"detalhe_evento.php?id=$idEvento&pag=1\"' />";
                echo "<br />";
                echo "<br />";
                echo "</form>";
        ?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>