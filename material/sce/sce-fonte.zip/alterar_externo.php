<?php
    require_once ("../includes/comum.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador") {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_externo.php");

    $ExternoMySqlDAO = new ExternoMySqlDao;
    $externo = $ExternoMySqlDAO->load($_GET["id"]);
    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <h4>Altera��o do externo <?php echo $externo->getNome(); ?></h4>
            <form action="proc_alterar_externo.php" method="post" name="alteracao_externo">
                <input name="id" type="hidden" value=<?php echo $_GET["id"]; ?> />
                Nome: * <input type="text" name="nome" value=<?php echo '"' . $externo->getNome() . '"' ?> />
                Institui��o: * <input type="text" name="instituicao" value=<?php echo '"' . $externo->getInstituicao() . '"' ?> />
                Telefone: * <input type="text" name="telefone" value=<?php echo '"' . $externo->getTelefone() . '"' ?> />
                E-mail: * <input type="text" name="email" value=<?php echo '"' . $externo->getEmail() . '"' ?> />
                <input type='submit' value='Cadastrar' name='submit' />
        <input type="button" value="Voltar" onclick="window.location='manter_externos.php?pag=1'" />
            </form>
<?php
    include($BASE_DIR . "/sce/includes/legenda.html");
?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>
