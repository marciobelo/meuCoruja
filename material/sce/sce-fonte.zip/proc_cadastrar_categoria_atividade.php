<?php
    require_once ("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_categoriaatividade.php");

    $CategoriaAtividade = new CategoriaAtividade();
    if (!$_POST["nome"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        header("Location: manter_categoriaatividade.php");
        break;
    }
    else
    {
        $CategoriaAtividade->setNome( $_POST["nome"] );
        $CategoriaatividadeMySqlDAO = new CategoriaatividadeMySqlDAO();
        $CategoriaAtividade = $CategoriaatividadeMySqlDAO->insert( $CategoriaAtividade );
    }

    if ($CategoriaAtividade==0)
    {
        trigger_error(mysql_error());
    }
    else
    {
        $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
        header("Location: manter_categoriaatividade.php");
    }
?>