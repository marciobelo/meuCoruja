<?php
    require_once ("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }

    require_once($BASE_DIR . "/sce/includes/require_categoriaatividade.php");
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");

    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDao;
    $categoriasatividade = $CategoriaAtividadeMySqlDAO->queryAll();
    
    $AtividadeMySqlDAO = new AtividadeMySqlDao;

    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
?>
        <div id="mainContent">
            <h4>Categorias de atividade</h4>
            <?php
                if($categoriasatividade)
                {
            ?>
            <table>
                <tr>
                    <th>Nome</th>
                    <th>Alterar</th>
                    <th>Excluir</th>
                </tr>
<?php
    foreach ($categoriasatividade as $categoriaatividade)
    {
        echo "<tr>";
        echo "<td>" . $categoriaatividade->getNome() . "</td>";
        $id = $categoriaatividade->getId();
        echo "<td> <a href='alterar_categoriaatividade.php?id=$id'>Clique</a> </td>";
        $deletavel = $AtividadeMySqlDAO->queryByIdCategoriaAtividade($id);
        if (!empty($deletavel)) {
            echo "<td> <a href='excluir_categoriaatividade.php?id=$id' "
                 . "onclick='return confirm(\"Deseja realmente excluir a categoria? As atividades vinculadas tamb�m "
                 . "ser�o exclu�das.\")'>Clique</a> </td>";
        }
        else
        {
            echo "<td> <a href='excluir_categoriaatividade.php?id=$id' "
                 . "onclick='return confirm(\"Deseja realmente excluir a categoria?\")'>Clique</a> </td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    echo "<br>";
    }
    else
    {
        echo "N�o h� categorias cadastradas! Cadastre uma categoria usando o formul�rio abaixo.";
    }
?>
                <form action="proc_cadastrar_categoria_atividade.php" method="post" name="cadastro_categoria_atividade">
                    Nome: (*) <input name="nome" type="text" />
                    <input type="submit" value="Cadastrar" name="enviar" />
                    <input type="button" value="Voltar" onclick="window.location='index.php'" />
                </form>
        <?php
            include($BASE_DIR . "/sce/includes/legenda.html");
        ?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>