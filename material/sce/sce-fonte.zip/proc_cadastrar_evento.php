<?php 
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_evento.php");

    $Evento = new Evento();
    if (!$_POST["nome"] or !$_POST["dtInicial"] or !$_POST["dtFinal"]
            or !$_POST["categoria"] or !$_POST["coordenador"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        $_SESSION["eventoSession"] = $_POST;
        header("Location: manter_evento.php?pag=1");
        break;
    }

    $_POST["dtInicial"] = str_replace("/", "-", $_POST["dtInicial"]);
    $_POST["dtFinal"] = str_replace("/", "-", $_POST["dtFinal"]);
    
    if (strtotime($_POST["dtInicial"]) > strtotime($_POST["dtFinal"]))
    {
        $_SESSION["erro"] = "A data final deve ser maior que a data inicial";
        $_POST["dtInicial"] = str_replace("-", "/", $_POST["dtInicial"]);
        $_POST["dtFinal"] = str_replace("-", "/", $_POST["dtFinal"]);
        $_SESSION["eventoSession"] = $_POST;
        header("Location: manter_evento.php?pag=1");
        break;
    }
    else
    {
        $Evento->setNome( $_POST["nome"] );
        $Evento->setDtInicial( date("Y-m-d",strtotime($_POST["dtInicial"])) );
        $Evento->setDtFinal( date("Y-m-d", strtotime($_POST["dtFinal"])) );
        $Evento->setIdCategoriaEvento( $_POST["categoria"] );
        $Evento->setIdTema( $_POST["tema"] );
        $Evento->setIdPessoa( $_POST["coordenador"] );
        $EventoMySqlDAO = new EventoMySqlDAO();
        $Evento = $EventoMySqlDAO->insert( $Evento );
        if ($Evento==0)
        {
            trigger_error(mysql_error(), E_USER_ERROR);
        }
        else
        {
            $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
            header("Location: detalhe_evento.php?id=$Evento&pag=1");
        }
    }
?>