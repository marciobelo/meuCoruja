<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");

    $Atividade = new Atividade();
    $AtividadeMySqlDAO = new AtividadeMySqlDAO();
    $Atividade = $AtividadeMySqlDAO->load($_POST["id"]);
    if (!$_POST["nome"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        $id = $_POST["id"];
        $evento = $_POST["evento"];
        header("Location: alterar_atividade.php?id=$id&evento=$evento");
        break;
    }
    else
    {
        if ($_POST["seletorPalestrante"] == "Interno")
        {
            $_POST["tipoPalestrante"] = "I";
            $_POST["palestrante"] = $_POST["interno"];
            unset($_POST["interno"]);
        }
        else
        {
            $_POST["tipoPalestrante"] = "E";
            $_POST["palestrante"] = $_POST["externo"];
            unset($_POST["externo"]);
        }
        if ($_POST["palestrante"] == '')
        {
            $_POST["palestrante"] = "NULL";
        }
        $Atividade->setNome( $_POST["nome"] );
        $Atividade->setData( date("Y-m-d", strtotime($_POST["data"])) );
        $Atividade->setHoraInicial( $_POST["horaInicial"] );
        $Atividade->setHoraFinal( $_POST["horaFinal"] );
        $Atividade->setIdCategoriaAtividade( $_POST["categoria"] );
        $Atividade->setIdPalestrante( $_POST["palestrante"] );
        $Atividade->setIdEspaco( $_POST["espaco"] );
        $Atividade->setCustomEspaco ( $_POST["customEspaco"] );
        $Atividade->setTipoPalestrante ( $_POST["tipoPalestrante"] );
        $Atividade = $AtividadeMySqlDAO->update( $Atividade );
    }

    $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
    $evento = $_POST["evento"];
    header("Location: detalhe_evento.php?id=$evento&pag=1");
?>
