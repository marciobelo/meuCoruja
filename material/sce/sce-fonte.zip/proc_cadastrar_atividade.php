<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once($BASE_DIR . "/sce/includes/require_evento.php");

    $Evento = $_POST["evento"];
    if (!$_POST["nome"] or !$_POST["data"] or !$_POST["horaInicial"] or !$_POST["horaFinal"] or !$_POST["horaExtensao"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        $_SESSION["atividadeSession"] = $_POST;
        header("Location: detalhe_evento.php?id=$Evento&pag=1");
        break;
    }
    elseif ($_POST["horaInicial"] >= $_POST["horaFinal"])
    {
        $_SESSION["erro"] = "Hora inicial deve ser menor que a final";
        $_SESSION["atividadeSession"] = $_POST;
        header("Location: detalhe_evento.php?id=$Evento&pag=1");
        break;
    }
    else
    {
        if ($_POST["seletorPalestrante"] == "Interno")
        {
            $_POST["tipoPalestrante"] = "I";
            $_POST["palestrante"] = $_POST["interno"];
            unset($_POST["interno"]);
            unset($_POST["seletorPalestrante"]);
        }
        else
        {
            $_POST["tipoPalestrante"] = "E";
            $_POST["palestrante"] = $_POST["externo"];
            unset($_POST["externo"]);
            unset($_POST["seletorPalestrante"]);
        }
        $EventoMySqlDAO = new EventoMySqlDAO();
        $evento = $EventoMySqlDAO->load($Evento);
        $dtInicial = date("d-m-Y", strtotime($evento->getDtInicial()));
        $dtFinal = date("d-m-Y", strtotime($evento->getDtFinal()));
        $dtInicial = explode("-", $dtInicial);
        $dtFinal = explode("-", $dtFinal);
        $dtAtividade = explode("/", $_POST["data"]);
        $dtInicialEvento = mktime(0, 0, 0, $dtInicial[1], $dtInicial[0], $dtInicial[2]);
        $dtFinalEvento = mktime(0, 0, 0, $dtFinal[1], $dtFinal[0], $dtFinal[2]);
        $dtAtividade = mktime(0, 0, 0, $dtAtividade[1], $dtAtividade[0], $dtAtividade[2]);
        if ($dtAtividade < $dtInicialEvento or $dtAtividade > $dtFinalEvento )
        {
            $_SESSION["erro"] = "Data deve estar no limite do evento";
            $_SESSION["atividadeSession"] = $_POST;
            header("Location: detalhe_evento.php?id=$Evento&pag=1");
            break;
        }
        $Atividade = new Atividade();
        $Atividade->setNome( $_POST["nome"] );
        $_POST["data"] = str_replace("/", "-", $_POST["data"]);
        $Atividade->setData( date("Y-m-d",strtotime($_POST["data"])) );
        $Atividade->setHoraInicial( $_POST["horaInicial"] . ":00");
        $Atividade->setHoraFinal( $_POST["horaFinal"] . ":00");
        $Atividade->setHoraExtensao( (int)$_POST["horaExtensao"]);
        $Atividade->setIdCategoriaAtividade( $_POST["categoria"] );
        $Atividade->setIdEvento( $_POST["evento"] );
        $Atividade->setIdPalestrante( $_POST["palestrante"] );
        $Atividade->setTipoPalestrante( $_POST["tipoPalestrante"] );
        $Atividade->setIdEspaco( $_POST["espaco"] );
        $Atividade->setCustomEspaco( $_POST["customEspaco"] );
        $AtividadeMySqlDAO = new AtividadeMySqlDAO();
        $atividades = $AtividadeMySqlDAO->querybyIdEventoOrderBy($Evento, "data, horaInicial DESC");
        foreach ($atividades as $atividade)
        {
            if ($Atividade->getIdEspaco() == $atividade->getIdEspaco())
            {
                if ($Atividade->getData() == $atividade->getData())
                {
                    if ($Atividade->getHoraInicial() < $atividade->getHoraInicial())
                    {
                        if ($Atividade->getHoraFinal() >= $atividade->getHoraFinal())
                        {
                            $_SESSION["erro"] = "Cadastro conflitante com outra atividade";
                            $_POST["data"] = str_replace("-", "/", $_POST["data"]);
                            $_SESSION["atividadeSession"] = $_POST;
                            header("Location: detalhe_evento.php?id=$Evento&pag=1");
                            break;
                        }
                    }
                    elseif ($Atividade->getHoraInicial() == $atividade->getHoraInicial())
                    {
                        $_SESSION["erro"] = "Cadastro conflitante com outra atividade";
                        $_POST["data"] = str_replace("-", "/", $_POST["data"]);
                        $_SESSION["atividadeSession"] = $_POST;
                        header("Location: detalhe_evento.php?id=$Evento&pag=1");
                        break;
                    }
                    else
                    {
                        if ($Atividade->getHoraInicial() <= $atividade->getHoraFinal())
                        {
                            $_SESSION["erro"] = "Cadastro conflitante com outra atividade";
                            $_POST["data"] = str_replace("-", "/", $_POST["data"]);
                            $_SESSION["atividadeSession"] = $_POST;
                            header("Location: detalhe_evento.php?id=$Evento&pag=1");
                            break;
                        }
                    }
                }
            }
        }
        if (!$_SESSION["erro"]) {
            $Atividade = $AtividadeMySqlDAO->insert( $Atividade );
        }
    }

    if (!$Atividade)
    {
        trigger_error(mysql_error(), E_USER_ERROR);
    }
    else
    {
        $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
        header("Location: detalhe_evento.php?id=$Evento&pag=1");
    }

?>