<?php 
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_categoriaatividade.php");

    $id = $_GET["id"];
    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDao;
    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDao;
    $AvaliacaoAspectoMySqlDAO = new AvaliacaoAspectoMySqlDao;
    $atividades = $AtividadeMySqlDAO->queryByIdCategoriaAtividade($id);
    foreach ($atividades as $atividade)
    {
        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdAtividade($atividade->getId());
        foreach ($avaliacoes as $avaliacao)
        {
            $avaliacoesaspecto = $AvaliacaoAspectoMySqlDAO->queryByIdAvaliacao($avaliacao->getId());
            foreach ($avaliacoesaspecto as $avaliacaoaspecto)
            {
                $AvaliacaoAspectoMySqlDAO->delete($avaliacaoaspecto->getId());
            }
            $AvaliacaoMySqlDAO->delete($avaliacao->getId());
        }
        $AtividadeMySqlDAO->delete($atividade->getId());
    }
    $CategoriaAtividade = $CategoriaAtividadeMySqlDAO->delete($id);

    if($CategoriaAtividade == 0)
    {
        trigger_error(mysql_error(), E_USER_ERROR);
    }
    else
    {
        $_SESSION["sucesso"] = "Exclus�o efetuada com sucesso";
        header("Location: manter_categoriaatividade.php");
    }
?>