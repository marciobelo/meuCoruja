<?php 
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    require_once($BASE_DIR . "/sce/includes/require_matriculaaluno.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");
	require_once($BASE_DIR . "/sce/includes/require_evento.php");
	require_once($BASE_DIR . "/sce/includes/require_categoriaevento.php");
	require_once($BASE_DIR . "/sce/includes/require_tema.php");
    include($BASE_DIR . "/sce/includes/header.html");

    if ($permissao == "professor")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
    }

    if ($permissao == "aluno")
    {

        $MatriculaAlunoMySqlDAO = new MatriculaAlunoMySqlDAO();
        $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
        $AtividadeMySqlDAO = new AtividadeMySqlDAO();
		$EventoMySqlDAO = new EventoMySqlDAO();
		$CategoriaEventoMySqlDAO = new CategoriaEventoMySqlDAO();
		$TemaMySqlDAO = new TemaMySqlDAO();

        $matriculaAluno = $MatriculaAlunoMySqlDAO->queryByIdPessoa($usuario->getIdPessoa());
        $matriculaAluno = $matriculaAluno[0];
        if ($matriculaAluno)
        {
            $matriculaAluno = $matriculaAluno->getMatriculaAluno();
        } else
        {
            $matriculaAluno = "";
        }

        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdPessoa($usuario->getIdPessoa());
        $eventos = array();
        foreach ($avaliacoes as $avaliacao)
        {
            if ($avaliacao->getStatus())
            {
                $atividade = $AtividadeMySqlDAO->load($avaliacao->getIdAtividade());
                if (!in_array($atividade->getIdEvento(), $eventos)) {
                    $eventos[] = $atividade->getIdEvento();
                }
                $horas[$atividade->getIdEvento()] += $atividade->getHoraExtensao();
            }
        }
    }

?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
        <?php
            if ($permissao == "coordenador")
            {
        ?>
            <h4>Consulta de horas de extens&atilde;o</h4>
            <form action="proc_obter_extensao_matricula_coordenador.php" method="GET">
                Matricula do aluno: (*) <input type="text" name="matricula" />
                <input type="submit" value="OK" />
                <input type='button' value='Voltar' onclick='window.location="index.php"' />
                <?php 
                    include($BASE_DIR . "/sce/includes/legenda.html");
                ?>
            </form>
                <?php
                    } 
                    elseif ($permissao == "aluno")
                    {
						if (count($eventos) > 0)
						{
							echo "<h3>Lista de hora de extens�o por evento</h3>";
							echo "<table class='tabDados'>";
							echo "<tr>";
							echo "<th>Evento</th>";
							echo "<th>Horas de extens�o</th>";
							echo "<th>Datas</th>";
							echo "<th>Tema</th>";
							echo "<th>Coordenador</th>";
							echo "</tr>";
							foreach ($eventos as $evento) 
							{
								$objEvento = $EventoMySqlDAO->load($evento);
								$nomeEvento = $objEvento->getNome();
								echo "<tr>";
								echo "<td><a href='obter_extensao_evento.php?id=$evento'>$nomeEvento</a></td>";
								echo "<td>$horas[$evento]</td>";
								echo "<td>" . date("d/m/Y",strtotime($objEvento->getDtInicial())) . " - "
								. date("d/m/Y",strtotime($objEvento->getDtFinal())) . "</td>";
								$tema = $TemaMySqlDAO->load($objEvento->getIdTema());
								if ($tema->getNome() == NULL) {
									$tema->setNome('----');
								}
								echo "<td>" . $tema->getNome() . "</td>";
								$pessoa = $PessoaMySqlDAO->load($objEvento->getIdPessoa());
								echo "<td>" . $pessoa->getNome() . "</td>";
								echo "</tr>";
							}
							echo "</table>";
							echo "<br /><br />";
						}
						else
						{
							echo "Voc� n�o possui horas de extens�o";
						}
                    }
                ?>
<?php

?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>