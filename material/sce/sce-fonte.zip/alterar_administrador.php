<?php
    require_once ("../includes/comum.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador") {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }

    require_once ($BASE_DIR . "/sce/includes/require_administrador.php");

    $AdministradorMySqlDAO = new AdministradorMySqlDao;
    $bolSucesso = $AdministradorMySqlDAO->toggleAdm($_GET["id"]);

    if ($bolSucesso)
    {
    	$_SESSION["sucesso"] = "Altera��o efetuada com sucesso";
    }
    else
    {
    	trigger_error(mysql_error());
    }

    header("Location: manter_administradores.php?pag=1");
?>
