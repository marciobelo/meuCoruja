<?php
    require_once("../includes.comum.php");
    
    /**
     * Classe ArrayList
     * @author: Luiz Gilberto
     * @name: ArrayList.class.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class ArrayList
    {
        private $tab;
        private $size;

        /**
         * Construtor
         */
        public function ArrayList()
        {
            $this->tab = array();
            $this->size=0;
        }

        /**
         * Adiciona valor na lista
         * @param mixed $value
         */
        public function add($value)
        {
            $this->tab[$this->size] = $value;
            $this->size = ($this->size) +1;
        }

        /**
         * Pega um elemento de acordo com um �ndice
         * @param int $idx
         */
        public function get($idx)
        {
            return $this->tab[$idx];
        }

        /**
         * Pega o �ltimo elemento
         */
        public function getLast()
        {
            return $this->tab[($this->size)-1];
        }

        /**
         * Pega o tamanho da lista
         */
        public function size()
        {
            return $this->size;
        }

        /**
         * Verifica se a lista est� vazia
         */
        public function isEmpty()
        {
            return ($this->size)==0;
        }

        /**
         * Remove o �ltimo elemento
         */
        public function removeLast()
        {
            return $this->size = ($this->size) -1;
        }
    }
?>