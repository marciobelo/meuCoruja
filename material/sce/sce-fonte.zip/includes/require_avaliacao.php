<?php
    require_once ("$BASE_DIR/sce/classes/models/Avaliacao.php");
    require_once ("$BASE_DIR/sce/classes/dao/Avaliacao.php");
?>