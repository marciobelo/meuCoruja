<?php
    require_once("$BASE_DIR/sce/classes/models/Aluno.php");
    require_once("$BASE_DIR/sce/classes/dao/Aluno.php");
?>