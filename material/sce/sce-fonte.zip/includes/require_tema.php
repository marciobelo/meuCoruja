<?php
    require_once("$BASE_DIR/sce/classes/models/Tema.php");
    require_once("$BASE_DIR/sce/classes/dao/Tema.php");
?>