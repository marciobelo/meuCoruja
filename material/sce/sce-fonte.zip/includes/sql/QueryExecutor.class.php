<?php
    /**
     * Objeto executa queries sql
     */
    class QueryExecutor
    {

        /**
         * Executa a query
         *
         * @param sqlQuery Query SQL
         */
        public static function execute($sqlQuery)
        {
            $transaction = Transaction::getCurrentTransaction();
            if(!$transaction)
            {
                $connection = new Connection();
            }else
            {
                $connection = $transaction->getConnection();
            }
            $query = $sqlQuery->getQuery();
            $result = $connection->executeQuery($query);
            if(!$result)
            {
                throw new Exception(mysql_error());
            }
            $i=0;
            $tab = array();
            while ($row = mysql_fetch_array($result))
            {
                $tab[$i++] = $row;
            }
            mysql_free_result($result);
            if(!$transaction)
            {
                $connection->close();
            }
            return $tab;
        }


        /**
         * Executa query de update
         * @param string $sqlQuery
         */
        public static function executeUpdate($sqlQuery)
        {
            $transaction = Transaction::getCurrentTransaction();
            if(!$transaction)
            {
                $connection = new Connection();
            }else
            {
                $connection = $transaction->getConnection();
            }
            $query = $sqlQuery->getQuery();
            $result = $connection->executeQuery($query);
            if(!$result)
            {
                return mysql_error();
            }
            else
            {
                return mysql_affected_rows();
            }
        }

        /**
         * Executa insert
         * @param string $sqlQuery
         */
        public static function executeInsert($sqlQuery)
        {
            QueryExecutor::executeUpdate($sqlQuery);
            return mysql_insert_id();
        }

    }
?>