<?php
    /*
 * Classe retorna a conex�o para o banco de dados
    */
    class ConnectionFactory
    {

        /**
         * Retorna conex�o
         * @return Connection
         */
        static public function getConnection()
        {
            $connectionProperty = new ConnectionProperty();
            $conn = mysql_connect($connectionProperty->getHost(), $connectionProperty->getUser(),
                    $connectionProperty->getPassword());
            mysql_select_db($connectionProperty->getDatabase());
            if(!$conn)
            {
                throw new Exception('could not connect to database');
            }
            return $conn;
        }

        /**
         * Fecha a conex�o
         *
         * @param Connection
         */
        static public function close($connection)
        {
            mysql_close($connection);
        }
    }
?>