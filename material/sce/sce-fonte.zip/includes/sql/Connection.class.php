<?php
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    /*
 * Objeto representa conex�o com o banco de dados
    */
    class Connection
    {
        private $connection;

        /**
         * Construtor da conex�o
         */
        public function Connection()
        {
            $this->connection = ConnectionFactory::getConnection();
        }

        /**
         * Fecha conex�o
         */
        public function close()
        {
            ConnectionFactory::close($this->connection);
        }

        /**
         * Executa query
         *
         * @param Query sql
         * @return resultado
         */
        public function executeQuery($sql)
        {
            return mysql_query($sql, $this->connection);
        }
    }
?>