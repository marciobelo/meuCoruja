<?php
    /*
 * Transa��o de banco de dados
    */
    class Transaction
    {
        private static $transactions;

        private $connection;

        /**
         * Construtor de transa��o
         */
        public function Transaction()
        {
            $this->connection = new Connection();
            if(!Transaction::$transactions)
            {
                Transaction::$transactions = new ArrayList();
            }
            Transaction::$transactions->add($this);
            $this->connection->executeQuery('BEGIN');
        }

        /**
         * D� commit numa transa��o
         */
        public function commit()
        {
            $this->connection->executeQuery('COMMIT');
            $this->connection->close();
            Transaction::$transactions->removeLast();
        }

        /**
         * D� rollback numa transa��o
         */
        public function rollback()
        {
            $this->connection->executeQuery('ROLLBACK');
            $this->connection->close();
            Transaction::$transactions->removeLast();
        }

        /**
         * Pega uma conex�o
         */
        public function getConnection()
        {
            return $this->connection;
        }

        /**
         * Retorna a transa��o atual
         */
        public static function getCurrentTransaction()
        {
            if(Transaction::$transactions)
            {
                $tran = Transaction::$transactions->getLast();
                return $tran;
            }
            return;
        }
    }
?>