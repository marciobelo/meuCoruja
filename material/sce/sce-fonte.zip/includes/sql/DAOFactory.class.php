<?php

    /**
     * DAOFactory F�brica de DAO
     */
    class DAOFactory
    {

        /**
         * Pega a DAO de aluno
         */
        public static function getAlunoDAO()
        {
            return new AlunoMySqlDAO();
        }

        /**
         * Pega a DAO de aspecto
         */
        public static function getAspectoDAO()
        {
            return new AspectoMySqlDAO();
        }

        /**
         * Pega a DAO de atividade
         */
        public static function getAtividadeDAO()
        {
            return new AtividadeMySqlDAO();
        }

        /**
         * Pega a DAO de avaliacao
         */
        public static function getAvaliacaoDAO()
        {
            return new AvaliacaoMySqlDAO();
        }

        /**
         * Pega a DAO de avaliacaoaspecto
         */
        public static function getAvaliacaoaspectoDAO()
        {
            return new AvaliacaoaspectoMySqlDAO();
        }

        /**
         * Pega a DAO de categoriaatividade
         */
        public static function getCategoriaatividadeDAO()
        {
            return new CategoriaatividadeMySqlDAO();
        }

        /**
         * Pega a DAO de categoriaevento
         */
        public static function getCategoriaeventoDAO()
        {
            return new CategoriaeventoMySqlDAO();
        }

        /**
         * Pega a DAO de coordenador
         */
        public static function getCoordenadorDAO()
        {
            return new CoordenadorMySqlDAO();
        }

        /**
         * Pega a DAO de espaco
         */
        public static function getEspacoDAO()
        {
            return new EspacoMySqlDAO();
        }

        /**
         * Pega a DAO de evento
         */
        public static function getEventoDAO()
        {
            return new EventoMySqlDAO();
        }

        /**
         * Pega a DAO de login
         */
        public static function getLoginDAO()
        {
            return new LoginMySqlDAO();
        }

        /**
         * Pega a DAO de matriculaaluno
         */
        public static function getMatriculaAlunoDAO()
        {
            return new MatriculaAlunoMySqlDAO();
        }

        /**
         * Pega a DAO de matriculaprofessor
         */
        public static function getMatriculaProfessorDAO()
        {
            return new MatriculaProfessorMySqlDAO();
        }

        /**
         * Pega a DAO de pessoa
         */
        public static function getPessoaDAO()
        {
            return new PessoaMySqlDAO();
        }

        /**
         * Pega a DAO de professor
         */
        public static function getProfessorDAO()
        {
            return new ProfessorMySqlDAO();
        }

        /**
         * Pega a DAO de tema
         */
        public static function getTemaDAO()
        {
            return new TemaMySqlDAO();
        }


    }
?>