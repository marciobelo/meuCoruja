<?php

    require_once ("../includes/comum.php");

    /**
     * Propriedades de conex�o
     */
    class ConnectionProperty
    {
        private $host;
        private $user;
        private $password;
        private $database;

        /**
         * Construtor
         * @global string $SGBD_SERVIDOR
         * @global string $SGBD_USUARIO
         * @global string $SGBD_SENHA
         */
        public function __construct()
        {
            global $SGBD_SERVIDOR, $SGBD_USUARIO, $SGBD_SENHA;
            $this->host = $SGBD_SERVIDOR;
            $this->user = $SGBD_USUARIO;
            $this->password = $SGBD_SENHA;
            $this->database = 'sce';
        }

        /**
         * Retorna o host
         */
        public function getHost()
        {
            return $this->host;
        }

        /**
         * Retorna o usu�rio
         */
        public function getUser()
        {
            return $this->user;
        }

        /**
         * Retorna a senha
         */
        public function getPassword()
        {
            return $this->password;
        }

        /**
         * Retorna o banco de dados
         */
        public function getDatabase()
        {
            return $this->database;
        }
    }
?>