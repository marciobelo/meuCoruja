<?php
    /**
     * Objeto representa query SQL com parâmetros
     */
    class SqlQuery
    {
        var $txt;
        var $params = array();
        var $idx = 0;

        /**
         * Construtor
         *
         * @param String $txt query em sql
         */
        function SqlQuery($txt)
        {
            $this->txt = $txt;
        }

        /**
         * Seta parâmetros em string
         *
         * @param String $value valor a ser setado
         */
        public function setString($value)
        {
            $value = mysql_escape_string($value);
            if ($value != 'NULL') {
                $this->params[$this->idx++] = "'".$value."'";
            } else {
                $this->params[$this->idx++] = 'NULL';
            }
        }

        /**
         * Seta parâmetros em string
         *
         * @param String $value valor a ser setado
         */
        public function set($value)
        {
            $value = mysql_escape_string($value);
            if ($value != 'NULL') {
                $this->params[$this->idx++] = "'".$value."'";
            } else {
                $this->params[$this->idx++] = 'NULL';
            }
        }


        /**
         * Seta números
         *
         * @param String $value número a ser setado
         */
        public function setNumber($value)
        {
            if (!is_numeric($value)) {
                throw new Exception($value.' is not a number');
            }
            if ($value==null) {
                $this->params[$this->idx++] = null;
            } else {
                $this->params[$this->idx++] = "'".$value."'";
            }
        }

        /**
         * Retorna query sql
         */
        public function getQuery()
        {
            if ($this->idx==0) {
                return $this->txt;
            }
            $p = explode("?", $this->txt);
            $sql = '';
            for ($i=0;$i<=$this->idx;$i++) {
                $sql .= $p[$i].$this->params[$i];
            }
            return $sql;
        }
        
    }
?>