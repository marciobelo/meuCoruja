<?php
    require_once("$BASE_DIR/sce/classes/models/Professor.php");
    require_once("$BASE_DIR/sce/classes/dao/Professor.php");
?>