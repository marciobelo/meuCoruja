<?php
    require_once("$BASE_DIR/sce/classes/models/Pessoa.php");
    require_once("$BASE_DIR/sce/classes/dao/Pessoa.php");
?>