<?php
    require_once("$BASE_DIR/sce/classes/models/Espaco.php");
    require_once("$BASE_DIR/sce/classes/dao/Espaco.php");
?>