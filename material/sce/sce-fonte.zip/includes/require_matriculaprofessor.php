<?php
    require_once("$BASE_DIR/sce/classes/models/MatriculaProfessor.php");
    require_once("$BASE_DIR/sce/classes/dao/MatriculaProfessor.php");
?>