<?php
    require_once("$BASE_DIR/sce/classes/models/Aspecto.php");
    require_once("$BASE_DIR/sce/classes/dao/Aspecto.php");
?>