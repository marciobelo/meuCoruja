<?php
    require_once("$BASE_DIR/sce/classes/models/Externo.php");
    require_once("$BASE_DIR/sce/classes/dao/Externo.php");
?>
