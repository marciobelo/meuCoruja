<?php
    require_once ("$BASE_DIR/sce/classes/models/AvaliacaoAspecto.php");
    require_once ("$BASE_DIR/sce/classes/dao/AvaliacaoAspecto.php");
?>