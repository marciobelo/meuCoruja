<?php
    require_once("$BASE_DIR/sce/classes/models/Atividade.php");
    require_once("$BASE_DIR/sce/classes/dao/Atividade.php");
?>