<?php

    require_once("../includes/comum.php");

    require_once("require_aluno.php");
    require_once("require_professor.php");
	require_once("require_administrador.php");

    $idPessoa = $_SESSION["usuario"]->getIdPessoa();

    $AlunoMySqlDAO = new AlunoMySqlDAO();
    $ProfessorMySqlDAO = new ProfessorMySqlDAO();
	$AdministradorMySqlDAO = new AdministradorMySqlDAO();
	if ($AdministradorMySqlDAO->load($idPessoa)->getIdPessoa())
	{
		$permissao = "coordenador";
	}
    elseif ($AlunoMySqlDAO->load($idPessoa)->getIdPessoa())
    {
        $permissao = "aluno";
    }
    elseif ($ProfessorMySqlDAO->load($idPessoa)->getIdPessoa())
    {
        $permissao = "professor";
    }

?>
