<?php
    require_once("$BASE_DIR/sce/classes/models/MatriculaAluno.php");
    require_once("$BASE_DIR/sce/classes/dao/MatriculaAluno.php");
?>