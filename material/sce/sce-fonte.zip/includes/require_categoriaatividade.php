<?php
    require_once("$BASE_DIR/sce/classes/models/Categoriaatividade.php");
    require_once("$BASE_DIR/sce/classes/dao/Categoriaatividade.php");
?>