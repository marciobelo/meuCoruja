<?php
    require_once("$BASE_DIR/sce/classes/models/Evento.php");
    require_once("$BASE_DIR/sce/classes/dao/Evento.php");
?>