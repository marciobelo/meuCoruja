<?php
    require_once("$BASE_DIR/sce/classes/models/CategoriaEvento.php");
    require_once("$BASE_DIR/sce/classes/dao/CategoriaEvento.php");
?>