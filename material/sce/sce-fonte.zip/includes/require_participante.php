<?php
    require_once("$BASE_DIR/sce/classes/models/Participante.php");
    require_once("$BASE_DIR/sce/classes/dao/Participante.php");
?>
