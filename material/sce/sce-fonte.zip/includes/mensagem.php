<?php
    if ($_SESSION["erro"])
    {
        echo "<div id='erro'>";
        echo $_SESSION["erro"];
        echo "</div>";
        unset ($_SESSION["erro"]);
    } elseif ($_SESSION["sucesso"])
    {
        echo "<div id='sucesso'>";
        echo $_SESSION["sucesso"];
        echo "</div>";
        unset ($_SESSION["sucesso"]);
    }
?>