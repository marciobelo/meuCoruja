<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_externo.php");

    $Externo = new Externo();
    if (!$_POST["nome"] or !$_POST["instituicao"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        $_SESSION["externoSession"] = $_POST;
        header("Location: manter_externos.php?pag=1");
        break;
    }

    $Externo->setNome( $_POST["nome"] );
    $Externo->setInstituicao( $_POST["instituicao"] );
    $Externo->setTelefone( $_POST["telefone"] );
    $Externo->setEmail( $_POST["email"] );
    $ExternoMySqlDAO = new ExternoMySqlDAO();
    $Externo = $ExternoMySqlDAO->insert( $Externo );
    if ($Externo==0)
    {
        trigger_error(mysql_error(), E_USER_ERROR);
    }
    else
    {
        $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
        header("Location: manter_externos.php?pag=1");
    }
?>