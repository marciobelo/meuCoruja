<?php
    require_once ("../includes/comum.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador") {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }

    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once($BASE_DIR . "/sce/includes/require_espaco.php");
    require_once($BASE_DIR . "/sce/includes/require_categoriaatividade.php");
    require_once($BASE_DIR . "/sce/includes/require_externo.php");

    $PessoaMySqlDAO = new PessoaMySqlDao;
    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDao;
    $EspacoMySqlDAO = new EspacoMySqlDao;
    $ExternoMySqlDAO = new ExternoMySqlDao;
    $categorias = $CategoriaAtividadeMySqlDAO->queryAll();
    $internos = $PessoaMySqlDAO->queryAll();
    $externos = $ExternoMySqlDAO->queryAll();

    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $atividade = $AtividadeMySqlDAO->load($_GET["id"]);
    $idEvento = $atividade->getIdEvento();

    if ($atividade->getIdEspaco()) {
        $espaco = $EspacoMySqlDAO->load($atividade->getIdEspaco());
        $espaco = $espaco->getNome();
    } else {
        $espaco = $atividade->getCustomEspaco();
    }
?>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/jscal2.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/border-radius.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/gold/gold.css" />
    <script type="text/javascript" src="./javascript/jscal2/js/jscal2.js"></script>
    <script type="text/javascript" src="./javascript/jscal2/js/lang/pt.js"></script>
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <h4>Altera��o da atividade <?php echo $atividade->getNome(); ?></h4>
            <form action="proc_alterar_atividade.php" method="post" name="form">
                <input name="id" type="hidden" value=<?php echo $_GET["id"]; ?> />
                <input type="hidden" name="evento" value="<?php echo $_GET["evento"]; ?>" />
                <input name="data" type="hidden" value=<?php echo $atividade->getData(); ?> />
                <input name="horaInicial" type="hidden" value=<?php echo $atividade->getHoraInicial(); ?> />
                <input name="horaFinal" type="hidden" value=<?php echo $atividade->getHoraFinal(); ?> />
                Nome: (*) <input type="text" name="nome" value=<?php echo '"' . $atividade->getNome() . '"' ?> />
                <br />
                <br />
                Data: <?php echo date("d/m/Y",strtotime($atividade->getData())) ?>
                <br />
                <br />
                Hor�rio: <?php echo $atividade->getHoraInicial() . "/" . $atividade->getHoraFinal() ?>
                <br />
                <br />
                Espa�o: <?php echo $espaco; ?>
                <br />
                <br />
                Categoria:
                <select name="categoria">
                    <?php
                        foreach ($categorias as $categoria)
                        {
                            if ($atividade->getIdCategoriaAtividade()!=$categoria->getId()) {
                                echo "<option value=" . $categoria->getId(). ">" . $categoria->getNome() . "</option>";
                            } else {
                                echo '<option selected="selected"  value=' . $categoria->getId() . ">"
                                     . $categoria->getNome() . "</option>";
                            }
                        }
                    ?>
                </select>
                <br />
                <br />
                Respons�vel:
                <select name='seletorPalestrante' onchange='if (this.value=="Interno") {
                    document.form.interno.style.display = ""; document.form.externo.style.display = "none"; } else {
                    document.form.externo.style.display = ""; document.form.interno.style.display = "none"; }
                    return true;'>
                    <?php
                        if ($_SESSION["atividadeSession"]["seletorPalestrante"] == "Interno"
                            || $atividade->getTipoPalestrante() == "I") {
                            echo "<option selected='selected' value='Interno'>Interno</option>";
                            echo "<option value='Externo'>Externo</option>";
                        } else {
                            echo "<option value='Interno'>Interno</option>";
                            echo "<option selected='selected' value='Externo'>Externo</option>";
                        }
                    ?>
                </select>
                <?php
                    if ($_SESSION["atividadeSession"]["seletorPalestrante"] == "Interno"
                    || $atividade->getTipoPalestrante() == "I") {
                        echo "<select name='interno'>";
                    }
                    else
                    {
                        echo "<select name='interno' style='display: none'>";
                    }
                    if (is_null($atividade->getIdPalestrante())) {
                        echo "<option value='' selected='selected'>-</option>";
                    }
                    else
                    {
                        echo "<option value=''>-</option>";
                    }
                    foreach ($internos as $interno) {
                        if ($atividade->getIdPalestrante() != $interno->getIdPessoa()) {
                            echo "<option value=" . $interno->getIdPessoa(). ">" . $interno->getNome()
                                 . "</option>";
                        } else {
                            echo '<option selected="selected" value=' . $interno->getIdPessoa() . ">"
                                 . $interno->getNome() . "</option>";
                        }
                    }
                    echo "</select>";

                    if ($_SESSION["atividadeSession"]["seletorPalestrante"] == "Externo"
                    || $atividade->getTipoPalestrante() == "E") {
                        echo "<select name='externo'>";
                    }
                    else
                    {
                        echo "<select name='externo' style='display: none'>";
                    }
                    if (is_null($atividade->getIdPalestrante())) {
                        echo "<option value='' selected='selected'>-</option>";
                    }
                    else
                    {
                        echo "<option value=''>-</option>";
                    }
                    foreach ($externos as $externo) {
                        if ($atividade->getIdPalestrante() != $externo->getId()) {
                            echo "<option value=" . $externo->getId() . ">" . $externo->getNome()
                                 . "</option>";
                        } else {
                            echo '<option selected="selected" value=' . $externo->getId() . ">"
                                 . $externo->getNome() . "</option>";
                        }
                    }
                    echo "</select>";
                ?>
                <br />
                <br />
                <input type='submit' value='Cadastrar' name='submit' />
                <input type="button" value="Voltar"
                       onclick="window.location='detalhe_evento.php?id=<?php echo $idEvento ?>&pag=1'" />
            </form>
<?php
    include($BASE_DIR . "/sce/includes/legenda.html");
?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>
