<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_categoriaevento.php");

    $Categoriaevento = new Categoriaevento();
    if (!$_POST["nome"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        header("Location: manter_categoriaevento.php");
        break;
    }
    else
    {
        $Categoriaevento->setNome( $_POST["nome"] );
        $CategoriaeventoMySqlDAO = new CategoriaeventoMySqlDAO();
        $Categoriaevento = $CategoriaeventoMySqlDAO->insert( $Categoriaevento );
    }

    if ($Categoriaevento==0)
    {
        $_SESSION["erro"] = "Erro no cadastro";
        header("Location: manter_categoriaevento.php");
    }
    else
    {
        $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
        header("Location: manter_categoriaevento.php");
    }
?>