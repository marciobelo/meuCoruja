<?php

    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_espaco.php");
    require_once ($BASE_DIR . "/sce/includes/require_evento.php");
    require_once ($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once ($BASE_DIR . "/sce/includes/require_aluno.php");
    require_once ($BASE_DIR . "/sce/includes/require_professor.php");
    require_once ($BASE_DIR . "/sce/includes/require_categoriaatividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");

    $tot = 10;

    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $atividades = $AtividadeMySqlDAO->querybyIdEventoOrderByPage($_GET["id"], "data, horaInicial", (int)$_GET["pag"],
                                                                 $tot);

    $count = $AtividadeMySqlDAO->countFromEvento($_GET["id"]);
    $count = $count[0][0];

    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDao;
    $categorias = $CategoriaAtividadeMySqlDAO->queryAll();

    $EspacoMySqlDAO = new EspacoMySqlDao;
    $espacos = $EspacoMySqlDAO->queryAll();

    $EventoMySqlDAO = new EventoMySqlDao;
    $evento = $EventoMySqlDAO->load($_GET["id"]);

    $idCoordenador = $evento->getIdPessoa();

    $PessoaMySqlDAO = new PessoaMySqlDao;
    $coordenadores = $PessoaMySqlDAO->queryAll();
    $palestrantes = $PessoaMySqlDAO->queryAll();

    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();

    $minDate = date("Ymd",strtotime($evento->getDtInicial()));
    $maxDate = date("Ymd",strtotime($evento->getDtFinal()));
?>
<head>
    <meta http-equiv="Content-Type" content="text/html" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/jscal2.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/border-radius.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/gold/gold.css" />
    <script type="text/javascript" src="./javascript/jscal2/js/jscal2.js"></script>
    <script type="text/javascript" src="./javascript/jscal2/js/lang/pt.js"></script>
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                if ($atividades) {
                    echo "<h4>Lista de atividades do evento" . $evento->getNome() . "</h4>";
                    $idEvento = $_GET["id"];
                    if ($_GET["pag"] != 1) {
                        $ant = $_GET["pag"]-1;
                        echo "<a href='atividade_estatistica.php?id=$idEvento&pag=1' ><< </a>";
                        echo "<a href='atividade_estatistica.php?id=$idEvento&pag=$ant' >< </a>";
                    }
                    $ultima = floor($count / $tot);

                    if ($ultima != 0 && $_GET["pag"] != $ultima) {
                        $prox = $_GET["pag"]+1;
                        echo "<a href='atividade_estatistica.php?id=$idEvento&pag=$ultima' style='float:right; "
                             . "padding-right: 10px;'> &nbsp; >></a>";
                        echo "<a href='atividade_estatistica.php?id=$idEvento&pag=$prox' style='float:right;'> > </a>";
                    }
                    echo "<br />";
                    echo "<table class='tabDados'>";
                    echo "<tr>";
                    echo "<th>T�tulo</th>";
                    echo "<th>Data</th>";
                    echo "<th>Hor�rio</th>";
                    echo "<th>Categoria</th>";
                    echo "<th>Espa�o</th>";
                    echo "<th>Estat�sticas</th>";
                    echo "</tr>";
                    foreach ($atividades as $atividade) {
                        $id = $atividade->getId();
                        $categoriaAtividade = $CategoriaAtividadeMySqlDAO->load($atividade->getIdCategoriaAtividade());
                        $categoriaAtividade = $categoriaAtividade->getNome();
                        $horaInicial = substr($atividade->getHoraInicial(), 0, 5);
                        $horaFinal = substr($atividade->getHoraFinal(), 0, 5);
                        echo "<td>" . $atividade->getNome() . "</td>";
                        echo "<td>" . date("d/m/Y", strtotime($atividade->getData())) . "</td>";
                        echo "<td>" . $horaInicial . "/" . $horaFinal . "</td>";
                        echo "<td>" . $categoriaAtividade . "</td>";
                        if ($atividade->getIdEspaco()) {
                            $espaco = $EspacoMySqlDAO->load($atividade->getIdEspaco());
                            echo "<td>" . $espaco->getNome() . "</td>";
                        } else {
                            echo "<td>" . $atividade->getCustomEspaco() . "</td>";
                        }
                        echo "<td><a href='obter_estatistica_atividade.php?id=$id'>Clique</a></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "N�o h� atividades cadastradas!";
                }
            ?>
            <input type="button" value="Voltar" onclick="window.location='obter_estatistica.php?pag=1'" />
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
        ?>
</body>
</html>