<?php 
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");

    $PessoaMySqlDAO = new PessoaMySqlDAO();
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
    $AtividadeMySqlDAO = new AtividadeMySqlDAO();
    if ($_GET["id"])
    {
        $avaliacao = $AvaliacaoMySqlDAO->load($_GET["id"]);
        $avaliacao->setStatus(1);
        $AvaliacaoMySqlDAO->update($avaliacao);
        if ($avaliacao == 0)
        {
            trigger_error(mysql_error(), E_USER_ERROR);
        } else
        {
            $_SESSION["sucesso"] = "Valida��o bem-sucedida";
            $id = $avaliacao->getIdAtividade();
            header("Location: validar_avaliacao.php?id=$id");
        }
    } else
    {
        $avaliacoes = $_POST["avaliacao"];
		if (is_array($avaliacoes) && count($avaliacoes) > 0 ) {
			foreach ($avaliacoes as &$avaliacao)
			{
				$avaliacao =  $AvaliacaoMySqlDAO->load($avaliacao);
				$avaliacao->setStatus(1);
				$avaliacao = $AvaliacaoMySqlDAO->update($avaliacao);
				if ($avaliacao == 0)
				{
					trigger_error(mysql_error(), E_USER_ERROR);
				} else
				{
					$_SESSION["sucesso"] = "Valida��o bem-sucedida";
					$id = $_POST["idAvaliacao"];
					header("Location: validar_avaliacao.php?id=$id");
				}
			}
		} else {
			$_SESSION["erro"] = "Escolha uma avalia��o";
			$id = $_POST["idAvaliacao"];
			header("Location: validar_avaliacao.php?id=$id");
		}
    }


?>