<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_administrador.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");

    $tot = 10;

    $PessoaMySqlDAO = new PessoaMySqlDao;
    $pessoas = $PessoaMySqlDAO->queryAllByPage((int)$_GET["pag"], $tot);
    $count = $PessoaMySqlDAO->count();
    $count = $count[0][0];
    $AdministradorMySqlDAO = new AdministradorMySqlDao;
?>
<head>
    <meta http-equiv="Content-Type" content="text/html" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                if ($pessoas)
                {
                ?>
            <h4>Lista de internos cadastrados</h4>
                <?php
                    if ($_GET["pag"] != 1)
                    {
                        $ant = $_GET["pag"]-1;
                        echo "<a href='manter_administradores.php?pag=1' ><< </a>";
                        echo "<a href='manter_administradores.php?pag=$ant' >< </a>";
                    }
                    $ultima = floor($count / $tot);

                    if ($ultima != 0 && $_GET["pag"] != $ultima)
                    {
                        $prox = $_GET["pag"]+1;
                        echo "<a href='manter_administradores.php?pag=$ultima' style='float:right; padding-right: 10px;'> "
                             . "&nbsp; >></a>";
                        echo "<a href='manter_administradores.php?pag=$prox' style='float:right;'> > </a>";
                    }
                ?>
            <table class="tabDados">
                <tr>
                    <th>Nome</th>
                    <th>Admin</th>
                </tr>
                    <?php
                        foreach ($pessoas as $pessoa)
                        {
                            $id = $pessoa->getIdPessoa();
                            $adm = $AdministradorMySqlDAO->isAdm($id);
                            if ($adm)
                            {
			    	$strAdm = 'Sim';
                            }
                            else
                            {
			    	$strAdm = 'N�o';
			    }
                            echo "<tr>";
                            echo "<td>" . $pessoa->getNome() . "</td>";
                            echo "<td> <a href='alterar_administrador.php?id=$id'>$strAdm</a> </td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    }
                    else
                    {
                        echo "N�o h� pessoas cadastradas! Cadastre uma pessoa usando o Sistema Coruja.";
                    }
                ?>
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
        ?>
</body>
</html>