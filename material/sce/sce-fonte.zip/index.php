<?php
    require_once("../includes/comum.php");
    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <h3>Sistema de Controle de Eventos do IST-Rio</h3>
            <p>Selecione a op��o desejada no menu ao lado.</p>
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
        ?>
</body>
</html>
