<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once($BASE_DIR . "/sce/includes/require_aluno.php");
    require_once($BASE_DIR . "/sce/includes/require_professor.php");
    require_once($BASE_DIR . "/sce/includes/require_matriculaprofessor.php");
    require_once($BASE_DIR . "/sce/includes/require_matriculaaluno.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");
    require_once($BASE_DIR . "/sce/includes/require_aspecto.php");
    require_once ("./includes/permissao.php");

    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
    $avaliacao = $AvaliacaoMySqlDAO->load($_GET["id"]);

    $AtividadeMySqlDAO = new AtividadeMySqlDAO();
    $atividade = $AtividadeMySqlDAO->load($avaliacao->getIdAtividade());
    
    $idAtividade = $avaliacao->getIdAtividade();
    
    $idEvento = $atividade->getIdEvento();

    $AvaliacaoAspectoMySqlDAO = new AvaliacaoaspectoMySqlDAO();
    $avaliacoesaspecto = $AvaliacaoAspectoMySqlDAO->queryByIdAvaliacao($_GET["id"]);

    $AlunoMySqlDAO = new AlunoMySqlDAO();
    $ProfessorMySqlDAO = new ProfessorMySqlDAO();

    $AspectoMySqlDAO = new AspectoMySqlDAO();

    if (!is_null($AlunoMySqlDAO->load($avaliacao->getIdPessoa())->getIdPessoa()))
    {
        $cond = "aluno";
        $MatriculaAlunoMySqlDAO = new MatriculaAlunoMySqlDAO();
        $matricula = $MatriculaAlunoMySqlDAO->queryByIdPessoa($avaliacao->getIdPessoa());
    }
    elseif (!is_null($ProfessorMySqlDAO->load($avaliacao->getIdPessoa())->getIdPessoa()))
    {
        $cond = "professor";
        $MatriculaProfessorMySqlDAO = new MatriculaProfessorMySqlDAO();
        $matricula = $MatriculaProfessorMySqlDAO->queryByIdPessoa($avaliacao->getIdPessoa());
    }

    $PessoaMySqlDAO = new PessoaMySqlDAO();
    $pessoa = $PessoaMySqlDAO->load($avaliacao->getIdPessoa());
    $nomeAvaliacao = $pessoa->getNome();

    include ($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
                include($BASE_DIR . "/sce/includes/menu.html");
                include($BASE_DIR . "/sce/includes/mensagem.php");
            ?>
        <div id="mainContent">
            <?php
                $nomeAtividade = $atividade->getNome();
                $horaInicial = $atividade->getHoraInicial();
                $horaFinal = $atividade->getHoraFinal();
                $data = date("d-m-Y", strtotime($atividade->getData()));
            ?>
            <h4>Avaliação da atividade <?php echo $nomeAtividade ?></h4>
            <b>Data:</b> <?php echo $data ?>
            <b>&nbsp;&nbsp;Hora:</b> <?php echo "$horaInicial - $horaFinal" ?>
            <br />
            <br />
            <b>Nome:</b> <?php echo $nomeAvaliacao; ?>
            <br />
            <br />
            <?php
                if (is_array($matricula) && !empty($matricula))
                {
                    echo "<b>Matrículas: </b>";
                    foreach ($matricula as $key => $mat)
                    {
                        if ($key == 0)
                        {
                            if ($cond == "aluno")
                            {
                                echo $mat->getMatriculaAluno();
                            }
                            elseif ($cond == "professor")
                            {
                                echo $mat->getMatriculaProfessor();
                            }
                        }
                        else
                        {
                            if ($cond == "aluno")
                            {
                                echo " / " . $mat->getMatriculaAluno();
                            }
                            elseif ($cond == "professor")
                            {
                    echo " / " . $mat->getMatriculaProfessor();
                }
                        }
                    }
                }
                elseif (!empty($matricula))
                {
                    echo "<b>Matrícula: </b>";
                    echo $matricula;
                }
                else
                {
                    echo "<b>Matrícula: -</b>";
                }
            ?>
            <br />
            <br />
            <?php
                foreach ($avaliacoesaspecto as $key => $avaliacaoaspecto)
                {
                    if ($avaliacaoaspecto->getResposta() == 0)
                    {
                        $resposta = "<img alt='Péssimo' title='Péssimo' src='./includes/imagens/pessimo.png' />";
                    } 
                    elseif ($avaliacaoaspecto->getResposta() == 1)
                    {
                        $resposta = "<img alt='Ruim' title='Ruim' src='./includes/imagens/ruim.png' />";
                    } 
                    elseif ($avaliacaoaspecto->getResposta() == 2)
                    {
                        $resposta = "<img alt='Regular' title='Regular' src='./includes/imagens/regular.png' />";
                    } 
                    elseif ($avaliacaoaspecto->getResposta() == 3)
                    {
                        $resposta = "<img alt='Bom' title='Bom' src='./includes/imagens/bom.png' />";
                    } 
                    else 
                    {
                        $resposta = "<img alt='Ótimo' title='Ótimo' src='./includes/imagens/otimo.png' />";
                    }
                    $aspecto = $AspectoMySqlDAO->load($avaliacaoaspecto->getIdAspecto())->getNome();
                    echo "<b>" . $aspecto . "</b>" . ": " . $resposta;
                    if ($key != count($avaliacoesaspecto) - 1)
                    {
                        echo "<br />";
                        echo "<br />";
                    }
                }
            ?>
            <br />
            <br />
            <b>Sugestão:</b>
            <br />
            <?php
                if ($avaliacao->getSugestao() != "")
                {
                    echo nl2br($avaliacao->getSugestao());
                }
                else
                {
                    echo "-";
                }
            ?>
            <br />
            <br />
            <b>Sugestão de evento:</b>
            <br />
            <?php
                if ($avaliacao->getSugestaoEvento())
                {
                    echo nl2br($avaliacao->getSugestaoEvento());
                }
                else
                {
                    echo "-";
                }
            ?>
            <br />
            <br />
        <?php
            $validado = ($avaliacao->getStatus()) ? "Sim" : "Não";
            echo "<b>Validado: </b>" . $validado;
            echo "<br />";
            echo "<br />";
            if ($permissao == 'coordenador')
            {
                        if ($avaliacao->getStatus() == 0)
                        {
                                $id = $_GET['id'];
                                echo "<form method='GET' action='proc_validar_avaliacao.php'>";
                                echo "<input type='hidden' value=$id name=id />";
                                echo "<input type='submit' value='Validar' />";
                                echo "<input type='button' value='Voltar' "
                                     . "onclick='window.location=\"validar_avaliacao.php?id=$idAtividade\"' />";
                                echo "</form>";
                        }
                        else
                        {
                                $id = $_GET['id'];
                                echo "<form method='GET' action='proc_invalidar_avaliacao.php'>";
                                echo "<input type='hidden' value=$id name=id />";
                                echo "<input type='submit' value='Invalidar' />";
                                echo "<input type='button' value='Voltar'"
                                     . "onclick='window.location=\"validar_avaliacao.php?id=$idAtividade\"' />";
                                echo "</form>";
                        }
            }
            else
            {
                    echo "<input type='button' value='Voltar'"
                         . "onclick='window.location=\"detalhe_evento.php?id=$idEvento&pag=1\"' />";
            }
        ?>
            <br />
            <img alt='Péssimo' title='Péssimo' src='./includes/imagens/pessimo.png' /> Péssimo
            <br />
            <img alt='Ruim' title='Ruim' src='./includes/imagens/ruim.png' /> Ruim
            <br />
            <img alt='Regular' title='Regular' src='./includes/imagens/regular.png' /> Regular
            <br />
            <img alt='Bom' title='Bom' src='./includes/imagens/bom.png' /> Bom
            <br />
            <img alt='Ótimo' title='Ótimo' src='./includes/imagens/otimo.png' /> Ótimo
                </div>
            </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
        ?>
    </body>
</html>