<?php

    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_espaco.php");
    require_once ($BASE_DIR . "/sce/includes/require_evento.php");
    require_once ($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once ($BASE_DIR . "/sce/includes/require_aluno.php");
    require_once ($BASE_DIR . "/sce/includes/require_professor.php");
    require_once ($BASE_DIR . "/sce/includes/require_categoriaatividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
	require_once ($BASE_DIR . "/sce/includes/require_matriculaaluno.php");
	
    if ($permissao == "professor")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
    }

    $AtividadeMySqlDAO = new AtividadeMySqlDAO();

    if ($permissao == "aluno")
    {
        $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdPessoa($usuario->getIdPessoa());
        foreach ($avaliacoes as $avaliacao)
        {
            if ($avaliacao->getStatus())
            {
                $atividade = $AtividadeMySqlDAO->load($avaliacao->getIdAtividade());
                if ($atividade->getIdEvento() == $_GET["id"])
                {
                    $atividades[$avaliacao->getIdAtividade()] = $atividade;
                }
            }
        }
    }
    else
    {
        $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdPessoa($_GET['aluno']);
        foreach ($avaliacoes as $avaliacao)
        {
            if ($avaliacao->getStatus())
            {
                $atividade = $AtividadeMySqlDAO->load($avaliacao->getIdAtividade());
                if ($atividade->getIdEvento() == $_GET["id"])
                {
                    $atividades[$avaliacao->getIdAtividade()] = $atividade;
                }
            }
        }
        $idAluno = $_GET["aluno"];
        $MatriculaAlunoMySqlDAO = new MatriculaAlunoMySqlDAO();
        $matriculaAluno = $MatriculaAlunoMySqlDAO->queryByIdPessoa($idAluno);
        $matriculaAluno = $matriculaAluno[0]->getMatriculaAluno();
    }
	
    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDao;
	$EspacoMySqlDAO = new EspacoMySqlDao;
    $EventoMySqlDAO = new EventoMySqlDao;
    $evento = $EventoMySqlDAO->load($_GET["id"]);
?>
<head>
    <meta http-equiv="Content-Type" content="text/html" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                if (count($atividades) > 0) {
                    echo "<h4>Lista de atividades por hora de extens�o do evento " . $evento->getNome() . "</h4>";
                    $idEvento = $_GET["id"];
					echo "<table class='tabDados'>";
					echo "<tr>";
					echo "<th>T�tulo</th>";
					echo "<th>Data</th>";
					echo "<th>Hor�rio</th>";
					echo "<th>Categoria</th>";
					echo "<th>Espa�o</th>";
					echo "<th>Extens�o</th>";
                    if ($permissao == 'coordenador')
                    {
                        echo "<th>PDF</th>";
                    }
					echo "</tr>";
					foreach ($atividades as $atividade) {
                        $id = $atividade->getId();
                        $categoriaAtividade = $CategoriaAtividadeMySqlDAO->load($atividade->getIdCategoriaAtividade());
                        $categoriaAtividade = $categoriaAtividade->getNome();
                        $horaInicial = substr($atividade->getHoraInicial(), 0, 5);
                        $horaFinal = substr($atividade->getHoraFinal(), 0, 5);
                        echo "<td>" . $atividade->getNome() . "</td>";
                        echo "<td>" . date("d/m/Y", strtotime($atividade->getData())) . "</td>";
                        echo "<td>" . $horaInicial . "/" . $horaFinal . "</td>";
                        echo "<td>" . $categoriaAtividade . "</td>";
                        if ($atividade->getIdEspaco()) {
                            $espaco = $EspacoMySqlDAO->load($atividade->getIdEspaco());
                            echo "<td>" . $espaco->getNome() . "</td>";
                        } else {
                            echo "<td>" . $atividade->getCustomEspaco() . "</td>";
                        }
                        echo "<td>" . $atividade->getHoraExtensao() . "</td>";
                        if ($permissao == 'coordenador')
                        {
                            echo "<td><a href='gerar_pdf_atividade.php?id=$id&aluno=$idAluno' target='_blank'>Gerar</a></td>";
                        }
                        echo "</tr>";
					}
				}
                else
                {
                    echo "N�o h� atividades.";
                }
			?>
			</table>
            <?php
                if ($permissao == "coordenador")
                {
                    echo "<input type='button' value='Voltar' onclick='window.location=\"proc_obter_extensao_matricula_coordenador.php?matricula=$matriculaAluno\"' />";
                }
                else
                {
                    echo "<input type='button' value='Voltar' onclick='window.location=\"obter_extensao.php\"' />";
                }
            ?>
        </div>
		<br />
	<?php
		include($BASE_DIR . "/sce/includes/footer.html");
	?>
</body>