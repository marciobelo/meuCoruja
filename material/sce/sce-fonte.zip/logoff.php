<?php
    require_once("../includes/comum.php");

    session_destroy();
    header("Location: /coruja");
?>