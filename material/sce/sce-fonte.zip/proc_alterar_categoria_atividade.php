<?php
    require_once ("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_categoriaatividade.php");

    $CategoriaAtividade = new CategoriaAtividade();
    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDAO();
    $CategoriaAtividade = $CategoriaAtividadeMySqlDAO->load($_POST["id"]);
    if ($_POST["nome"] == $CategoriaAtividade->getNome())
    {
        $_SESSION["erro"] = "Insira um nome diferente";
        $id = $_POST["id"];
        header("Location: alterar_categoriaatividade.php?id=$id");
        break;
    }
    if (!$_POST["nome"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        $id = $_POST["id"];
        header("Location: alterar_categoriaatividade.php?id=$id");
        break;
    }
    else
    {
        $CategoriaAtividade->setNome( $_POST["nome"] );
        $CategoriaAtividade = $CategoriaAtividadeMySqlDAO->update( $CategoriaAtividade );
    }

    if ($CategoriaAtividade!=0)
    {
        $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
        header("Location: manter_categoriaatividade.php");
    } else
    {
        trigger_error(mysql_error());
    }
?>
