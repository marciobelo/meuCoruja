<?php

    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_espaco.php");
    require_once ($BASE_DIR . "/sce/includes/require_evento.php");
    require_once ($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once ($BASE_DIR . "/sce/includes/require_aluno.php");
    require_once ($BASE_DIR . "/sce/includes/require_professor.php");
    require_once ($BASE_DIR . "/sce/includes/require_categoriaatividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_externo.php");

    $tot = 10;

    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $atividades = $AtividadeMySqlDAO->querybyIdEventoOrderByPage($_GET["id"], "data, horaInicial", (int)$_GET["pag"],
                                                                 $tot);

    $count = $AtividadeMySqlDAO->countFromEvento($_GET["id"]);
    $count = $count[0][0];

    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDao;
    $categorias = $CategoriaAtividadeMySqlDAO->queryAll();

    $EspacoMySqlDAO = new EspacoMySqlDao;
    $espacos = $EspacoMySqlDAO->queryAll();

    $EventoMySqlDAO = new EventoMySqlDao;
    $evento = $EventoMySqlDAO->load($_GET["id"]);

    $PessoaMySqlDAO = new PessoaMySqlDao;
    $internos = $PessoaMySqlDAO->queryAll();

    $ExternoMySqlDAO = new ExternoMySqlDao;
    $externos = $ExternoMySqlDAO->queryAll();

    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();

    $minDate = date("Ymd",strtotime($evento->getDtInicial()));
    $maxDate = date("Ymd",strtotime($evento->getDtFinal()));
?>
<head>
    <meta http-equiv="Content-Type" content="text/html" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/jscal2.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/border-radius.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/steel/steel.css" />
    <script type="text/javascript" src="./javascript/jscal2/js/jscal2.js"></script>
    <script type="text/javascript" src="./javascript/jscal2/js/lang/pt.js"></script>
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                if ($atividades) {
                    echo "<h4>Lista de atividades do evento " . $evento->getNome() . "</h4>";
                    $idEvento = $_GET["id"];
                    if ($_GET["pag"] != 1) {
                        $ant = $_GET["pag"]-1;
                        echo "<a href='detalhe_evento.php?id=$idEvento&pag=1' ><< </a>";
                        echo "<a href='detalhe_evento.php?id=$idEvento&pag=$ant' >< </a>";
                    }
                    $ultima = floor($count / $tot);

                    if ($ultima != 0 && $_GET["pag"] != $ultima) {
                        $prox = $_GET["pag"]+1;
                        echo "<a href='detalhe_evento.php?id=$idEvento&pag=$ultima' "
                             . "style='float:right; padding-right: 10px;'> &nbsp; >></a>";
                        echo "<a href='detalhe_evento.php?id=$idEvento&pag=$prox' style='float:right;'> > </a>";
                    }
                echo "<br />";
                echo "<table class='tabDados'>";
                echo "<tr>";
                echo "<th>Título</th>";
                echo "<th>Data</th>";
                echo "<th>Horário</th>";
                echo "<th>Categoria</th>";
                echo "<th>Espaço</th>";
                if ($permissao == "coordenador") {
                    echo "<th>Alterar</th>";
                    echo "<th>Excluir</th>";
                    echo "<th>Bloqueio</th>";
                    echo "<th>Validar</th>";
                } else {
                    echo "<th>Avaliação</th>";
                }
                echo "</tr>";
                foreach ($atividades as $atividade)
                {
                    $id = $atividade->getId();
                    $categoriaAtividade = $CategoriaAtividadeMySqlDAO->load($atividade->getIdCategoriaAtividade());
                    $categoriaAtividade = $categoriaAtividade->getNome();
                    $horaInicial = substr($atividade->getHoraInicial(), 0, 5);
                    $horaFinal = substr($atividade->getHoraFinal(), 0, 5);
                    if ($atividade->getIdPalestrante()) 
                    {
                        if ($atividade->getTipoPalestrante() == "I")
                        {
                            $responsavel = $PessoaMySqlDAO->load($atividade->getIdPalestrante());
                        }
                        else
                        {
                            $responsavel = $ExternoMySqlDAO->load($atividade->getIdPalestrante());
                        }
                        $nomeResponsavel = " - " . $responsavel->getNome();
                    } 
                    else
                    {
                        $nomeResponsavel = "";
                    }
                    echo "<td>" . $atividade->getNome() . $nomeResponsavel . "</td>";
                    echo "<td>" . date("d/m/Y", strtotime($atividade->getData())) . "</td>";
                    echo "<td>" . $horaInicial . "/" . $horaFinal . "</td>";
                    echo "<td>" . $categoriaAtividade . "</td>";
                    if ($atividade->getIdEspaco()) {
                        $espaco = $EspacoMySqlDAO->load($atividade->getIdEspaco());
                        echo "<td>" . $espaco->getNome() . "</td>";
                    } else {
                        echo "<td>" . $atividade->getCustomEspaco() . "</td>";
                    }
                    if ($permissao == "coordenador") {
                        $idEvento = $_GET["id"];
                        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdAtividade($id);
                        echo "<td> <a href='alterar_atividade.php?id=$id&evento=$idEvento'>Clique</a> </td>";
                        echo "<td> <a href='excluir_atividade.php?id=$id' "
                             . "onclick='return confirm(\"Deseja realmente excluir a atividade? As avaliações "
                             . "vinculadas também serão excluidas.\")'>Clique</a> </td>";
                        $bloqueado = ($atividade->getBloqueado() == 0) ? 1 : 0;
                        $strBloqueado = ($atividade->getBloqueado()) ? 'Não' : 'Sim';
                        echo "<td> <a href='alterar_bloqueio_avaliacao.php?id=$id&bloqueado=$bloqueado' />$strBloqueado"
                             . "</td>";
                        $bolAvaliacao = true;
                        foreach ($avaliacoes as $avaliacao) {
                            if ($avaliacao->getStatus() == 0) {
                                $bolAvaliacao = false;
                            }
                        }
                        if (empty($avaliacoes)) {
                            echo "<td></td>";
                        } else {
                            if ($bolAvaliacao) {
                                echo "<td><a href='validar_avaliacao.php?id=$id'>Validadas</a></td>";
                            } else {
                                echo "<td><a href='validar_avaliacao.php?id=$id'>Clique</a></td>";
                            }
                        }
                    } else {
                        if ($atividade->getBloqueado() == 0) {
                            echo "<td>Bloqueado</td>";
                        } else {
                            $avaliacao = $AvaliacaoMySqlDAO->queryByIdPessoaIdAtividade(
                                    $_SESSION["usuario"]->getIdPessoa(), $id);
                            if (!$avaliacao[0]) {
                                echo "<td> <a href='preencher_avaliacao.php?id=$id'>Preencha</a></td>";
                            }
                            elseif ($avaliacao[0]->getStatus()) {
                                $idAvaliacao = $avaliacao[0]->getId();
                                echo "<td> <a href='ver_avaliacao.php?id=$idAvaliacao'>Validada</a></td>";
                            } else {
                                $idAvaliacao = $avaliacao[0]->getId();
                                echo "<td> <a href='ver_avaliacao.php?id=$idAvaliacao'>Não-validada</a></td>";
                            }
                        }
                    }
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "Não há atividades cadastradas!";
                if ($permissao == "coordenador") {
                    echo " Cadastre uma atividade usando o formulário abaixo.";
                }
            }
            if ($permissao == "coordenador") {
                ?>
            <h4>Formulário de cadastro de atividades</h4>
            <form action="proc_cadastrar_atividade.php" method="POST" name="form">
                <input type="hidden" name="evento" value="<?php echo $_GET["id"]; ?>" />
                Nome: (*) <input type="text" name="nome" value=<?php echo '"' . $_SESSION["atividadeSession"]["nome"]
                                                                          . '"'; ?> />
                Horas de extensão: (*) <input type="text" name="horaExtensao" size="4"
                                              value=<?php echo '"' . $_SESSION["atividadeSession"]["horaExtensao"]
                                                               . '"';
                                                    ?>
                                       />
                Categoria:
                <select name="categoria">
                    <?php
                        foreach ($categorias as $categoria)
                        {
                            if ($_SESSION["atividadeSession"]["categoria"] != $categoria->getId())
                            {
                                echo "<option value=" . $categoria->getId(). ">" . $categoria->getNome() . "</option>";
                            }
                            else
                            {
                                echo "<option value=" . $categoria->getId() . "selected='selected'>"
                                     . $categoria->getNome() . "</option>";
                            }
                        }
                    ?>
                </select>
                <br />
                <br />
				Data: (*) <input type="text" name="data" maxlength="10" size="10" id="data" readonly
                                 value=<?php echo '"' . $_SESSION["atividadeSession"]["data"] . '"'; ?> />
                <img src="./includes/imagens/calendario1.png" alt="data" id="dataBt" />
                <script type="text/javascript">
                    Calendar.setup({
                        trigger: "dataBt",
                        inputField: "data",
                        onSelect: function() { this.hide() },
                        bottomBar: false,
                        fdow: 0,
                        min: <?php echo $minDate; ?>,
                        max: <?php echo $maxDate; ?>,
                        dateFormat: "%d/%m/%Y"
                    });
                </script>
				&nbsp;
				&nbsp;
				&nbsp;
                Início: (*) <input type="text" name="horaInicial" maxlength="5" size="5"
                                   value=<?php echo '"' . $_SESSION["atividadeSession"]["horaInicial"] . '"'; ?> />
								   &nbsp;
								   &nbsp;
								   &nbsp;
                Término: (*) <input type="text" name="horaFinal" maxlength="5" size="5"
                                    value=<?php echo '"' . $_SESSION["atividadeSession"]["horaFinal"] . '"'; ?> />
				<br />
				<br />
                Responsável:
                <select name="seletorPalestrante" onchange='if (this.value=="Interno") {
                    document.form.interno.style.display = ""; document.form.externo.style.display = "none"; } else {
                    document.form.externo.style.display = ""; document.form.interno.style.display = "none"; }
                    return true;'>
                    <?php
                        if ($_SESSION["atividadeSession"]["seletorPalestrante"] == "Interno") {
                            echo "<option value='Interno' selected='selected'>Interno</option>";
                            echo "<option value='Externo'>Externo</option>";
                        } elseif ($_SESSION["atividadeSession"]["seletorPalestrante"] == "Externo") {
                            echo "<option value='Interno'>Interno</option>";
                            echo "<option value='Externo' selected='selected'>Externo</option>";
                        } else {
                            echo "<option value='Interno'>Interno</option>";
                            echo "<option value='Externo'>Externo</option>";
                        }
                    ?>
                </select>
                <?php
                if (!isset($_SESSION["atividadeSession"]["seletorPalestrante"]) ||
                    $_SESSION["atividadeSession"]["seletorPalestrante"] == "Interno") {
                    echo "<select name='interno'>";
                }
                else
                {
                    echo "<select name='interno' style='display:none'>";
                }
                echo "<option value=''> - </option>";
                foreach ($internos as $interno) {
                    $idInterno = $interno->getIdPessoa();
                    $nomeInterno = $interno->getNome();
                    if ($_SESSION["atividadeSession"]["interno"] != $idInterno) {
                        echo "<option value= $idInterno> $nomeInterno </option>";
                    } else {
                        echo "<option value= $idInterno selected='selected'> $nomeInterno </option>";
                    }
                }
                echo "</select>";
                if ($_SESSION["atividadeSession"]["seletorPalestrante"] == "Externo") {
                    echo "<select name='externo'>";
                }
                else
                {
                    echo "<select name='externo' style='display:none'>";
                }
                echo "<option value=''> - </option>";
                foreach ($externos as $externo)
                {
                    $idExterno = $externo->getId();
                    $nomeExterno = $externo->getNome();
                    if ($_SESSION["atividadeSession"]["externo"] != $idExterno) {
                        echo "<option value = $idExterno> $nomeExterno </option>";
                    }
                    else
                    {
                        echo "<option value = $idExterno selected='selected'> $nomeExterno </option>";
                    }
                }
                echo "</select>";
                ?>
                <br />
                <br />
                Espaço
                <select name="espaco" onchange='if (this.value=="Customizado") { 
                    document.form.customEspaco.style.display = ""; } else {
                    document.form.customEspaco.style.display = "none";
                    document.form.customEspaco.value="";} return true;'>
                    <?php
                        foreach ($espacos as $espaco) {
                            $idEspaco = $espaco->getIdEspaco();
                            $nomeEspaco = $espaco->getNome();
                            $capacidadeEspaco = $espaco->getCapacidade();
                            if ($_SESSION["atividadeSession"]["espaco"] != $nomeEspaco) {
                                echo "<option value=$idEspaco >$nomeEspaco($capacidadeEspaco pessoas)</option>";
                            } else {
                                echo "<option value=$idEspaco selected='selected'>$nomeEspaco"
                                . "($capacidadeEspaco pessoas)</option>";
                            }
                        }
                        if ($_SESSION["atividadeSession"]["espaco"] != 'Customizado') {
                            echo "<option value='Customizado'>Customizado</option>";
                        } else {
                            echo "<option value='Customizado' selected='selected'>Customizado</option>";
                        }
                    ?>
                </select>
                <?php
                    if ($_SESSION["atividadeSession"]["customEspaco"] == '') {
                        echo '<input type="text" name="customEspaco" size=50 style="display:none;">';
                    } else {
                        echo "<input type='text' name='customEspaco' size=50 selected='selected'>";
                    }
                ?>
                <br />
                <br />
                <input type="submit" value="Cadastrar" name="submit"
                       onclick='return confirm("Deseja confirmar a inclusão?");'/>
        <input type="button" value="Voltar" onclick="window.location='manter_evento.php?pag=1'" />
            </form>
            <?php
                }
            ?>
            <br />
            <?php
                if ($permissao == "coordenador")
                {
                    include($BASE_DIR . "/sce/includes/legenda.html");
                }
            ?>
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
            unset($_SESSION["atividadeSession"]);
        ?>
</body>
</html>