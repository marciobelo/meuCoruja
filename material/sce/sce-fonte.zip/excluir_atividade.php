<?php 
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");

    $id = $_GET["id"];
    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDao;
    $AvaliacaoAspectoMySqlDAO = new AvaliacaoAspectoMySqlDao;
    $avaliacoes = $AvaliacaoMySqlDAO->queryByIdAtividade($id);
    if ($avaliacoes)
    {
        foreach ($avaliacoes as $avaliacao)
        {
            $avaliacoesaspecto = $AvaliacaoAspectoMySqlDAO->queryByIdAvaliacao($avaliacao->getId());
            foreach ($avaliacoesaspecto as $avaliacaoaspecto)
            {
                $AvaliacaoAspectoMySqlDAO->delete($avaliacaoaspecto->getId());
            }
            $AvaliacaoMySqlDAO->delete($avaliacao->getId());
        }
    }
    $Atividade = $AtividadeMySqlDAO->load($id);
    $evento = $Atividade->getIdEvento();
    $Atividade = $AtividadeMySqlDAO->delete($id);

    if($Atividade == 0)
    {
        trigger_error(mysql_error(), E_USER_ERROR);
    }
    else
    {
        $_SESSION["sucesso"] = "Exclus�o efetuada com sucesso";
        header("Location: detalhe_evento.php?id=$evento&pag=1");
    }
?>