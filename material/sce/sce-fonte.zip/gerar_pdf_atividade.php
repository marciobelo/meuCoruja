<?php

    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
	require_once ("./includes/fpdf/fpdf.php");
    require_once ("./includes/require_atividade.php");
    require_once ("./includes/require_evento.php");
    require_once ("./includes/require_pessoa.php");

    if ($permissao != 'coordenador')
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
	
	class PDF extends FPDF
	{

        function Header()
        {
            global $BASE_DIR;
            $urlImage = $BASE_DIR . '/sce/includes/imagens/logoist.jpg';
            $this->Image($urlImage,10,8,191,21);
            $this->SetFont('Arial','BU',35);

            $this->Ln(30);
            $this->Cell(80);
            $this->Cell(110,10,'Certificado de Extensão',0,0,'C');
            $this->Ln(25);
        }


	}

    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $EventoMySqlDAO = new EventoMySqlDao;
    $atividade = $AtividadeMySqlDAO->load($_GET["id"]);
    $nomeAtividade = $atividade->getNome();
    $dataAtividade = $atividade->getData();
    $idEvento = $atividade->getIdEvento();
    $evento = $EventoMySqlDAO->load($idEvento);
    $nomeEvento = $evento->getNome();
    $PessoaMySqlDAO = new PessoaMySqlDAO();
    $pessoa =  $PessoaMySqlDAO->load($_GET["aluno"]);
    $aluno = $pessoa->getNome();
    $intHoras += $atividade->getHoraExtensao();
    
    $arrMeses = array('1' => 'Janeiro',
                      '2' => 'Fevereiro',
                      '3' => 'Março',
                      '4' => 'Abril',
                      '5' => 'Maio',
                      '6' => 'Junho',
                      '7' => 'Julho',
                      '8' => 'Agosto',
                      '9' => 'Setembro',
                      '10' => 'Outubro',
                      '11' => 'Novembro',
                      '12' => 'Dezembro');
    
    $arrData = explode('-', $dataAtividade);
    $dataAtividade = $arrData[2] . ' de ' . $arrMeses[$arrData[1]] . ' de ' . $arrData[0];
    
    $dataAtual = date('Y-n-d');
    $arrDataAtual = explode('-', $dataAtual);
    $dataAtual = $arrDataAtual[2] . ' de ' . $arrMeses[$arrDataAtual[1]] . ' de ' . $arrDataAtual[0];
    
	//Instanciation of inherited class
	$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage('L');
    $pdf->SetFont('Times','',20);
    $pdf->Cell(0,0,'O INSTITUTO SUPERIOR DE TECNOLOGIA DA CIDADE DO RIO DE JANEIRO ',0,1, 'C');
    $pdf->Ln(10);
    $pdf->Cell(0,10,'certifica para os devidos fins que ',0,1, 'C');
    $pdf->Ln(5);
    $pdf->SetFont('Times','BUI',20);
    $pdf->Cell(0,10,$aluno,0,1, 'C');
    $pdf->Ln(6);
    $pdf->SetFont('Times','',20);
    $pdf->MultiCell(0,7,'participou da atividade ' . $nomeAtividade . ' no evento ' . $nomeEvento 
                    . ' realizada no Instituto Superior de Tecnologia do Rio de Janeiro, localizado na' 
                    . ' FAETEC - Quintino, no dia ' . $dataAtividade . ', ganhando ' 
                    . $intHoras . ' horas de extensão',0,'C', 0);
    $pdf->Ln(20);
    $pdf->SetFont('Times','B',20);
    $pdf->Cell(0,10,'Rio de Janeiro, ' . $dataAtual ,0,1, 'R');
    $pdf->SetFont('Times','',20);
    $pdf->Ln(8);
    $pdf->Cell(310,10,'___________________________       ___________________________' ,0,1, 'C');
    $pdf->SetFont('Times','',14);
    $pdf->Cell(253,3,'Ronaldo Ribeiro Goldschmidt                                       Márcio F. Campos ' ,0,1, 'C');
    $pdf->Cell(243,10,'Coordenador de Pesquisa e Extensão                           Diretor Geral ' ,0,1, 'C');
	$pdf->Output();


?>