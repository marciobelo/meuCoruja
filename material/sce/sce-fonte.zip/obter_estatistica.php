<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_evento.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once($BASE_DIR . "/sce/includes/require_tema.php");
    require_once($BASE_DIR . "/sce/includes/require_categoriaevento.php");

    $tot = 10;

    $PessoaMySqlDAO = new PessoaMySqlDao;
    $TemaMySqlDAO = new TemaMySqlDao;
    $temas = $TemaMySqlDAO->queryAll();
    $CategoriaEventoMySqlDAO = new CategoriaEventoMySqlDao;
    $categorias = $CategoriaEventoMySqlDAO->queryAll();
    $EventoMySqlDAO = new EventoMySqlDao;
    $eventos = $EventoMySqlDAO->queryAllOrderByPage("dtInicial DESC", (int)$_GET["pag"], $tot);
    $count = $EventoMySqlDAO->count();
    $count = $count[0][0];
?>
<head>
    <meta http-equiv="Content-Type" content="text/html" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/jscal2.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/border-radius.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/steel/steel.css" />
    <script type="text/javascript" src="./javascript/jscal2/js/jscal2.js"></script>
    <script type="text/javascript" src="./javascript/jscal2/js/lang/pt.js"></script>
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                if ($eventos)
                {
                ?>
            <h4>Lista de eventos cadastrados</h4>
                <?php
                    if ($_GET["pag"] != 1)
                    {
                        $ant = $_GET["pag"]-1;
                        echo "<a href='manter_evento.php?pag=1' ><< </a>";
                        echo "<a href='manter_evento.php?pag=$ant' >< </a>";
                    }
                    $ultima = floor($count / $tot);

                    if ($ultima != 0 && $_GET["pag"] != $ultima)
                    {
                        $prox = $_GET["pag"]+1;
                        echo "<a href='manter_evento.php?pag=$ultima' style='float:right; padding-right: 10px;'> "
                             . "&nbsp; >></a>";
                        echo "<a href='manter_evento.php?pag=$prox' style='float:right;'> > </a>";
                    }
                ?>
            <table class="tabDados">
                <tr>
                    <th>Nome</th>
                    <th>Datas</th>
                    <th>Categoria</th>
                    <th>Coordenador</th>
                    <th>Atividades</th>
                </tr>
                    <?php
                        foreach ($eventos as $evento)
                        {
                            echo "<tr>";
                            echo "<td>" . $evento->getNome() . "</td>";
                            echo "<td>" . date("d/m/Y",strtotime($evento->getDtInicial())) . " - "
                                 . date("d/m/Y",strtotime($evento->getDtFinal())) . "</td>";
                            $categoria = $CategoriaEventoMySqlDAO->load($evento->getIdCategoriaEvento());
                            echo "<td>" . $categoria->getNome() . "</td>";
                            $pessoa = $PessoaMySqlDAO->load($evento->getIdPessoa());
                            echo "<td>" . $pessoa->getNome() . "</td>";
                            $id = $evento->getId();
                            echo "<td> <a href='atividade_estatistica.php?id=$id&pag=1'>Clique</a> </td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    }
                    else
                    {
                        echo "N�o h� eventos cadastrados! Cadastre um evento usando o formul�rio abaixo.";
                    }
                ?>
            </table>
            <input type='button' value='Voltar' onclick='window.location="index.php"' />
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
        ?>
</body>
</html>