<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao == "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");
    require_once($BASE_DIR . "/sce/includes/require_aspecto.php");
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");

    $idAtividade = $_POST["idAtividade"];

    $AtividadeMySqlDAO = new AtividadeMySqlDAO();
    $atividade = $AtividadeMySqlDAO->load($idAtividade);
    $idEvento = $atividade->getIdEvento();

    $AspectoMySqlDAO = new AspectoMySqlDAO();
    $aspectos = $AspectoMySqlDAO->queryAll();

    $Avaliacao = new Avaliacao();
    $Avaliacao->setSugestao( $_POST["sugestao"] );
    $Avaliacao->setSugestaoEvento( $_POST["sugestaoevento"] );
    $Avaliacao->setIdAtividade( (int)$_POST["idAtividade"] );
    $Avaliacao->setIdPessoa($_SESSION["usuario"]->getIdPessoa());
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
    $Avaliacao = $AvaliacaoMySqlDAO->insert( $Avaliacao );
    $AvaliacaoAspectoMySqlDAO = new AvaliacaoAspectoMySqlDAO();
    foreach ($aspectos as $aspecto)
    {
        $AvaliacaoAspecto = new AvaliacaoAspecto();
        $AvaliacaoAspecto->setIdAvaliacao($Avaliacao);
        $AvaliacaoAspecto->setIdAspecto($aspecto->getId());
        $AvaliacaoAspecto->setResposta((int)$_POST[$aspecto->getNome()]);
        $AvaliacaoAspecto = $AvaliacaoAspectoMySqlDAO->insert ( $AvaliacaoAspecto );
    }
    if ($Avaliacao==0)
    {
        trigger_error(mysql_error());
    }
    else
    {
        $_SESSION["sucesso"] = "Avalia��o cadastrada com sucesso";
        header("Location: ver_avaliacao.php?id=$Avaliacao");
    }
?>