<?php
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_aspecto.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");

    $id = $_GET["id"];
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDao;
    $AspectoMySqlDAO = new AspectoMySqlDao;
    $AvaliacaoAspectoMySqlDAO = new AvaliacaoAspectoMySqlDao;
    $avaliacoesaspecto = $AvaliacaoAspectoMySqlDAO->queryByIdAspecto($id);
    foreach ($avaliacoesaspecto as $avaliacaoaspecto)
    {
        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdAvaliacaoAspecto($avaliacao->getId());
        foreach ($avaliacoes as $avaliacao)
        {
            $AvaliacaoMySqlDAO->delete($Avaliacao->getId());
        }
        $AvaliacaoAspectoMySqlDAO->delete($AvaliacaoAspecto->getId());
    }
    $Aspecto = $AspectoMySqlDAO->delete($id);

    if($Aspecto == 0)
    {
        trigger_error(mysql_error(), E_USER_ERROR);
    }
    else
    {
        $_SESSION["sucesso"] = "Exclus�o efetuada com sucesso";
        header("Location: manter_aspecto.php");
    }
?>