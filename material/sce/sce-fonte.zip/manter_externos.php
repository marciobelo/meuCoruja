<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_externo.php");

    $tot = 10;

    $ExternoMySqlDAO = new ExternoMySqlDao;
    $externos = $ExternoMySqlDAO->queryAllByPage((int)$_GET["pag"], $tot);
    $count = $ExternoMySqlDAO->count();
    $count = $count[0][0];
?>
<head>
    <meta http-equiv="Content-Type" content="text/html" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/jscal2.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/border-radius.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/steel/steel.css" />
    <script type="text/javascript" src="./javascript/jscal2/js/jscal2.js"></script>
    <script type="text/javascript" src="./javascript/jscal2/js/lang/pt.js"></script>
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                if ($externos)
                {
                ?>
            <h4>Lista de externos cadastrados</h4>
                <?php
                    if ($_GET["pag"] != 1)
                    {
                        $ant = $_GET["pag"]-1;
                        echo "<a href='manter_externos.php?pag=1' ><< </a>";
                        echo "<a href='manter_externos.php?pag=$ant' >< </a>";
                    }
                    $ultima = floor($count / $tot);

                    if ($ultima != 0 && $_GET["pag"] != $ultima)
                    {
                        $prox = $_GET["pag"]+1;
                        echo "<a href='manter_externos.php?pag=$ultima' style='float:right; padding-right: 10px;'> "
                            . "&nbsp; >></a>";
                        echo "<a href='manter_externos.php?pag=$prox' style='float:right;'> > </a>";
                    }
                ?>
            <table class="tabDados">
                <tr>
                    <th>Nome</th>
                    <th>Institui��o</th>
                    <th>Telefone</th>
                    <th>E-mail</th>
                    <th>Alterar</th>
                    <th>Excluir</th>
                </tr>
                    <?php
                        foreach ($externos as $externo)
                        {
                            echo "<tr>";
                            echo "<td>" . $externo->getNome() . "</td>";
                            echo "<td>" . $externo->getInstituicao() . "</td>";
                            echo "<td>" . $externo->getTelefone() . "</td>";
                            echo "<td>" . $externo->getEmail() . "</td>";
                            $id = $externo->getId();
                            echo "<td> <a href='alterar_externo.php?id=$id'>Clique</a> </td>";
                            echo "<td> <a href='excluir_externo.php?id=$id' "
                                . "onclick='return confirm(\"Deseja realmente excluir o externo?\")'>Clique</a> </td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    }
                    else
                    {
                        echo "N�o h� externos cadastrados! Cadastre um externo usando o formul�rio abaixo.";
                    }
                ?>
                <h4>Formul�rio de cadastro de externo</h4>
                <form action="proc_cadastrar_externo.php" method="POST">
                    Nome: (*) <input type="text" name="nome" value=<?php echo '"' . $_SESSION["externoSession"]["nome"] . '"' ?> />
                    Institui��o: (*) <input type="text" name="instituicao" value=<?php echo '"' . $_SESSION["externoSession"]["instituicao"] . '"' ?> />
                    Telefone: <input type="text" name="telefone" value=<?php echo '"' . $_SESSION["externoSession"]["telefone"] . '"' ?> />
                    E-mail: <input type="text" name="email" value=<?php echo '"' . $_SESSION["externoSession"]["email"] . '"' ?> />
            <br />
            <br />
                    <input type='submit' value='Cadastrar' name='submit'
                        onclick='return confirm("Deseja confirmar a inclus�o?");'/>
                    <input type='button' value='Voltar' onclick='window.location="index.php"' />
                </form>
                <br />
                <?php
                    include($BASE_DIR . "/sce/includes/legenda.html");
                ?>
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
            unset($_SESSION["externoSession"]);
        ?>
</body>
</html>