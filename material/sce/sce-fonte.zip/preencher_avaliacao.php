<?php
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao == "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once ($BASE_DIR . "/sce/includes/require_aluno.php");
    require_once ($BASE_DIR . "/sce/includes/require_matriculaprofessor.php");
    require_once ($BASE_DIR . "/sce/includes/require_matriculaaluno.php");
    require_once ($BASE_DIR . "/sce/includes/require_professor.php");
    require_once ($BASE_DIR . "/sce/includes/require_aspecto.php");

    $idAtividade = $_GET["id"];
    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    
    $atividade = $AtividadeMySqlDAO->load($_GET["id"]);
    $idEvento = $atividade->getIdEvento();
    
    $PessoaMySqlDAO = new PessoaMySqlDao;
    $AspectoMySqlDAO = new AspectoMySqlDAO;
    $aspectos = $AspectoMySqlDAO->queryAll();

    $AlunoMySqlDAO = new AlunoMySqlDAO();
    $ProfessorMySqlDAO = new ProfessorMySqlDAO();

    if (!is_null($AlunoMySqlDAO->load($_SESSION["usuario"]->getIdPessoa())->getIdPessoa()))
    {
        $cond = "aluno";
        $MatriculaAlunoMySqlDAO = new MatriculaAlunoMySqlDAO();
        $matricula = $MatriculaAlunoMySqlDAO->queryByIdPessoa($_SESSION["usuario"]->getIdPessoa());
    }
    elseif (!is_null($ProfessorMySqlDAO->load($_SESSION["usuario"]->getIdPessoa())->getIdPessoa()))
    {
        $cond = "professor";
        $MatriculaProfessorMySqlDAO = new MatriculaProfessorMySqlDAO();
        $matricula = $MatriculaProfessorMySqlDAO->queryByIdPessoa($_SESSION["usuario"]->getIdPessoa());
    }

    $pessoa = $PessoaMySqlDAO->load($_SESSION["usuario"]->getIdPessoa());
    $nome = $pessoa->getNome();

    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
    <?php
        include($BASE_DIR . "/sce/includes/menu.html");
        include($BASE_DIR . "/sce/includes/mensagem.php");
    ?>
        <div id="mainContent">
            <h4>Formulário de cadastro de avaliações</h4>
            <form action="proc_preencher_avaliacao.php" method="POST">
                <input type="hidden" name="idAtividade" value="<?php echo $idAtividade; ?>">
                <b>Nome:</b> <?php echo $nome; ?>
                <br />
                <br />
                <?php
                    if (is_array($matricula))
                    {
                        echo "<b>Matrículas: </b>";
                        foreach ($matricula as $key => $mat)
                        {
                            if ($key == 0)
                            {
                                if ($cond == "aluno")
                                {
                                    echo $mat->getMatriculaAluno();
                                }
                                elseif ($cond == "professor")
                                {
                                    echo $mat->getMatriculaProfessor();
                                }
                            }
                            else
                            {
                                if ($cond == "aluno")
                                {
                                    echo " / " . $mat->getMatriculaAluno();
                                }
                                elseif ($cond == "professor")
                {
                    echo " / " . $mat->getMatriculaProfessor();
                                }
                            }
                        }
                    }
                    else
                    {
                        echo "<b>Matrícula: </b>";
                        echo $matricula;
                    }
                ?>
                <br />
                <br />
                <?php
                    foreach ($aspectos as $aspecto)
                    {
                        echo $aspecto->getNome();
                                                        echo "<br />";
                        echo "<input type='radio' name='" . $aspecto->getNome() 
                             . "'value='0' checked=true />"
                             . " <img alt='Péssimo' title='Péssimo' src='./includes/imagens/pessimo.png' /> <br />";
                        echo "<input type='radio' name='" . $aspecto->getNome() 
                             . "'value='1' />"
                             . " <img alt='Ruim' title='Ruim' src='./includes/imagens/ruim.png' /> <br />";
                        echo "<input type='radio' name='" . $aspecto->getNome() 
                             . "'value='2' />"
                             . " <img alt='Regular' title='Regular' src='./includes/imagens/regular.png' /> <br />";
                        echo "<input type='radio' name='" . $aspecto->getNome() 
                             . "'value='3' />"
                             . " <img alt='Bom' title='Bom' src='./includes/imagens/bom.png' /> <br />";
                        echo "<input type='radio' name='" . $aspecto->getNome() 
                             . "'value='4' />"
                             . " <img alt='Ótimo' title='Ótimo' src='./includes/imagens/otimo.png' />";
                        echo "<br />";
                        echo "<br />";
                    }
                ?>
                Sugestão:
                <br />
                <textarea rows="6" cols="70" name="sugestao"></textarea>
                <br />
                <br />
                Sugestão de evento:
                <br />
                <textarea rows="6" cols="70" name="sugestaoevento"></textarea>
                <br />
                <br />
                <input type="submit" value="Cadastrar" name="submit"
                       onclick="return confirm('Deseja realmente enviar a avaliação?')" />
        <input type='button' value='Voltar'
                       onclick='window.location="detalhe_evento.php?id=<?php echo $idEvento; ?>"' />
            </form>
<?php
    include($BASE_DIR . "/sce/includes/legenda.html");
?>
    <br />
    <img alt='Péssimo' title='Péssimo' src='./includes/imagens/pessimo.png' /> Péssimo
    <br />
    <img alt='Ruim' title='Ruim' src='./includes/imagens/ruim.png' /> Ruim
    <br />
    <img alt='Regular' title='Regular' src='./includes/imagens/regular.png' /> Regular
    <br />
    <img alt='Bom' title='Bom' src='./includes/imagens/bom.png' /> Bom
    <br />
    <img alt='Ótimo' title='Ótimo' src='./includes/imagens/otimo.png' /> Ótimo
    <br />
</div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>