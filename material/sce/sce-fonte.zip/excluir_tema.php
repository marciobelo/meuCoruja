<?php
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_evento.php");
    require_once ($BASE_DIR . "/sce/includes/require_tema.php");

    $id = $_GET["id"];
    $TemaMySqlDAO = new TemaMySqlDao;
    $EventoMySqlDAO = new EventoMySqlDao;
    $eventos = $EventoMySqlDAO->queryByIdTema($id);
    foreach ($eventos as $evento)
    {
        $atividades = $AtividadeMySqlDAO->queryByIdEvento($evento->getId());
        $EventoMySqlDAO->delete($evento->getId());
    }
    $Tema = $TemaMySqlDAO->delete($id);
    
    if ($Tema == 0) {
        trigger_error(mysql_error(), E_USER_ERROR);
    }
    else
    {
        $_SESSION["sucesso"] = "Exclus�o efetuada com sucesso";
        header("Location: manter_tema.php");
    }
?>