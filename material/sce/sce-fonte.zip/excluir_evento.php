<?php 
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_evento.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");

    $id = $_GET["id"];
    $EventoMySqlDAO = new EventoMySqlDao;
    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDao;
    $AvaliacaoAspectoMySqlDAO = new AvaliacaoAspectoMySqlDao;
    $atividades = $AtividadeMySqlDAO->queryByIdEvento($id);
    foreach ($atividades as $atividade)
    {
        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdAtividade($atividade->getId());
        foreach ($avaliacoes as $avaliacao)
        {
            $avaliacoesaspecto = $AvaliacaoAspectoMySqlDAO->queryByIdAvaliacao($avaliacao->getId());
            foreach ($avaliacoesaspecto as $avaliacaoaspecto)
            {
                $AvaliacaoAspectoMySqlDAO->delete($avaliacaoaspecto->getId());
            }
            $AvaliacaoMySqlDAO->delete($avaliacao->getId());
        }
        $AtividadeMySqlDAO->delete($atividade->getId());
    }
    $Evento = $EventoMySqlDAO->delete($id);
    if($Evento == 0)
    {
        trigger_error(mysql_error(), E_USER_ERROR);
    }
    else
    {
        $_SESSION["sucesso"] = "Exclus�o efetuada com sucesso";
        header("Location: manter_evento.php?pag=1");
    }
?>