<?php
    require_once ("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }

    require_once($BASE_DIR . "/sce/includes/require_tema.php");
    require_once($BASE_DIR . "/sce/includes/require_evento.php");
    
    $TemaMySqlDAO = new TemaMySqlDao;
    $temas = $TemaMySqlDAO->queryAll();
    
    $EventoMySqlDAO = new EventoMySqlDao;

    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
<?php
    include($BASE_DIR . "/sce/includes/menu.html");
    include($BASE_DIR . "/sce/includes/mensagem.php");
?>
        <div id="mainContent">
            <h4>Temas</h4>
<?php
    if($temas)
    {
?>
            <table>
                <tr>
                    <th>Nome</th>
                    <th>Alterar</th>
                    <th>Excluir</th>
                </tr>
<?php
    foreach ($temas as $tema)
    {
        echo "<tr>";
        echo "<td>" . $tema->getNome() . "</td>";
        $id = $tema->getId();
        echo "<td> <a href='alterar_tema.php?id=$id'>Clique</a> </td>";
        $deletavel = $EventoMySqlDAO->queryByIdTema($id);
            if (!empty($deletavel))
            {
                echo "<td> <a href='excluir_tema.php?id=$id' "
                     . "onclick='return confirm(\"Deseja realmente excluir o tema? Os eventos vinculados tamb�m ser�o "
                     . "exclu�dos.\")'>Clique</a> </td>";
            }
            else
            {
                echo "<td> <a href='excluir_tema.php?id=$id' "
                     . "onclick='return confirm(\"Deseja realmente excluir o tema?\")'>Clique</a> </td>";
            }
        echo "</tr>";
    }
    echo "</table>";
    echo "<br>";
    }
    else
    {
        echo "N�o h� temas cadastrados! Cadastre um tema usando o formul�rio abaixo.";
    }
?>
                <form action="proc_cadastrar_tema.php" method="post" name="cadastro_tema">
                    Nome: (*) <input name="nome" type="text" />
                    <input type="submit" value="Cadastrar" name="enviar" />
                    <input type='button' value='Voltar' onclick='window.location="index.php"' />
                </form>
<?php
    include($BASE_DIR . "/sce/includes/legenda.html");
?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>