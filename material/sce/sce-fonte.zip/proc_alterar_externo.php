<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_externo.php");

    $Externo = new externo();
    $ExternoMySqlDAO = new ExternoMySqlDAO();
    $Externo = $ExternoMySqlDAO->load($_POST["id"]);
    if (!$_POST["nome"] || !$_POST["instituicao"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        $id = $_POST["id"];
        header("Location: alterar_externo.php?id=$id");
        break;
    }
    else
    {
        $Externo->setNome( $_POST["nome"] );
        $Externo->setInstituicao( $_POST["instituicao"] );
        $Externo->setTelefone( $_POST["telefone"] );
        $Externo->setEmail( $_POST["email"] );
        $Externo = $ExternoMySqlDAO->update( $Externo );
    }

    $_SESSION["sucesso"] = "Altera��o efetuada com sucesso!";
    header("Location: manter_externos.php?pag=1");
?>
