<?php
    require_once ("../includes/comum.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador") {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once($BASE_DIR . "/sce/includes/require_categoriaatividade.php");

    $CategoriaAtividadeMySqlDAO = new CategoriaAtividadeMySqlDao;
    $categoriaAtividade = $CategoriaAtividadeMySqlDAO->load($_GET["id"]);
    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <h4>Altera��o da categoria de atividade <?php echo $categoriaAtividade->getNome(); ?></h4>
            <form action="proc_alterar_categoria_atividade.php" method="post" name="alteracao_categoriaatividade">
                <input name="id" type="hidden" value=<?php echo $_GET["id"]; ?> />
        Nome: (*) <input name="nome" type="text" value="<?php echo $categoriaAtividade->getNome(); ?>" />
                <input type="submit" value="Cadastrar" name="enviar" />
        <input type="button" value="Voltar" onclick="window.location='manter_categoriaatividade.php'" />
            </form>
            <?php
                include($BASE_DIR . "/sce/includes/legenda.html");
            ?>
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
        ?>
</body>
</html>
