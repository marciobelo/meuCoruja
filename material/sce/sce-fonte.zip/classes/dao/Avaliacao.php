<?php
    require_once("../includes/comum.php");
    require_once("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela avaliacao
     * @author: Luiz Gilberto
     * @name: avaliacao.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class AvaliacaoMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return AvaliacaoMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM avaliacao WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM avaliacao';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM avaliacao ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param avaliacao chave prim�ria
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM avaliacao WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param AvaliacaoMySql avaliacao
         */
        public function insert($avaliacao)
        {
            $sql = 'INSERT INTO avaliacao (sugestao, sugestaoEvento, status, idPessoa, idAtividade) '
                 . 'VALUES (?, ?, ?, ?, ?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($avaliacao->getSugestao());
            $sqlQuery->set($avaliacao->getSugestaoEvento());
            $sqlQuery->set($avaliacao->getStatus());
            $sqlQuery->set($avaliacao->getIdPessoa());
            $sqlQuery->set($avaliacao->getIdAtividade());

            $id = $this->executeInsert($sqlQuery);
            $avaliacao->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param AvaliacaoMySql avaliacao
         */
        public function update($avaliacao)
        {
            $sql = 'UPDATE avaliacao SET sugestao = ?, sugestaoEvento = ?, status = ?, idPessoa = ?, idAtividade = ? '
                 . 'WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($avaliacao->getSugestao());
            $sqlQuery->set($avaliacao->getSugestaoEvento());
            $sqlQuery->setNumber($avaliacao->getStatus());
            $sqlQuery->set($avaliacao->getIdPessoa());
            $sqlQuery->set($avaliacao->getIdAtividade());

            $sqlQuery->setNumber($avaliacao->getid());
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE avaliacao';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Query por idPessoa
         ** @param string $value
         */
        public function queryByIdPessoa($value)
        {
            $sql = 'SELECT * FROM avaliacao WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }
        /**
         * Query por idAtividade
         ** @param string $value
         */
        public function queryByIdAtividade($value)
        {
            $sql = 'SELECT * FROM avaliacao WHERE idAtividade = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        /**
         * Query por atividade validada
         ** @param string $value
         */
        public function queryByIdAtividadeValidada($value)
        {
            $sql = 'SELECT * FROM avaliacao WHERE idAtividade = ? AND status = 1';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        /**
         * Query por pessoa e atividade
         * @param string $pessoa
         * @param string $atividade
         */
        public function queryByIdPessoaIdAtividade ($pessoa, $atividade)
        {
            $sql = 'SELECT * FROM avaliacao WHERE idPessoa = ? AND idAtividade = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($pessoa);
            $sqlQuery->set($atividade);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return AvaliacaoMySql
         */
        protected function readRow($row)
        {
            $avaliacao = new Avaliacao();

            $avaliacao->setid($row['id']);
            $avaliacao->setSugestao($row['sugestao']);
            $avaliacao->setSugestaoEvento($row['sugestaoEvento']);
            $avaliacao->setStatus($row['status']);
            $avaliacao->setIdPessoa($row['idPessoa']);
            $avaliacao->setIdAtividade($row['idAtividade']);

            return $avaliacao;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         ** @param string $value
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return AvaliacaoMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>