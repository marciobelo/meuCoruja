<?php
    require_once("../includes/comum.php");
    require_once("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela categoriaevento
     * @author: Luiz Gilberto
     * @name: categoriaevento.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class CategoriaEventoMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return CategoriaEventoMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM CategoriaEvento WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM CategoriaEvento';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM CategoriaEvento ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param CategoriaEvento chave prim�ria
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM CategoriaEvento WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param CategoriaEventoMySql CategoriaEvento
         */
        public function insert($CategoriaEvento)
        {
            $sql = 'INSERT INTO CategoriaEvento (nome) VALUES (?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($CategoriaEvento->getnome());

            $id = $this->executeInsert($sqlQuery);
            $CategoriaEvento->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param CategoriaEventoMySql CategoriaEvento
         */
        public function update($CategoriaEvento)
        {
            $sql = 'UPDATE CategoriaEvento SET nome = ? WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($CategoriaEvento->getnome());

            $sqlQuery->setNumber($CategoriaEvento->getid());
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE CategoriaEvento';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return CategoriaEventoMySql
         */
        protected function readRow($row)
        {
            $CategoriaEvento = new CategoriaEvento();

            $CategoriaEvento->setid($row['id']);
            $CategoriaEvento->setnome($row['nome']);

            return $CategoriaEvento;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return CategoriaEventoMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>