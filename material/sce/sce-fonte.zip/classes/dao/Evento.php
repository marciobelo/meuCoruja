<?php
    require_once("../includes/comum.php");
    require_once ("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela evento
     * @author: Luiz Gilberto
     * @name: evento.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class EventoMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return EventoMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM sce.evento WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        public function count()
        {
            $sql = 'SELECT COUNT(*) FROM evento';
            $sqlQuery = new SqlQuery($sql);
            return $this->execute($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM sce.evento';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM sce.evento ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param evento chave prim�ria
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM sce.evento WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param EventoMySql evento
         */
        public function insert($evento)
        {
            $sql = 'INSERT INTO sce.evento (nome, dtInicial, dtFinal, idCategoriaEvento, idTema, idPessoa) '
                 . 'VALUES (?, ?, ?, ?, ?, ?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($evento->getNome());
            $sqlQuery->set($evento->getDtInicial());
            $sqlQuery->set($evento->getDtFinal());
            $sqlQuery->set($evento->getidCategoriaEvento());
            $sqlQuery->set($evento->getidTema());
            $sqlQuery->set($evento->getIdPessoa());

            $id = $this->executeInsert($sqlQuery);
            $evento->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param EventoMySql evento
         */
        public function update($evento)
        {
            $sql = 'UPDATE sce.evento SET nome = ?, dtInicial = ?, dtFinal = ?, idCategoriaEvento = ?, idTema = ?, '
                 . 'idPessoa = ? WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($evento->getNome());
            $sqlQuery->set($evento->getDtInicial());
            $sqlQuery->set($evento->getDtFinal());
            $sqlQuery->set($evento->getidCategoriaEvento());
            $sqlQuery->set($evento->getidTema());
            $sqlQuery->set($evento->getIdPessoa());

            $sqlQuery->setNumber($evento->getid());
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE sce.evento';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Query para pagina��o
         * @param string $order
         * @param int $page
         * @param int $tot
         */
        public function queryAllOrderByPage($order, $page, $tot)
        {
            $infLimit = ($page*$tot) - $tot;
            $sql = 'SELECT * FROM sce.evento ORDER BY ? LIMIT ' . $infLimit . ', ' . $tot;
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($order);

            return $this->getList($sqlQuery);
        }

        /**
         * Query para categoria de evento
         * @param int $value
         */
        public function queryByIdCategoriaEvento($value)
        {
            $sql = 'SELECT * FROM sce.evento WHERE idCategoriaEvento = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        /**
         * Query para pagina��o
         * @param int $value
         */
        public function queryByIdTema($value)
        {
            $sql = 'SELECT * FROM sce.evento WHERE idTema = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return EventoMySql
         */
        protected function readRow($row)
        {
            $evento = new Evento();

            $evento->setid($row['id']);
            $evento->setNome($row['nome']);
            $evento->setDtInicial($row['dtInicial']);
            $evento->setDtFinal($row['dtFinal']);
            $evento->setidCategoriaEvento($row['idCategoriaEvento']);
            $evento->setidTema($row['idTema']);
            $evento->setIdPessoa($row['idPessoa']);

            return $evento;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return EventoMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>