<?php
    require_once("../includes/comum.php");
    require_once ("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela atividade
     * @author: Luiz Gilberto
     * @name: atividade.php
     * @version: 1.0
     * @since: versão 1.0
     */
    class AtividadeMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave primária
         *
         * @param int $id chave primária
         * @return AtividadeMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM atividade WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        public function countFromEvento($id)
        {
            $sql = 'SELECT COUNT(*) FROM atividade WHERE idEvento = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->execute($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM atividade';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM atividade ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param atividade chave primária
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM atividade WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param AtividadeMySql atividade
         */
        public function insert($atividade)
        {
            $sql = 'INSERT INTO atividade (nome, data, horaInicial, horaFinal, horaExtensao, idCategoriaAtividade, '
                 . 'idEvento, idPalestrante, tipoPalestrante, ';
            $i = 0;
            if ($atividade->getIdEspaco() != "Customizado" && $atividade->getIdEspaco() != "")
            {
                $sql .= 'idEspaco';
                $i++;
            } elseif ($atividade->getIdEspaco() == "Customizado")
            {
                $sql .= 'customEspaco';
                $i++;
            }

            $sql .= ') VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?';

            if ($i == 0)
            {
                $sql .= ')';
            }
            else
            {
                $sql .= ', ?)';
            }

            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($atividade->getNome());
            $sqlQuery->set($atividade->getData());
            $sqlQuery->set($atividade->getHoraInicial());
            $sqlQuery->set($atividade->getHoraFinal());
            $sqlQuery->setNumber($atividade->getHoraExtensao());
            $sqlQuery->set($atividade->getIdCategoriaAtividade());
            $sqlQuery->set($atividade->getIdEvento());
            if ($atividade->getIdPalestrante() == "")
            {
                $sqlQuery->set("NULL");
            }
            else
            {
                $sqlQuery->set($atividade->getIdPalestrante());
            }
            $sqlQuery->set($atividade->getTipoPalestrante());

            if ($atividade->getIdEspaco() == "Customizado")
            {
                $sqlQuery->set($atividade->getCustomEspaco());
            } else
            {
                $sqlQuery->set($atividade->getIdEspaco());
            }

            $id = $this->executeInsert($sqlQuery);
            $atividade->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param AtividadeMySql atividade
         */
        public function update($atividade)
        {
            $sql = 'UPDATE atividade SET nome = ?, horaExtensao = ?, idCategoriaAtividade = ?, idEvento = ?, '
                 . 'idPalestrante = ?, tipoPalestrante = ? WHERE id = ?';
            
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($atividade->getNome());
            $sqlQuery->setNumber($atividade->getHoraExtensao());
            $sqlQuery->set($atividade->getIdCategoriaAtividade());
            $sqlQuery->set($atividade->getIdEvento());
            $sqlQuery->set($atividade->getIdPalestrante());
            $sqlQuery->set($atividade->getTipoPalestrante());
            
            $sqlQuery->setNumber($atividade->getid());
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Atualiza o status de bloqueado de uma atividade
         *
         * @param int $id - id da atividade
         * @param boolean $bloqueado - status de bloqueado
         *
         * @access public
         * @return mixed
         */
        public function updateBloqueado($id, $bloqueado)
        {
            $sql = 'UPDATE atividade SET bloqueado = ? WHERE id = ?';

            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($bloqueado);
            $sqlQuery->setNumber($id);

            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE atividade';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        public function queryByNome($value)
        {
            $sql = 'SELECT * FROM atividade WHERE nome = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByData($value)
        {
            $sql = 'SELECT * FROM atividade WHERE data = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByHoraInicial($value)
        {
            $sql = 'SELECT * FROM atividade WHERE horaInicial = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByHoraFinal($value)
        {
            $sql = 'SELECT * FROM atividade WHERE horaFinal = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByHoraExtensao($value)
        {
            $sql = 'SELECT * FROM atividade WHERE horaExtensao = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($value);
            return $this->getList($sqlQuery);
        }

        public function queryByIdCategoriaAtividade($value)
        {
            $sql = 'SELECT * FROM atividade WHERE idCategoriaAtividade = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByIdEvento($value)
        {
            $sql = 'SELECT * FROM atividade WHERE idEvento = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByIdEventoOrderBy($value, $order)
        {
            $sql = 'SELECT * FROM atividade WHERE idEvento = ? ORDER BY '.$order;
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByIdEventoOrderByPage($value, $order, $page, $tot)
        {
            $infLimit = ($page*$tot) - $tot;
            $sql = 'SELECT * FROM atividade WHERE idEvento = ? ORDER BY ? LIMIT ' . $infLimit . ', ' . $tot;
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            $sqlQuery->set($order);

            return $this->getList($sqlQuery);
        }

        public function queryByIdPalestrante($value)
        {
            $sql = 'SELECT * FROM atividade WHERE idPalestrante = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function queryByIdEspaco($value)
        {
            $sql = 'SELECT * FROM atividade where idEspaco = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        public function deleteByNome($value)
        {
            $sql = 'DELETE FROM atividade WHERE nome = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByData($value)
        {
            $sql = 'DELETE FROM atividade WHERE data = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByHoraInicial($value)
        {
            $sql = 'DELETE FROM atividade WHERE horaInicial = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByHoraFinal($value)
        {
            $sql = 'DELETE FROM atividade WHERE horaFinal = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByHoraExtensao($value)
        {
            $sql = 'DELETE FROM atividade WHERE horaExtensao = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByIdCategoriaAtividade($value)
        {
            $sql = 'DELETE FROM atividade WHERE idCategoriaAtividade = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByIdEvento($value)
        {
            $sql = 'DELETE FROM atividade WHERE idEvento = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByIdPalestrante($value)
        {
            $sql = 'DELETE FROM atividade WHERE idPalestrante = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        public function deleteByIdEspaco($value)
        {
            $sql = 'DELETE FROM atividade WHERE idEspaco = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }


        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return AtividadeMySql
         */
        protected function readRow($row)
        {
            $atividade = new Atividade();

            $atividade->setId($row['id']);
            $atividade->setNome($row['nome']);
            $atividade->setData($row['data']);
            $atividade->setHoraInicial($row['horaInicial']);
            $atividade->setHoraFinal($row['horaFinal']);
            $atividade->setHoraExtensao($row['horaExtensao']);
            $atividade->setIdCategoriaAtividade($row['idCategoriaAtividade']);
            $atividade->setIdEvento($row['idEvento']);
            $atividade->setIdPalestrante($row['idPalestrante']);
            $atividade->setTipoPalestrante($row['tipoPalestrante']);
            $atividade->setIdEspaco($row['idEspaco']);
            $atividade->setCustomEspaco($row['customEspaco']);
            $atividade->setBloqueado($row['bloqueado']);

            return $atividade;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return AtividadeMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>