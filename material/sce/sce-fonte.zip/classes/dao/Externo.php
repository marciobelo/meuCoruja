<?php
    require_once("../includes/comum.php");
    require_once ("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela externo
     * @author: Luiz Gilberto
     * @name: externo.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class ExternoMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return ExternoMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM externo WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }
        
        /**
         * Retorna a contagem de todos os registros
         *
         * @return int
         */
        public function count()
        {
            $sql = 'SELECT COUNT(*) FROM externo';
            $sqlQuery = new SqlQuery($sql);
            return $this->execute($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM externo';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM externo ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param $id chave prim�ria
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM externo WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param ExternoMySql externo
         */
        public function insert($externo)
        {
            $sql = 'INSERT INTO externo (nome, instituicao, telefone, email) VALUES (?, ?, ?, ?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($externo->getNome());
            $sqlQuery->set($externo->getInstituicao());
            $sqlQuery->set($externo->getTelefone());
            $sqlQuery->set($externo->getEmail());

            $id = $this->executeInsert($sqlQuery);
            $externo->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param ExternoMySql externo
         */
        public function update($externo)
        {
            $sql = 'UPDATE externo SET nome = ?, instituicao = ?, telefone = ?, email = ? WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($externo->getNome());
            $sqlQuery->set($externo->getInstituicao());
            $sqlQuery->set($externo->getTelefone());
            $sqlQuery->set($externo->getEmail());

            $sqlQuery->setNumber($externo->getid());
            return $this->executeUpdate($sqlQuery);
        }

	/**
	 * Retorna todos os registros paginados
	 *
	 * @param int $page - p�gina a ser exibida
	 * @param int $tot - total de registros a serem exibidos
	 */
        public function queryAllByPage($page, $tot)
        {
            $infLimit = ($page*$tot) - $tot;
            $sql = 'SELECT * FROM externo LIMIT ' . $infLimit . ', ' . $tot;
            $sqlQuery = new SqlQuery($sql);

            return $this->getList($sqlQuery);
        }

        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE externo';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return externoMySql
         */
        protected function readRow($row)
        {
            $externo = new externo();

            $externo->setid($row['id']);

            $externo->setNome($row['nome']);
            $externo->setInstituicao($row['instituicao']);
            $externo->setTelefone($row['telefone']);
            $externo->setEmail($row['email']);

            return $externo;
        }
        
        /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return externoMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }

        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>