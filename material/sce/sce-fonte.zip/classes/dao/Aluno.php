<?php
    require_once("../includes/comum.php");
    require_once("$BASE_DIR/sce/includes/require_mysqldao.php");
    
    /**
     * Classe que opera na tabela aluno
     * @author: Luiz Gilberto
     * @name: aluno.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class AlunoMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return AlunoMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM Aluno WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM Aluno';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM Aluno ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Faz uma query por IdPessoa
         * @param int $value
         */
        public function queryByIdPessoa($value)
        {
            $sql = 'SELECT * FROM Aluno WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta o registro por um idPessoa
         * @param int $value
         */
        public function deleteByIdPessoa($value)
        {
            $sql = 'DELETE FROM Aluno WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return AlunoMySql
         */
        protected function readRow($row)
        {
            $aluno = new Aluno();

            $aluno->setIdPessoa($row['idPessoa']);
            $aluno->setNomeMae($row['nomeMae']);
            $aluno->setRgMae($row['rgMae']);
            $aluno->setNomePai($row['nomePai']);
            $aluno->setRgPai($row['rgPai']);
            $aluno->setRgNumero($row['rgNumero']);
            $aluno->setRgDataEmissao($row['rgDataEmissao']);
            $aluno->setRgOrgaoEmissor($row['rgOrgaoEmissor']);
            $aluno->setCpf($row['cpf']);
            $aluno->setCpfProprio($row['cpfProprio']);
            $aluno->setCertidaoNascimentoNumero($row['certidaoNascimentoNumero']);
            $aluno->setCertidaoNascimentoLivro($row['certidaoNascimentoLivro']);
            $aluno->setCertidaoNascimentoFolha($row['certidaoNascimentoFolha']);
            $aluno->setCertidaoNascimentoCidade($row['certidaoNascimentoCidade']);
            $aluno->setCertidaoNascimentoSubdistrito($row['certidaoNascimentoSubdistrito']);
            $aluno->setCertidaoNascimentoUF($row['certidaoNascimentoUF']);
            $aluno->setCertidaoCasamentoNumero($row['certidaoCasamentoNumero']);
            $aluno->setCertidaoCasamentoLivro($row['certidaoCasamentoLivro']);
            $aluno->setCertidaoCasamentoFolha($row['certidaoCasamentoFolha']);
            $aluno->setCertidaoCasamentoCidade($row['certidaoCasamentoCidade']);
            $aluno->setCertidaoCasamentoSubdistrito($row['certidaoCasamentoSubdistrito']);
            $aluno->setCertidaoCasamentoUF($row['certidaoCasamentoUF']);
            $aluno->setEstabCursoOrigem($row['estabCursoOrigem']);
            $aluno->setEstabCursoOrigemUF($row['estabCursoOrigemUF']);
            $aluno->setCursoOrigemAnoConclusao($row['cursoOrigemAnoConclusao']);
            $aluno->setModalidadeCursoOrigem($row['modalidadeCursoOrigem']);
            $aluno->setCtps($row['ctps']);
            $aluno->setCorRaca($row['corRaca']);
            $aluno->setEstadoCivil($row['estadoCivil']);
            $aluno->setDeficienciaVisual($row['deficienciaVisual']);
            $aluno->setDeficienciaMotora($row['deficienciaMotora']);
            $aluno->setDeficienciaAuditiva($row['deficienciaAuditiva']);
            $aluno->setDeficienciaMental($row['deficienciaMental']);
            $aluno->setResponsavelLegal($row['responsavelLegal']);
            $aluno->setRgResponsavel($row['rgResponsavel']);
            $aluno->setTituloEleitorNumero($row['tituloEleitorNumero']);
            $aluno->setTituloEleitorData($row['tituloEleitorData']);
            $aluno->setTituloEleitorZona($row['tituloEleitorZona']);
            $aluno->setTituloEleitorSecao($row['tituloEleitorSecao']);
            $aluno->setCertificadoAlistamentoMilitarNumero($row['certificadoAlistamentoMilitarNumero']);
            $aluno->setCertificadoAlistamentoMilitarSerie($row['certificadoAlistamentoMilitarSerie']);
            $aluno->setCertificadoAlistamentoMilitarData($row['certificadoAlistamentoMilitarData']);
            $aluno->setCertificadoAlistamentoMilitarRM($row['certificadoAlistamentoMilitarRM']);
            $aluno->setCertificadoAlistamentoMilitarCSM($row['certificadoAlistamentoMilitarCSM']);
            $aluno->setCertificadoReservistaNumero($row['certificadoReservistaNumero']);
            $aluno->setCertificadoReservistaSerie($row['certificadoReservistaSerie']);
            $aluno->setCertificadoReservistaData($row['certificadoReservistaData']);
            $aluno->setCertificadoReservistaCAT($row['certificadoReservistaCAT']);
            $aluno->setCertificadoReservistaRM($row['certificadoReservistaRM']);
            $aluno->setCertificadoReservistaCSM($row['certificadoReservistaCSM']);

            return $aluno;
        }

        /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return AlunoMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>