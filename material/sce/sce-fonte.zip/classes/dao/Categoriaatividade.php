<?php
    require_once("../includes/comum.php");
    require_once("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela categoriaatividade
     * @author: Luiz Gilberto
     * @name: categoriaatividade.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class CategoriaatividadeMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return CategoriaatividadeMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM categoriaatividade WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM categoriaatividade';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM categoriaatividade ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param categoriaatividade chave prim�ria
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM categoriaatividade WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param CategoriaatividadeMySql categoriaatividade
         */
        public function insert($categoriaatividade)
        {
            $sql = 'INSERT INTO categoriaatividade (nome) VALUES (?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($categoriaatividade->getNome());

            $id = $this->executeInsert($sqlQuery);
            $categoriaatividade->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param CategoriaatividadeMySql categoriaatividade
         */
        public function update($categoriaatividade)
        {
            $sql = 'UPDATE categoriaatividade SET nome = ? WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($categoriaatividade->getNome());

            $sqlQuery->setNumber($categoriaatividade->getid());
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE categoriaatividade';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return CategoriaatividadeMySql
         */
        protected function readRow($row)
        {
            $categoriaatividade = new Categoriaatividade();

            $categoriaatividade->setid($row['id']);
            $categoriaatividade->setNome($row['nome']);

            return $categoriaatividade;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return CategoriaatividadeMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>