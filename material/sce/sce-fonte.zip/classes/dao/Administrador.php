<?php
    require_once("../includes/comum.php");
    require_once ("$BASE_DIR/sce/includes/require_administrador.php");

    /**
     * Classe que opera na tabela administrador
     * @author: Luiz Gilberto
     * @name: administrador.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class AdministradorMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return AdministradorMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM sce.administrador WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }
        
        /**
         * Checa se uma pessoa � administrador
         *
         * @param int $id chave prim�ria
         * @return boolean
         */
        public function isAdm($id)
        {
            return $this->load($id)->getIdPessoa() != null ? true : false;
        }
        
        public function toggleAdm($id)
        {
            $bolAdm = $this->isAdm($id);
            if (!$bolAdm)
            {
	    	$administrador = new Administrador();
	    	$administrador->setIdPessoa($id);
                return $this->insert($administrador);
	    }
	    else
	    {
		return $this->deleteByIdPessoa($id);
	    }
        }
        
        /**
         * Insere registro na tabela
         *
         * @param AdministradorMySql administrador
         */
        public function insert($administrador)
        {
            $sql = 'INSERT INTO administrador (idPessoa) VALUES (?)';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($administrador->getIdPessoa());

            $id = $this->executeInsert($sqlQuery);
            return $id;
        }
        
        /**
         * Deleta o registro por um idPessoa
         * @param int $value
         */
        public function deleteByidPessoa($value)
        {
            $sql = 'DELETE FROM administrador WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return AdministradorMySql
         */
        protected function readRow($row)
        {
            $administrador = new Administrador();

            $administrador->setIdPessoa($row['idPessoa']);

            return $administrador;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return PessoaMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>