<?php
    require_once("../includes/comum.php");
    require_once("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela tema
     * @author: Luiz Gilberto
     * @name: tema.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class TemaMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return TemaMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM Tema WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($id);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM Tema';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna de ordena��o
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM Tema ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param Tema chave prim�ria
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM Tema WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param TemaMySql Tema
         */
        public function insert($Tema)
        {
            $sql = 'INSERT INTO Tema (nome) VALUES (?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($Tema->getnome());

            $id = $this->executeInsert($sqlQuery);
            $Tema->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param TemaMySql Tema
         */
        public function update($Tema)
        {
            $sql = 'UPDATE Tema SET nome = ? WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($Tema->getnome());

            $sqlQuery->setNumber($Tema->getid());
            return $this->executeUpdate($sqlQuery);
        }


        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE Tema';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return TemaMySql
         */
        protected function readRow($row)
        {
            $Tema = new Tema();

            $Tema->setid($row['id']);
            $Tema->setnome($row['nome']);

            return $Tema;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return TemaMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>