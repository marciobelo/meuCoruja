<?php
    require_once("../includes/comum.php");
    require_once ("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela pessoa
     * @author: Luiz Gilberto
     * @name: pessoa.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class PessoaMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return PessoaMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM Pessoa WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }
        
        /**
         * Retorna a contagem de todos os registros
         *
         * @return int
         */
        public function count()
        {
            $sql = 'SELECT COUNT(*) FROM Pessoa';
            $sqlQuery = new SqlQuery($sql);
            return $this->execute($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM Pessoa';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM Pessoa ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }
        
	/**
	 * Retorna todos os registros paginados
	 *
	 * @param int $page - p�gina a ser exibida
	 * @param int $tot - total de registros a serem exibidos
	 */
        public function queryAllByPage($page, $tot)
        {
            $infLimit = ($page*$tot) - $tot;
            $sql = 'SELECT * FROM Pessoa LIMIT ' . $infLimit . ', ' . $tot;
            $sqlQuery = new SqlQuery($sql);

            return $this->getList($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return PessoaMySql
         */
        protected function readRow($row)
        {
            $pessoa = new Pessoa();

            $pessoa->setIdPessoa($row['idPessoa']);
            $pessoa->setNome($row['nome']);
            $pessoa->setSexo($row['sexo']);
            $pessoa->setEnderecoLogradouro($row['enderecoLogradouro']);
            $pessoa->setEnderecoNumero($row['enderecoNumero']);
            $pessoa->setEnderecoComplemento($row['enderecoComplemento']);
            $pessoa->setEnderecoBairro($row['enderecoBairro']);
            $pessoa->setEnderecoMunicipio($row['enderecoMunicipio']);
            $pessoa->setEnderecoEstado($row['enderecoEstado']);
            $pessoa->setEnderecoCEP($row['enderecoCEP']);
            $pessoa->setDataNascimento($row['dataNascimento']);
            $pessoa->setNacionalidade($row['nacionalidade']);
            $pessoa->setNaturalidade($row['naturalidade']);
            $pessoa->setTelefoneResidencial($row['telefoneResidencial']);
            $pessoa->setTelefoneComercial($row['telefoneComercial']);
            $pessoa->setTelefoneCelular($row['telefoneCelular']);
            $pessoa->setEmail($row['email']);

            return $pessoa;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return PessoaMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>