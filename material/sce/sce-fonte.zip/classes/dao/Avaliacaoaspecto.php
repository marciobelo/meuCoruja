<?php
    require_once("../includes/comum.php");
    require_once ("$BASE_DIR/sce/includes/require_mysqldao.php");


    /**
     * Classe que opera na tabela avaliacaoaspecto
     * @author: Luiz Gilberto
     * @name: avaliacaoaspecto.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class AvaliacaoaspectoMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return AvaliacaoaspectoMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM avaliacaoaspecto WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM avaliacaoaspecto';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM avaliacaoaspecto ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param avaliacaoaspecto chave prim�ria
         */
        public function delete($id)
        {
            $sql = 'DELETE FROM avaliacaoaspecto WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param AvaliacaoaspectoMySql avaliacaoaspecto
         */
        public function insert($avaliacaoaspecto)
        {
            $sql = 'INSERT INTO avaliacaoaspecto (idAspecto, idAvaliacao, resposta) VALUES (?, ?, ?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($avaliacaoaspecto->getIdAspecto());
            $sqlQuery->set($avaliacaoaspecto->getIdAvaliacao());
            $sqlQuery->set($avaliacaoaspecto->getResposta());

            $id = $this->executeInsert($sqlQuery);
            $avaliacaoaspecto->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param AvaliacaoaspectoMySql avaliacaoaspecto
         */
        public function update($avaliacaoaspecto)
        {
            $sql = 'UPDATE avaliacaoaspecto SET idAspecto = ?, idAvaliacao = ?, resposta = ? WHERE id = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($avaliacaoaspecto->getIdAspecto());
            $sqlQuery->set($avaliacaoaspecto->getIdAvaliacao());
            $sqlQuery->set($avaliacaoaspecto->getResposta());

            $sqlQuery->setNumber($avaliacaoaspecto->getid());
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Deleta todos os registros
         */
        public function clean()
        {
            $sql = 'TRUNCATE TABLE avaliacaoaspecto';
            $sqlQuery = new SqlQuery($sql);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Query por aspecto
         ** @param string $value
         */
        public function queryByIdAspecto($value)
        {
            $sql = 'SELECT * FROM avaliacaoaspecto WHERE idAspecto = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        /**
         * Query por avalia��o
         ** @param string $value
         */
        public function queryByIdAvaliacao($value)
        {
            $sql = 'SELECT * FROM avaliacaoaspecto WHERE idAvaliacao = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            return $this->getList($sqlQuery);
        }

        /**
         * Query por aspecto e avalia��o
         ** @param string $value
         */
        public function queryByIdAspectoIdAvaliacao($value, $value2)
        {
            $sql = 'SELECT * FROM avaliacaoaspecto WHERE idAspecto = ? AND idAvaliacao = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->set($value);
            $sqlQuery->set($value2);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return AvaliacaoaspectoMySql
         */
        protected function readRow($row)
        {
            $avaliacaoaspecto = new Avaliacaoaspecto();

            $avaliacaoaspecto->setid($row['id']);
            $avaliacaoaspecto->setIdAspecto($row['idAspecto']);
            $avaliacaoaspecto->setIdAvaliacao($row['idAvaliacao']);
            $avaliacaoaspecto->setResposta($row['resposta']);

            return $avaliacaoaspecto;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return AvaliacaoaspectoMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         * @param string $sqlQuery
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>