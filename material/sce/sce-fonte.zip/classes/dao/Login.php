<?php
    require_once("../includes/comum.php");
    require_once("$BASE_DIR/sce/includes/require_mysqldao.php");

    /**
     * Classe que opera na tabela login
     * @author: Luiz Gilberto
     * @name: login.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class LoginMySqlDAO
    {

        /**
         * Retorna um determinado model pela chave prim�ria
         *
         * @param int $id chave prim�ria
         * @return LoginMySql
         */
        public function load($id)
        {
            $sql = 'SELECT * FROM Login WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($id);
            return $this->getRow($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela
         */
        public function queryAll()
        {
            $sql = 'SELECT * FROM Login';
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Retorna todos os registros da tabela ordenados por um determinado campo
         *
         * @param string $orderColumn nome da coluna
         */
        public function queryAllOrderBy($orderColumn)
        {
            $sql = 'SELECT * FROM Login ORDER BY '.$orderColumn;
            $sqlQuery = new SqlQuery($sql);
            return $this->getList($sqlQuery);
        }

        /**
         * Deleta registro do id determinado da tabela
         * @param login chave prim�ria
         */
        public function delete($idPessoa)
        {
            $sql = 'DELETE FROM Login WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);
            $sqlQuery->setNumber($idPessoa);
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         *
         * @param LoginMySql login
         */
        public function insert($login)
        {
            $sql = 'INSERT INTO Login (nomeAcesso, senha, foto) VALUES (?, ?, ?)';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($login->getNomeAcesso());
            $sqlQuery->set($login->getSenha());
            $sqlQuery->set($login->getFoto());

            $id = $this->executeInsert($sqlQuery);
            $login->setid($id);
            return $id;
        }

        /**
         * Atualiza registro de um determinado id na tabela
         *
         * @param LoginMySql login
         */
        public function update($login)
        {
            $sql = 'UPDATE Login SET nomeAcesso = ?, senha = ?, foto = ? WHERE idPessoa = ?';
            $sqlQuery = new SqlQuery($sql);

            $sqlQuery->set($login->getNomeAcesso());
            $sqlQuery->set($login->getSenha());
            $sqlQuery->set($login->getFoto());

            $sqlQuery->setNumber($login->getIdPessoa());
            return $this->executeUpdate($sqlQuery);
        }

        /**
         * Retorna um objeto com os dados de um registro
         *
         * @return LoginMySql
         */
        protected function readRow($row)
        {
            $login = new Login();

            $login->setIdPessoa($row['idPessoa']);
            $login->setNomeAcesso($row['nomeAcesso']);
            $login->setSenha($row['senha']);
            $login->setFoto($row['foto']);

            return $login;
        }

         /**
         * Retorna uma lista de registros como resultado de uma query
         * @param string $sqlQuery
         */
        protected function getList($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            $ret = array();
            for($i=0;$i<count($tab);$i++)
            {
                $ret[$i] = $this->readRow($tab[$i]);
            }
            return $ret;
        }

        /**
         * Retorna um objeto model como resultado de uma query
         *
         * @return LoginMySql
         */
        protected function getRow($sqlQuery)
        {
            $tab = QueryExecutor::execute($sqlQuery);
            return $this->readRow($tab[0]);
        }

        /**
         * Executa query SQL
         */
        protected function execute($sqlQuery)
        {
            return QueryExecutor::execute($sqlQuery);
        }


        /**
         * Executa query SQL
         */
        protected function executeUpdate($sqlQuery)
        {
            return QueryExecutor::executeUpdate($sqlQuery);
        }

        /**
         * Insere registro na tabela
         */
        protected function executeInsert($sqlQuery)
        {
            return QueryExecutor::executeInsert($sqlQuery);
        }
    }
?>