<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela matriculaaluno
     * @author: Luiz Gilberto
     * @name: matriculaaluno.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class MatriculaAluno
    {

        private $matriculaAluno;
        private $idPessoa;
        private $dataMatricula;
        private $siglaCurso;
        private $idMatriz;
        private $idPeriodoLetivo;
        private $turnoIngresso;
        private $concursoPontos;
        private $concursoClassificacao;
        private $situacaoMatricula;
        private $idFormaIngresso;

        public function MatriculaAluno ()
        {
        }

        public function setMatriculaAluno($matriculaAluno)
        {
            $this->matriculaAluno = $matriculaAluno;
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }

        public function setDataMatricula($dataMatricula)
        {
            $this->dataMatricula = $dataMatricula;
        }

        public function setSiglaCurso($siglaCurso)
        {
            $this->siglaCurso = $siglaCurso;
        }

        public function setIdMatriz($idMatriz)
        {
            $this->idMatriz = $idMatriz;
        }

        public function setIdPeriodoLetivo($idPeriodoLetivo)
        {
            $this->idPeriodoLetivo = $idPeriodoLetivo;
        }

        public function setTurnoIngresso($turnoIngresso)
        {
            $this->turnoIngresso = $turnoIngresso;
        }

        public function setConcursoPontos($concursoPontos)
        {
            $this->concursoPontos = $concursoPontos;
        }

        public function setConcursoClassificacao($concursoClassificacao)
        {
            $this->concursoClassificacao = $concursoClassificacao;
        }

        public function setSituacaoMatricula($situacaoMatricula)
        {
            $this->situacaoMatricula = $situacaoMatricula;
        }

        public function setIdFormaIngresso($idFormaIngresso)
        {
            $this->idFormaIngresso = $idFormaIngresso;
        }

        public function getMatriculaAluno ()
        {
            return $this->matriculaAluno;
        }

        public function getIdPessoa ()
        {
            return $this->idPessoa;
        }

        public function getDataMatricula()
        {
            return $this->dataMatricula;
        }

        public function getSiglaCurso()
        {
            return $this->siglaCurso;
        }

        public function getIdMatriz()
        {
            return $this->idMatriz;
        }

        public function getIdPeriodoLetivo()
        {
            return $this->idPeriodoLetivo;
        }

        public function getTurnoIngresso()
        {
            return $this->turnoIngresso;
        }

        public function getConcursoPontos()
        {
            return $this->concursoPontos;
        }

        public function getConcursoClassificacao()
        {
            return $this->concursoClassificacao;
        }

        public function getSituacaoMatricula()
        {
            return $this->situacaoMatricula;
        }

        public function getIdFormaIngresso()
        {
            return $this->idFormaIngresso;
        }

    }
?>