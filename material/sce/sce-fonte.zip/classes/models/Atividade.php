<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela atividade
     * @author: Luiz Gilberto
     * @name: atividade.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Atividade
    {

        private $id;

        private $nome;

        private $data;

        private $horaInicial;

        private $horaFinal;

        private $horaExtensao;

        private $idCategoriaAtividade;

        private $idEvento;

        private $idPalestrante;

        private $idEspaco;

        private $tipoPalestrante;

        private $customEspaco;

        private $bloqueado;

        public function Atividade ()
        {
        }

        public function setId ($id)
        {
            $this->id = $id;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function setData($data)
        {
            $this->data = $data;
        }

        public function setHoraInicial($horaInicial)
        {
            $this->horaInicial = $horaInicial;
        }

        public function setHoraFinal($horaFinal)
        {
            $this->horaFinal = $horaFinal;
        }

        public function sethoraExtensao ($horaExtensao)
        {
            $this->horaExtensao = $horaExtensao;
        }

        public function setIdCategoriaAtividade ($idCategoriaAtividade)
        {
            $this->idCategoriaAtividade = $idCategoriaAtividade;
        }

        public function setIdEvento ($idEvento)
        {
            $this->idEvento = $idEvento;
        }

        public function setIdPalestrante ($idPalestrante)
        {
            $this->idPalestrante = $idPalestrante;
        }

        public function setIdEspaco ($idEspaco)
        {
            $this->idEspaco = $idEspaco;
        }

        public function setTipoPalestrante($tipoPalestrante)
        {
            $this->tipoPalestrante = $tipoPalestrante;
        }

        public function setCustomEspaco($customEspaco)
        {
            $this->customEspaco = $customEspaco;
        }

        public function setBloqueado($bloqueado)
        {
            $this->bloqueado = $bloqueado;
        }

        public function getId()
        {
            return $this->id;
        }

        public function getData ()
        {
            return $this->data;
        }

        public function getHoraInicial ()
        {
            return $this->horaInicial;
        }

        public function getHoraFinal ()
        {
            return $this->horaFinal;
        }

        public function getNome()
        {
            return $this->nome;
        }

        public function getHoraExtensao ()
        {
            return $this->horaExtensao;
        }
        public function getIdCategoriaAtividade ()
        {
            return $this->idCategoriaAtividade;
        }

        public function getIdEvento ()
        {
            return $this->idEvento;
        }

        public function getIdPalestrante ()
        {
            return $this->idPalestrante;
        }

        public function getIdEspaco ()
        {
            return $this->idEspaco;
        }

        public function getTipoPalestrante ()
        {
            return $this->tipoPalestrante;
        }

        public function getCustomEspaco ()
        {
            return $this->customEspaco;
        }

        public function getBloqueado ()
        {
            return $this->bloqueado;
        }
    }
?>