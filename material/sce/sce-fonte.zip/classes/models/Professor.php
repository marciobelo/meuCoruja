<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela professor
     * @author: Luiz Gilberto
     * @name: professor.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Professor
    {

        private $idPessoa;

        private $titulacaoAcademica;

        private $cvLattes;

        public function Professor()
        {
        }

        public function getIdPessoa()
        {
            return $this->idPessoa;
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }

        public function getTitulacaoAcademica()
        {
            return $this->titulacaoAcademica;
        }

        public function setTitulacaoAcademica($titulacaoAcademica)
        {
            $this->titulacaoAcademica = $titulacaoAcademica;
        }

        public function getCvLattes()
        {
            return $this->cvLattes;
        }

        public function setCvLattes($cvLattes)
        {
            $this->cvLattes = $cvLattes;
        }

    }
?>