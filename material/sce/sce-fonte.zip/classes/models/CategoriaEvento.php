<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela categoriaevento
     * @author: Luiz Gilberto
     * @name: categoriaevento.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class CategoriaEvento
    {

        private $id;

        private $nome;

        public function CategoriaEvento ()
        {
        }

        public function setid($id)
        {
            $this->id = $id;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function getid ()
        {
            return $this->id;
        }

        public function getNome ()
        {
            return $this->nome;
        }
    }
?>