<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela espaco
     * @author: Luiz Gilberto
     * @name: espaco.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Espaco
    {

        private $idEspaco;

        private $nome;

        private $capacidade;

        public function Espaco ()
        {
        }

        public function setIdEspaco($idEspaco)
        {
            $this->idEspaco = $idEspaco;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function setCapacidade($capacidade)
        {
            $this-> capacidade = $capacidade;
        }

        public function getIdEspaco ()
        {
            return $this->idEspaco;
        }

        public function getNome ()
        {
            return $this->nome;
        }

        public function getCapacidade()
        {
            return $this->capacidade;
        }
    }
?>