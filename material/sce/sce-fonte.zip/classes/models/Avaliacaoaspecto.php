<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela avaliacaoaspecto
     * @author: Luiz Gilberto
     * @name: avaliacaoaspecto.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Avaliacaoaspecto
    {

        private $id;

        private $idAspecto;

        private $idAvaliacao;

        private $resposta;

        public function AvaliacaoAspecto ()
        {
        }

        public function getid()
        {
            return $this->id;
        }

        public function setid($id)
        {
            $this->id = $id;
        }

        public function getIdAspecto()
        {
            return $this->idAspecto;
        }

        public function setIdAspecto($idAspecto)
        {
            $this->idAspecto = $idAspecto;
        }

        public function getIdAvaliacao()
        {
            return $this->idAvaliacao;
        }

        public function setIdAvaliacao($idAvaliacao)
        {
            $this->idAvaliacao = $idAvaliacao;
        }

        public function getResposta()
        {
            return $this->resposta;
        }

        public function setResposta($resposta)
        {
            $this->resposta = $resposta;
        }
    }
?>