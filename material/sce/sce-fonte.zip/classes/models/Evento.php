<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela evento
     * @author: Luiz Gilberto
     * @name: evento.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Evento
    {

        private $id;

        private $nome;

        private $dtInicial;

        private $dtFinal;

        private $idCategoriaEvento;

        private $idTema;

        private $idPessoa;

        public function Evento()
        {
        }
        public function getid()
        {
            return $this->id;
        }

        public function setid($id)
        {
            $this->id = $id;
        }

        public function getNome()
        {
            return $this->nome;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function getDtInicial()
        {
            return $this->dtInicial;
        }

        public function setDtInicial($dtInicial)
        {
            $this->dtInicial = $dtInicial;
        }

        public function getDtFinal()
        {
            return $this->dtFinal;
        }

        public function setDtFinal($dtFinal)
        {
            $this->dtFinal = $dtFinal;
        }

        public function getidCategoriaEvento()
        {
            return $this->idCategoriaEvento;
        }

        public function setidCategoriaEvento($idCategoriaEvento)
        {
            $this->idCategoriaEvento = $idCategoriaEvento;
        }

        public function getidTema()
        {
            return $this->idTema;
        }

        public function setidTema($idTema)
        {
            $this->idTema = $idTema;
        }

        public function getIdPessoa()
        {
            return $this->idPessoa;
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }
    }
?>