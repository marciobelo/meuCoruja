<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela aspecto
     * @author: Luiz Gilberto
     * @name: aspecto.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Aspecto
    {

        private $id;

        private $nome;

        public function Aspecto ()
        {
        }

        public function setid($id)
        {
            $this->id = $id;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function getid ()
        {
            return $this->id;
        }

        public function getNome ()
        {
            return $this->nome;
        }
    }
?>