<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela login
     * @author: Luiz Gilberto
     * @name: login.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Login {

    private $idPessoa;

    private $nomeAcesso;

    private $senha;

    private $foto;

    public setIdPessoa ( $idPessoa ) {
    this->idPessoa = $idPessoa;
    }

    public setNomeAcesso ( $nomeAcesso ) {
    this->nomeAcesso = $nomeAcesso;
    }

    public setSenha ( $senha ) {
    this->senha = $senha;
    }

    public setFoto ( $foto ) {
    this->foto = $foto;
    }

    public getIdPessoa () {
    return $idPessoa;
    }

    public getNomeAcesso () {
    return $nomeAcesso;
    }

    public getSenha () {
    return $senha;
    }

    public getFoto () {
    return $foto;
    }
    }
?>