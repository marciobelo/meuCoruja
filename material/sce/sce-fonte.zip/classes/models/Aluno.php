<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela aluno
     * @author: Luiz Gilberto
     * @name: aluno.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Aluno
    {

        private $idPessoa;

        private $nomeMae;

        private $rgMae;

        private $nomePai;

        private $rgPai;

        private $rgNumero;

        private $rgDataEmissao;

        private $rgOrgaoEmissor;

        private $cpf;

        private $cpfProprio;

        private $certidaoNascimentoNumero;

        private $certidaoNascimentoLivro;

        private $certidaoNascimentoFolha;

        private $certidaoNascimentoCidade;

        private $certidaoNascimentoSubdistrito;

        private $certidaoNascimentoUF;

        private $certidaoCasamentoNumero;

        private $certidaoCasamentoLivro;

        private $certidaoCasamentoFolha;

        private $certidaoCasamentoCidade;

        private $certidaoCasamentoSubdistrito;

        private $certidaoCasamentoUF;

        private $estabCursoOrigem;

        private $estabCursoOrigemUF;

        private $cursoOrigemAnoConclusao;

        private $modalidadeCursoOrigem;

        private $ctps;

        private $corRaca;

        private $estadoCivil;

        private $deficienciaVisual;

        private $deficienciaMotora;

        private $deficienciaAuditiva;

        private $deficienciaMental;

        private $responsavelLegal;

        private $rgResponsavel;

        private $tituloEleitorNumero;

        private $tituloEleitorData;

        private $tituloEleitorZona;

        private $tituloEleitorSecao;

        private $certificadoAlistamentoMilitarNumero;

        private $certificadoAlistamentoMilitarSerie;

        private $certificadoAlistamentoMilitarData;

        private $certificadoAlistamentoMilitarRM;

        private $certificadoAlistamentoMilitarCSM;

        private $certificadoReservistaNumero;

        private $certificadoReservistaSerie;

        private $certificadoReservistaData;

        private $certificadoReservistaCAT;

        private $certificadoReservistaRM;

        private $certificadoReservistaCSM;

        public function Aluno()
        {
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }

        public function setNomeMae($nomeMae)
        {
            $this->nomeMae = $nomeMae;
        }

        public function setRgMae($rgMae)
        {
            $this->rgMae = $rgMae;
        }

        public function setNomePai($nomePai)
        {
            $this->nomePai = $nomePai;
        }

        public function setRgPai($rgPai)
        {
            $this->rgPai = $rgPai;
        }

        public function setRgNumero($rgNumero)
        {
            $this->rgNumero = $rgNumero;
        }

        public function setRgDataEmissao($rgDataEmissao)
        {
            $this->rgDataEmissao = $rgDataEmissao;
        }

        public function setRgOrgaoEmissor($rgOrgaoEmissor)
        {
            $this->rgOrgaoEmissor = $rgOrgaoEmissor;
        }

        public function setCpf($cpf)
        {
            $this->cpf = $cpf;
        }

        public function setCpfProprio($cpfProprio)
        {
            $this->cpfProprio = $cpfProprio;
        }

        public function setCertidaoNascimentoNumero($certidaoNascimentoNumero)
        {
            $this->certidaoNascimentoNumero = $certidaoNascimentoNumero;
        }

        public function setCertidaoNascimentoLivro($certidaoNascimentoLivro)
        {
            $this->certidaoNascimentoLivro = $certidaoNascimentoLivro;
        }

        public function setCertidaoNascimentoFolha($certidaoNascimentoFolha)
        {
            $this->certidaoNascimentoFolha = $certidaoNascimentoFolha;
        }

        public function setCertidaoNascimentoCidade($certidaoNascimentoCidade)
        {
            $this->certidaoNascimentoCidade = $certidaoNascimentoCidade;
        }

        public function setCertidaoNascimentoSubdistrito($certidaoNascimentoSubdistrito)
        {
            $this->certidaoNascimentoSubdistrito = $certidaoNascimentoSubdistrito;
        }

        public function setCertidaoNascimentoUF($certidaoNascimentoUF)
        {
            $this->certidaoNascimentoUF = $certidaoNascimentoUF;
        }

        public function setCertidaoCasamentoNumero($certidaoCasamentoNumero)
        {
            $this->certidaoCasamentoNumero = $certidaoCasamentoNumero;
        }

        public function setCertidaoCasamentoLivro($certidaoCasamentoLivro)
        {
            $this->certidaoCasamentoLivro = $certidaoCasamentoLivro;
        }

        public function setCertidaoCasamentoFolha($certidaoCasamentoFolha)
        {
            $this->certidaoCasamentoFolha = $certidaoCasamentoFolha;
        }

        public function setCertidaoCasamentoCidade($certidaoCasamentoCidade)
        {
            $this->certidaoCasamentoCidade = $certidaoCasamentoCidade;
        }

        public function setCertidaoCasamentoSubdistrito($certidaoCasamentoSubdistrito)
        {
            $this->certidaoCasamentoSubdistrito  = $certidaoCasamentoSubdistrito;
        }

        public function setCertidaoCasamentoUF($certidaoCasamentoUF)
        {
            $this->certidaoCasamentoUF = $certidaoCasamentoUF;
        }

        public function setEstabCursoOrigem($estabCursoOrigem)
        {
            $this->estabCursoOrigem = $estabCursoOrigem;
        }

        public function setEstabCursoOrigemUF($estabCursoOrigemUF)
        {
            $this->estabCursoOrigemUF = $estabCursoOrigemUF;
        }

        public function setCursoOrigemAnoConclusao($cursoOrigemAnoConclusao)
        {
            $this->cursoOrigemAnoConclusao = $cursoOrigemAnoConclusao;
        }

        public function setModalidadeCursoOrigem($modalidadeCursoOrigem)
        {
            $this->modalidadeCursoOrigem = $modalidadeCursoOrigem;
        }

        public function setCtps($ctps)
        {
            $this->ctps = $ctps;
        }

        public function setCorRaca($corRaca)
        {
            $this->corRaca = $corRaca;
        }

        public function setEstadoCivil($estadoCivil)
        {
            $this->estadoCivil = $estadoCivil;
        }

        public function setDeficienciaVisual($deficienciaVisual)
        {
            $this->deficienciaVisual = $deficienciaVisual;
        }

        public function setDeficienciaMotora($deficienciaMotora)
        {
            $this->deficienciaMotora = $deficienciaMotora;
        }

        public function setDeficienciaAuditiva($deficienciaAuditiva)
        {
            $this->deficienciaAuditiva = $deficienciaAuditiva;
        }

        public function setDeficienciaMental($deficienciaMental)
        {
            $this->deficienciaMental = $deficienciaMental;
        }

        public function setResponsavelLegal($responsavelLegal)
        {
            $this->responsavelLegal  = $responsavelLegal;
        }

        public function setRgResponsavel($rgResponsavel)
        {
            $this->rgResponsavel = $rgResponsavel;
        }

        public function setTituloEleitorNumero($tituloEleitorNumero)
        {
            $this->tituloEleitorNumero = $tituloEleitorNumero;
        }

        public function settituloEleitorData($tituloEleitorData)
        {
            $this->tituloEleitorData = $tituloEleitorData;
        }

        public function settituloEleitorZona($tituloEleitorZona)
        {
            $this->tituloEleitorZona = $tituloEleitorZona;
        }

        public function settituloEleitorSecao($tituloEleitorSecao)
        {
            $this->tituloEleitorSecao = $tituloEleitorSecao;
        }

        public function setcertificadoAlistamentoMilitarNumero($certificadoAlistamentoMilitarNumero)
        {
            $this->certificadoAlistamentoMilitarNumero = $certificadoAlistamentoMilitarNumero;
        }

        public function setcertificadoAlistamentoMilitarSerie($certificadoAlistamentoMilitarSerie)
        {
            $this->certificadoAlistamentoMilitarSerie = $certificadoAlistamentoMilitarSerie;
        }

        public function setcertificadoAlistamentoMilitarData($certificadoAlistamentoMilitarData)
        {
            $this->certificadoAlistamentoMilitarData  = $certificadoAlistamentoMilitarData;
        }

        public function setcertificadoAlistamentoMilitarRM($certificadoAlistamentoMilitarRM)
        {
            $this->certificadoAlistamentoMilitarRM = $certificadoAlistamentoMilitarRM;
        }

        public function setcertificadoAlistamentoMilitarCSM($certificadoAlistamentoMilitarCSM)
        {
            $this->certificadoAlistamentoMilitarCSM = $certificadoAlistamentoMilitarCSM;
        }

        public function setcertificadoReservistaNumero($certificadoReservistaNumero)
        {
            $this->certificadoReservistaNumero = $certificadoReservistaNumero;
        }

        public function setcertificadoReservistaSerie($certificadoReservistaSerie)
        {
            $this->certificadoReservistaSerie = $certificadoReservistaSerie;
        }

        public function setcertificadoReservistaData($certificadoReservistaData)
        {
            $this->certificadoReservistaData = $certificadoReservistaData;
        }

        public function setcertificadoReservistaCAT($certificadoReservistaCAT)
        {
            $this->certificadoReservistaCAT = $certificadoReservistaCAT;
        }

        public function setcertificadoReservistaRM($certificadoReservistaRM)
        {
            $this->certificadoReservistaRM = $certificadoReservistaRM;
        }

        public function setcertificadoReservistaCSM($certificadoReservistaCSM)
        {
            $this->certificadoReservistaCSM = $certificadoReservistaCSM;
        }

        public function getIdPessoa()
        {
            return $this->idPessoa;
        }

        public function getnomeMae()
        {
            return $this->nomeMae;
        }

        public function getRgMae()
        {
            return $this->rgMae;
        }

        public function getnomePai()
        {
            return $this->nomePai;
        }

        public function getRgPai()
        {
            return $this->rgPai;
        }

        public function getrgNumero()
        {
            return $this->rgNumero;
        }

        public function getrgDataEmissao()
        {
            return $this->rgDataEmissao;
        }

        public function getrgOrgaoEmissor()
        {
            return $this->rgOrgaoEmissor;
        }

        public function getcpf()
        {
            return $this->cpf;
        }

        public function getcpfProprio()
        {
            return $this->cpfProprio;
        }

        public function getcertidaoNascimentoNumero()
        {
            return $this->certidaoNascimentoNumero;
        }

        public function getcertidaoNascimentoLivro()
        {
            return $this->certidaoNascimentoLivro;
        }

        public function getcertidaoNascimentoFolha()
        {
            return $this->certidaoNascimentoFolha;
        }

        public function getcertidaoNascimentoCidade()
        {
            return $this->certidaoNascimentoCidade;
        }

        public function getcertidaoNascimentoSubdistrito()
        {
            return $this->certidaoNascimentoSubdistrito;
        }

        public function getcertidaoNascimentoUF()
        {
            return $this->certidaoNascimentoUF;
        }

        public function getcertidaoCasamentoNumero()
        {
            return $this->certidaoCasamentoNumero;
        }

        public function getcertidaoCasamentoLivro()
        {
            return $this->certidaoCasamentoLivro;
        }

        public function getcertidaoCasamentoFolha()
        {
            return $this->certidaoCasamentoFolha;
        }

        public function getcertidaoCasamentoCidade()
        {
            return $this->certidaoCasamentoCidade;
        }

        public function getcertidaoCasamentoSubdistrito()
        {
            return $this->certidaoCasamentoSubdistrito;
        }

        public function getcertidaoCasamentoUF()
        {
            return $this->certidaoCasamentoUF;
        }

        public function getestabCursoOrigem()
        {
            return $this->estabCursoOrigem;
        }

        public function getestabCursoOrigemUF()
        {
            return $this->estabCursoOrigemUF;
        }

        public function getcursoOrigemAnoConclusao()
        {
            return $this->cursoOrigemAnoConclusao;
        }

        public function getmodalidadeCursoOrigem()
        {
            return $this->modalidadeCursoOrigem;
        }

        public function getctps()
        {
            return $this->ctps;
        }

        public function getcorRaca()
        {
            return $this->corRaca;
        }

        public function getestadoCivil()
        {
            return $this->estadoCivil;
        }

        public function getdeficienciaVisual()
        {
            return $this->deficienciaVisual;
        }

        public function getdeficienciaMotora()
        {
            return $this->deficienciaMotora;
        }

        public function getdeficienciaAuditiva()
        {
            return $this->deficienciaAuditiva;
        }

        public function getdeficienciaMental()
        {
            return $this->deficienciaMental;
        }

        public function getresponsavelLegal()
        {
            return $this->responsavelLegal;
        }

        public function getrgResponsavel()
        {
            return $this->rgResponsavel;
        }

        public function gettituloEleitorNumero()
        {
            return $this->tituloEleitorNumero;
        }

        public function gettituloEleitorData()
        {
            return $this->tituloEleitorData;
        }

        public function gettituloEleitorZona()
        {
            return $this->tituloEleitorZona;
        }

        public function gettituloEleitorSecao()
        {
            return $this->tituloEleitorSecao;
        }

        public function getcertificadoAlistamentoMilitarNumero()
        {
            return $this->certificadoAlistamentoMilitarNumero;
        }

        public function getcertificadoAlistamentoMilitarSerie()
        {
            return $this->certificadoAlistamentoMilitarSerie;
        }

        public function getcertificadoAlistamentoMilitarData()
        {
            return $this->certificadoAlistamentoMilitarData;
        }

        public function getcertificadoAlistamentoMilitarRM()
        {
            return $this->certificadoAlistamentoMilitarRM;
        }

        public function getcertificadoAlistamentoMilitarCSM()
        {
            return $this->certificadoAlistamentoMilitarCSM;
        }

        public function getcertificadoReservistaNumero()
        {
            return $this->certificadoReservistaNumero;
        }

        public function getcertificadoReservistaSerie()
        {
            return $this->certificadoReservistaSerie;
        }

        public function getcertificadoReservistaData()
        {
            return $this->certificadoReservistaData;
        }

        public function getcertificadoReservistaCAT()
        {
            return $this->certificadoReservistaCAT;
        }

        public function getcertificadoReservistaRM()
        {
            return $this->certificadoReservistaRM;
        }

        public function getcertificadoReservistaCSM()
        {
            return $this->certificadoReservistaCSM;
        }

    }
?>