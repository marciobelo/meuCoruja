<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela matriculaprofessor
     * @author: Luiz Gilberto
     * @name: matriculaprofessor.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class MatriculaProfessor
    {

        private $matriculaProfessor;
        private $idPessoa;
        private $cargaHoraria;
        private $dataInicio;
        private $dataEncerramento;

        public function MatriculaProfessor ()
        {
        }

        public function setMatriculaProfessor($matriculaProfessor)
        {
            $this->matriculaProfessor = $matriculaProfessor;
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }

        public function setCargaHoraria($cargaHoraria)
        {
            $this->cargaHoraria = $cargaHoraria;
        }

        public function setDataInicio($dataInicio)
        {
            $this->dataInicio = $dataInicio;
        }

        public function setDataEncerramento($dataEncerramento)
        {
            $this->dataEncerramento = $dataEncerramento;
        }

        public function getMatriculaProfessor ()
        {
            return $this->matriculaProfessor;
        }

        public function getIdPessoa ()
        {
            return $this->idPessoa;
        }

        public function getCargaHoraria()
        {
            return $this->cargaHoraria;
        }

        public function getDataInicio()
        {
            return $this->dataInicio;
        }

        public function getDataEncerramento()
        {
            return $this->dataEncerramento;
        }
    }
?>