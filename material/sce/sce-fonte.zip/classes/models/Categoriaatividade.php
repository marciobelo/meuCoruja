<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela categoriaatividade
     * @author: Luiz Gilberto
     * @name: categoriaatividade.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Categoriaatividade
    {

        private $id;

        private $nome;

        public function CategoriaAtividade ()
        {
        }

        public function getid()
        {
            return $this->id;
        }

        public function setid($id)
        {
            $this->id = $id;
        }

        public function getNome()
        {
            return $this->nome;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }
    }
?>