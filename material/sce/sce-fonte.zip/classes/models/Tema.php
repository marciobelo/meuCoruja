<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela tema
     * @author: Luiz Gilberto
     * @name: tema.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Tema
    {

        private $id;

        private $nome;

        public function Tema ()
        {
        }

        public function setid($id)
        {
            $this->id = $id;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function getid ()
        {
            return $this->id;
        }

        public function getNome ()
        {
            return $this->nome;
        }
    }
?>