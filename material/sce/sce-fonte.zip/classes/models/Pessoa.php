<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela pessoa
     * @author: Luiz Gilberto
     * @name: pessoa.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Pessoa
    {

        private $idPessoa;

        private $nome;

        private $sexo;

        private $enderecoLogradouro;

        private $enderecoNumero;

        private $enderecoComplemento;

        private $enderecoBairro;

        private $enderecoMunicipio;

        private $enderecoEstado;

        private $enderecoCEP;

        private $dataNascimento;

        private $nacionalidade;

        private $naturalidade;

        private $telefoneResidencial;

        private $telefoneComercial;

        private $telefoneCelular;

        private $email;

        public function Pessoa()
        {
        }

        public function getIdPessoa()
        {
            return $this->idPessoa;
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }

        public function getNome()
        {
            return $this->nome;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function getSexo()
        {
            return $this->sexo;
        }

        public function setSexo($sexo)
        {
            $this->sexo = $sexo;
        }

        public function getEnderecoLogradouro()
        {
            return $this->enderecoLogradouro;
        }

        public function setEnderecoLogradouro($enderecoLogradouro)
        {
            $this->enderecoLogradouro = $enderecoLogradouro;
        }

        public function getEnderecoNumero()
        {
            return $this->enderecoNumero;
        }

        public function setEnderecoNumero($enderecoNumero)
        {
            $this->enderecoNumero = $enderecoNumero;
        }

        public function getEnderecoComplemento()
        {
            return $this->enderecoComplemento;
        }

        public function setEnderecoComplemento($enderecoComplemento)
        {
            $this->enderecoComplemento = $enderecoComplemento;
        }

        public function getEnderecoBairro()
        {
            return $this->EnderecoBairro;
        }

        public function setEnderecoBairro($enderecoBairro)
        {
            $this->enderecoBairro = $enderecoBairro;
        }

        public function getEnderecoMunicipio()
        {
            return $this->enderecoMunicipio;
        }

        public function setEnderecoMunicipio($enderecoMunicipio)
        {
            $this->enderecoMunicipio = $enderecoMunicipio;
        }

        public function getEnderecoEstado()
        {
            return $this->enderecoEstado;
        }

        public function setEnderecoEstado($enderecoEstado)
        {
            $this->enderecoEstado = $enderecoEstado;
        }

        public function getEnderecoCEP()
        {
            return $this->enderecoCEP;
        }

        public function setEnderecoCEP($enderecoCEP)
        {
            $this->enderecoCEP = $enderecoCEP;
        }

        public function getDataNascimento()
        {
            return $this->dataNascimento;
        }

        public function setDataNascimento($dataNascimento)
        {
            $this->dataNascimento = $dataNascimento;
        }

        public function getNacionalidade()
        {
            return $this->nacionalidade;
        }

        public function setNacionalidade($nacionalidade)
        {
            $this->nacionalidade = $nacionalidade;
        }

        public function getNaturalidade()
        {
            return $this->naturalidade;
        }

        public function setNaturalidade($naturalidade)
        {
            $this->naturalidade = $naturalidade;
        }

        public function getTelefoneResidencial()
        {
            return $this->telefoneResidencial;
        }

        public function setTelefoneResidencial($telefoneResidencial)
        {
            $this->telefoneResidencial = $telefoneResidencial;
        }

        public function getTelefoneComercial()
        {
            return $this->telefoneComercial;
        }

        public function setTelefoneComercial($telefoneComercial)
        {
            $this->telefoneComercial = $telefoneComercial;
        }

        public function getTelefoneCelular()
        {
            return $this->telefoneCelular;
        }

        public function setTelefoneCelular($telefoneCelular)
        {
            $this->telefoneCelular = $telefoneCelular;
        }

        public function setEmail($email)
        {
            $this->email = $email;
        }

        public function getEmail()
        {
            return $this->email;
        }
    }
?>