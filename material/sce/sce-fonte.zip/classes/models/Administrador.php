<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela administrador
     * @author: Luiz Gilberto
     * @name: administrador.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Administrador
    {

        private $idPessoa;

        public function Pessoa()
        {
        }

        public function getIdPessoa()
        {
            return $this->idPessoa;
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }
		
    }
?>