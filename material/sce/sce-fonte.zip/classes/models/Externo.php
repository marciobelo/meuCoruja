<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela externo
     * @author: Luiz Gilberto
     * @name: externo.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Externo
    {

        private $id;

        private $instituicao;

        private $telefone;

        private $email;

        public function Externo ()
        {
        }

        public function setId ($id)
        {
            $this->id = $id;
        }

        public function setNome($nome)
        {
            $this->nome = $nome;
        }

        public function setInstituicao($instituicao)
        {
            $this->instituicao = $instituicao;
        }

        public function setTelefone($telefone)
        {
            $this->telefone = $telefone;
        }

        public function setEmail($email)
        {
            $this->email = $email;
        }

        public function getId()
        {
            return $this->id;
        }

        public function getNome ()
        {
            return $this->nome;
        }

        public function getInstituicao ()
        {
            return $this->instituicao;
        }

        public function getTelefone ()
        {
            return $this->telefone;
        }

        public function getEmail()
        {
            return $this->email;
        }
    }
?>