<?php
    require_once("../includes/comum.php");
    /**
     * Objeto representa a tabela avaliacao
     * @author: Luiz Gilberto
     * @name: avaliacao.php
     * @version: 1.0
     * @since: vers�o 1.0
     */
    class Avaliacao
    {

        private $id;

        private $sugestao;

        private $sugestaoEvento;

        private $status;

        private $idPessoa;

        private $idAtividade;

        public function Avaliacao ()
        {
        }

        public function getid()
        {
            return $this->id;
        }

        public function setid($id)
        {
            $this->id = $id;
        }

        public function getSugestao()
        {
            return $this->sugestao;
        }

        public function setSugestao($sugestao)
        {
            $this->sugestao = $sugestao;
        }

        public function getSugestaoEvento()
        {
            return $this->sugestaoEvento;
        }

        public function setSugestaoEvento($sugestaoEvento)
        {
            $this->sugestaoEvento = $sugestaoEvento;
        }

        public function getStatus()
        {
            return $this->status;
        }

        public function setStatus($status)
        {
            $this->status = $status;
        }

        public function getIdPessoa()
        {
            return $this->idPessoa;
        }

        public function setIdPessoa($idPessoa)
        {
            $this->idPessoa = $idPessoa;
        }

        public function getIdAtividade()
        {
            return $this->idAtividade;
        }

        public function setIdAtividade($idAtividade)
        {
            $this->idAtividade = $idAtividade;
        }
    }
?>