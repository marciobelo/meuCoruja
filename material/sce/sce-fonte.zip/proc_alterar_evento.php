<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_evento.php");

    $Evento = new Evento();
    $EventoMySqlDAO = new EventoMySqlDAO();
    $Evento = $EventoMySqlDAO->load($_POST["id"]);
    if (!$_POST["nome"] || !$_POST["dtInicial"] || !$_POST["dtFinal"])
    {
        $_SESSION["erro"] = "Preencha os dados requeridos";
        $id = $_POST["id"];
        header("Location: alterar_evento.php?id=$id");
        break;
    }
    else
    {
        $Evento->setNome( $_POST["nome"] );
        $Evento->setDtInicial( date("Y-m-d", strtotime($_POST["dtInicial"])) );
        $Evento->setDtFinal( date("Y-m-d", strtotime($_POST["dtFinal"])) );
        $Evento->setIdTema( $_POST["tema"] );
        $Evento->setIdCategoriaEvento($_POST["categoria"]);
        $Evento->setIdPessoa( $_POST["coordenador"] );
        $Evento = $EventoMySqlDAO->update( $Evento );
    }

    $_SESSION["sucesso"] = "Cadastro efetuado com sucesso!";
    header("Location: manter_evento.php?pag=1");
?>
