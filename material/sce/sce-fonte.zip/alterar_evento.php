<?php
    require_once ("../includes/comum.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador") {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_evento.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once($BASE_DIR . "/sce/includes/require_professor.php");
    require_once($BASE_DIR . "/sce/includes/require_tema.php");
    require_once($BASE_DIR . "/sce/includes/require_categoriaevento.php");

    $PessoaMySqlDAO = new PessoaMySqlDao;
    $TemaMySqlDAO = new TemaMySqlDao;
    $temas = $TemaMySqlDAO->queryAll();
    $CategoriaEventoMySqlDAO = new CategoriaEventoMySqlDao;
    $categorias = $CategoriaEventoMySqlDAO->queryAll();
    $coordenadores = $PessoaMySqlDAO->queryAll();
    $palestrantes = $PessoaMySqlDAO->queryAll();

    $EventoMySqlDAO = new EventoMySqlDao;
    $evento = $EventoMySqlDAO->load($_GET["id"]);
    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <h4>Altera��o do evento <?php echo $evento->getNome(); ?></h4>
            <form action="proc_alterar_evento.php" method="post" name="alteracao_evento">
                <input name="id" type="hidden" value=<?php echo $_GET["id"]; ?> />
                <input name="dtInicial" type="hidden" value=<?php echo $evento->getDtInicial(); ?> />
                <input name="dtFinal" type="hidden" value=<?php echo $evento->getDtFinal(); ?> />
                Nome: * <input type="text" name="nome" value=<?php echo '"' . $evento->getNome() . '"' ?> />
                Datas: <?php echo date("d/m/Y",strtotime($evento->getDtInicial())) . " - "
                                  . date("d/m/Y",strtotime($evento->getDtFinal())) ?>
                <br />
                <br />
                Tema:
                <select name="tema">
                    <?php
                        echo "<option value='NULL'>----</option>";
                        foreach ($temas as $tema) {
                            if ($evento->getIdTema()!=$tema->getId()) {
                                echo "<option value=" . $tema->getId(). ">" . $tema->getNome() . "</option>";
                            } else {
                                echo '<option selected="selected" value=' . $tema->getId(). ">" . $tema->getNome()
                                     . "</option>";
                            }
                        }
                    ?>
                </select>
                Categoria:
                <select name="categoria">
                    <?php
                        foreach ($categorias as $categoria) {
                            if ($evento->getIdCategoriaEvento()!=$categoria->getId()) {
                                echo "<option value=" . $categoria->getId(). ">" . $categoria->getNome() . "</option>";
                            } else {
                                echo '<option selected="selected"  value=' . $categoria->getId() . ">"
                                     . $categoria->getNome() . "</option>";
                            }
                        }
                    ?>
                </select>
					Coordenador:
                <select name="coordenador">
                    <?php
                        foreach ($coordenadores as $coordenador) {
                            if ($evento->getIdPessoa()!=$coordenador->getIdPessoa()) {
                                echo "<option value=" . $coordenador->getIdPessoa(). ">" . $coordenador->getNome()
                                     . "</option>";
                            } else {
                                echo '<option selected="selected" value=' . $coordenador->getIdPessoa() . ">"
                                     . $coordenador->getNome() . "</option>";
                            }
                        }
                    ?>
                </select>
                <input type='submit' value='Cadastrar' name='submit' />
        <input type="button" value="Voltar" onclick="window.location='manter_evento.php?pag=1'" />
            </form>
<?php
    include($BASE_DIR . "/sce/includes/legenda.html");
?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>
