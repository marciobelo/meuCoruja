<?php
    require_once ("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }

    require_once($BASE_DIR . "/sce/includes/require_categoriaevento.php");
    require_once($BASE_DIR . "/sce/includes/require_evento.php");
    
    $CategoriaEventoMySqlDAO = new CategoriaEventoMySqlDao;
    $categoriasevento = $CategoriaEventoMySqlDAO->queryAll();
    
    $EventoMySqlDAO = new EventoMySqlDao;

    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
?>
        <div id="mainContent">
            <h4>Categorias de evento</h4>
            <?php
                if($categoriasevento)
                {
    ?>
            <table>
                <tr>
                    <th>Nome</th>
                    <th>Alterar</th>
                    <th>Excluir</th>
                </tr>
<?php
    foreach ($categoriasevento as $categoriaevento)
    {
        echo "<tr>";
        echo "<td>" . $categoriaevento->getNome() . "</td>";
        $id = $categoriaevento->getId();
        echo "<td> <a href='alterar_categoriaevento.php?id=$id'>Clique</a> </td>";
        $deletavel = $EventoMySqlDAO->queryByIdCategoriaEvento($id);
        if (!empty($deletavel))
        {
            echo "<td> <a href='excluir_categoriaevento.php?id=$id' "
                 . "onclick='return confirm(\"Deseja realmente excluir a categoria? Os eventos vinculados tamb�m ser�o "
                 . "exclu�dos.\")'>Clique</a> </td>";
        }
        else
        {
            echo "<td> <a href='excluir_categoriaevento.php?id=$id' "
                 . "onclick='return confirm(\"Deseja realmente excluir a categoria?\")'>Clique</a> </td>";
        }
        echo "</tr>";
    }
        echo "</table>";
        echo "<br>";
    }
    else
    {
        echo "N�o h� categorias cadastradas! Cadastre uma categoria usando o formul�rio abaixo.";
    }
?>
                <form action="proc_cadastrar_categoria_evento.php" method="post" name="cadastro_categoria_evento">
                    Nome: (*) <input name="nome" type="text" />
                    <input type="submit" value="Cadastrar" name="enviar" />
                    <input type='button' value='Voltar' onclick='window.location="index.php"' />
                </form>
<?php
            include($BASE_DIR . "/sce/includes/legenda.html");
        ?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>