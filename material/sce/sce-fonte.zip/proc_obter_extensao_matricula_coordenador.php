﻿<?php
    require_once ("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once($BASE_DIR . "/sce/includes/require_matriculaaluno.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once($BASE_DIR . "/sce/includes/require_evento.php");
    require_once($BASE_DIR . "/sce/includes/require_tema.php");
    require_once($BASE_DIR . "/sce/includes/require_categoriaevento.php");

    if (!$_GET["matricula"])
    {
        $_SESSION["erro"] = "Preencha a matr�cula";
        header("Location: obter_extensao.php");
        break;
    }
    else
    {
        $MatriculaAlunoMySqlDAO = new MatriculaAlunoMySqlDAO();
        $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
        $AtividadeMySqlDAO = new AtividadeMySqlDAO();
        $EventoMySqlDAO = new EventoMySqlDAO();
        $CategoriaEventoMySqlDAO = new CategoriaEventoMySqlDAO();
        $TemaMySqlDAO = new TemaMySqlDAO();
        $matriculaAluno = $MatriculaAlunoMySqlDAO->load($_GET["matricula"]);
        if (!$matriculaAluno->getIdPessoa())
        {
            $_SESSION["erro"] = "Matrícula não encontrada";
            header("Location: obter_extensao.php");
        }
        $avaliacoes = $AvaliacaoMySqlDAO->queryByIdPessoa($matriculaAluno->getIdPessoa());
        $eventos = array();
        foreach ($avaliacoes as $avaliacao)
        {
            if ($avaliacao->getStatus())
            {
                $atividade = $AtividadeMySqlDAO->load($avaliacao->getIdAtividade());
                if (!in_array($atividade->getIdEvento(), $eventos))
                {
                    $eventos[] = $atividade->getIdEvento();
                }
                $horas[$atividade->getIdEvento()] += $atividade->getHoraExtensao();
            }
        }
        $PessoaMySqlDAO = new PessoaMySqlDAO();
        $pessoa =  $PessoaMySqlDAO->load($matriculaAluno->getIdPessoa());
        $nomePessoa = $pessoa->getNome();
        $idAluno = $matriculaAluno->getIdPessoa();
    }
    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
    include($BASE_DIR . "/sce/includes/menu.html");
            ?>
        <div id="mainContent">
            <?php
                if (count($eventos) > 0)
                {
                    echo "<h3>Lista de hora de extens�o por evento</h3>";
                    echo "<table class='tabDados'>";
                    echo "<tr>";
                    echo "<th>Evento</th>";
                    echo "<th>Horas de extens�o</th>";
                    echo "<th>Datas</th>";
                    echo "<th>Tema</th>";
                    echo "<th>Coordenador</th>";
                    echo "<th>PDF</th>";
                    echo "</tr>";
                    foreach ($eventos as $evento) 
                    {
                        $objEvento = $EventoMySqlDAO->load($evento);
                        $nomeEvento = $objEvento->getNome();
                        echo "<tr>";
                        echo "<td><a href='obter_extensao_evento.php?id=$evento&aluno=$idAluno'>$nomeEvento</a></td>";
                        echo "<td>$horas[$evento]</td>";
                        echo "<td>" . date("d/m/Y",strtotime($objEvento->getDtInicial())) . " - "
                        . date("d/m/Y",strtotime($objEvento->getDtFinal())) . "</td>";
                        $tema = $TemaMySqlDAO->load($objEvento->getIdTema());
                        if ($tema->getNome() == NULL) {
                            $tema->setNome('----');
                        }
                        echo "<td>" . $tema->getNome() . "</td>";
                        $pessoa = $PessoaMySqlDAO->load($objEvento->getIdPessoa());
                        echo "<td>" . $pessoa->getNome() . "</td>";
                        echo "<td><a href='gerar_pdf_evento.php?id=$evento&aluno=$idAluno' target='_blank'>Gerar</a></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                    echo "<br /><br />";
                }
                else
                {
                    echo "O aluno $nomePessoa n�o possui horas de extens�o";
                }
                echo "<input type='button' value='Voltar'"
                         . "onclick='window.location=\"obter_extensao.php\"' />";
            ?>
        </div>
        <br class="clearfloat" />
        <div id="footer">
            <p>&nbsp;</p>
        </div>
    </div>
</body>
</html>
