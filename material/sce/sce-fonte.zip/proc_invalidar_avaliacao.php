<?php
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once ($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");

    $PessoaMySqlDAO = new PessoaMySqlDAO();
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO();
    $AtividadeMySqlDAO = new AtividadeMySqlDAO();
    $avaliacao = $AvaliacaoMySqlDAO->load($_GET["id"]);
    $avaliacao->setStatus('0');
    $AvaliacaoMySqlDAO->update($avaliacao);
    if ($avaliacao == 0)
    {
        trigger_error(mysql_error(), E_USER_ERROR);
    } else
    {
        $_SESSION["sucesso"] = "Invalida��o bem-sucedida";
        $id = $avaliacao->getIdAtividade();
        header("Location: validar_avaliacao.php?id=$id");
    }
?>
