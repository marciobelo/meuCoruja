<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    require_once($BASE_DIR . "/sce/includes/require_evento.php");
    require_once($BASE_DIR . "/sce/includes/require_pessoa.php");
    require_once($BASE_DIR . "/sce/includes/require_professor.php");
    require_once($BASE_DIR . "/sce/includes/require_tema.php");
    require_once($BASE_DIR . "/sce/includes/require_categoriaevento.php");

    $tot = 10;

    $PessoaMySqlDAO = new PessoaMySqlDao;
    $TemaMySqlDAO = new TemaMySqlDao;
    $temas = $TemaMySqlDAO->queryAll();
    $CategoriaEventoMySqlDAO = new CategoriaEventoMySqlDao;
    $categorias = $CategoriaEventoMySqlDAO->queryAll();
    $EventoMySqlDAO = new EventoMySqlDao;
    $eventos = $EventoMySqlDAO->queryAllOrderByPage("dtInicial DESC", (int)$_GET["pag"], $tot);
    $count = $EventoMySqlDAO->count();
    $count = $count[0][0];
    $PessoaMySqlDAO = new PessoaMySqlDao;
    $coordenadores = $PessoaMySqlDAO->queryAll();
    $palestrantes = $PessoaMySqlDAO->queryAll();
?>
<head>
    <meta http-equiv="Content-Type" content="text/html" />
    <title>Sistema de Controle de Eventos do IST-Rio</title>
    <link rel="stylesheet" href="estilos/sceist.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/jscal2.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/border-radius.css" />
    <link rel="stylesheet" type="text/css" href="./javascript/jscal2/css/steel/steel.css" />
    <script type="text/javascript" src="./javascript/jscal2/js/jscal2.js"></script>
    <script type="text/javascript" src="./javascript/jscal2/js/lang/pt.js"></script>
</head>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                if ($eventos)
                {
                ?>
            <h4>Lista de eventos cadastrados</h4>
                <?php
                    if ($_GET["pag"] != 1)
                    {
                        $ant = $_GET["pag"]-1;
                        echo "<a href='manter_evento.php?pag=1' ><< </a>";
                        echo "<a href='manter_evento.php?pag=$ant' >< </a>";
                    }
                    $ultima = floor($count / $tot);

                    if ($ultima != 0 && $_GET["pag"] != $ultima)
                    {
                        $prox = $_GET["pag"]+1;
                        echo "<a href='manter_evento.php?pag=$ultima' style='float:right; padding-right: 10px;'> "
                             . "&nbsp; >></a>";
                        echo "<a href='manter_evento.php?pag=$prox' style='float:right;'> > </a>";
                    }
                ?>
            <table class="tabDados">
                <tr>
                    <th>Nome</th>
                    <th>Datas</th>
                    <th>Categoria</th>
                    <th>Tema</th>
                    <th>Coordenador</th>
                        <?php
                            if ($permissao == "coordenador")
                            {
                            ?>
                    <th>Alterar</th>
                    <th>Excluir</th>
                            <?php
                            }
                        ?>
                    <th>Atividades</th>
                </tr>
                    <?php
                        foreach ($eventos as $evento)
                        {
                            echo "<tr>";
                            echo "<td>" . $evento->getNome() . "</td>";
                            echo "<td>" . date("d/m/Y",strtotime($evento->getDtInicial())) . " - "
                            . date("d/m/Y",strtotime($evento->getDtFinal())) . "</td>";
                            $categoria = $CategoriaEventoMySqlDAO->load($evento->getIdCategoriaEvento());
                            echo "<td>" . $categoria->getNome() . "</td>";
                            $tema = $TemaMySqlDAO->load($evento->getIdTema());
                            if ($tema->getNome() == NULL) {
                                $tema->setNome('----');
                            }
                            echo "<td>" . $tema->getNome() . "</td>";
                            $pessoa = $PessoaMySqlDAO->load($evento->getIdPessoa());
                            echo "<td>" . $pessoa->getNome() . "</td>";
                            $id = $evento->getId();
                            if ($permissao == "coordenador")
                            {
                                echo "<td> <a href='alterar_evento.php?id=$id'>Clique</a> </td>";
                                echo "<td> <a href='excluir_evento.php?id=$id' "
                                     . "onclick='return confirm(\"Deseja realmente excluir o evento? As atividades e"
                                     . "avalia��es vinculadas tamb�m ser�o excluidas.\")'>Clique</a> </td>";
                            }
                            echo "<td> <a href='detalhe_evento.php?id=$id&pag=1'>Clique</a> </td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    }
                    else
                    {
                        echo "N�o h� eventos cadastrados! Cadastre um evento usando o formul�rio abaixo.";
                    }
                ?>
                <?php
                    if ($permissao == "coordenador")
                    {
                    ?>
                <h4>Formul�rio de cadastro de evento</h4>
                <form action="proc_cadastrar_evento.php" method="POST">
                    Nome: (*) <input type="text" name="nome" value=<?php echo '"' . $_SESSION["eventoSession"]["nome"]
                                                                              . '"' ?> />
                    Data inicial: (*) <input type="text" name="dtInicial" maxlength="10" size="10" id="dtInicial" readonly
                                             value=<?php echo '"' . $_SESSION["eventoSession"]["dtInicial"] . '"' ?>  />
                    <img src="./includes/imagens/calendario1.png" alt="dataInicial" id="dtInBt" />
                    <script type="text/javascript">
                        Calendar.setup({
                            trigger: "dtInBt",
                            inputField: "dtInicial",
                            onSelect: function() { this.hide() },
                            bottomBar: false,
                            fdow: 0,
                            dateFormat: "%d/%m/%Y"
                        });
                    </script>
                    Data final: (*) <input type="text" name="dtFinal" maxlength="10" size="10" id="dtFinal" readonly
                                           value=<?php echo '"' . $_SESSION["eventoSession"]["dtFinal"] . '"' ?> />
                    <img src="./includes/imagens/calendario1.png" alt="dataFinal" id="dtFimBt" />
                    <script type="text/javascript">
                        Calendar.setup({
                            trigger: "dtFimBt",
                            inputField: "dtFinal",
                            onSelect: function() { this.hide() },
                            bottomBar: false,
                            fdow: 0,
                            dateFormat: "%d/%m/%Y"
                        });
                    </script>
                    <br />
                    <br />
                    Tema:
                    <select name="tema">
                            <?php
                                echo "<option value='NULL'>----</option>";
                                foreach ($temas as $tema)
                                {
                                    if ($_SESSION["eventoSession"]["tema"] != $tema->getId())
                                    {
                                        echo "<option value=" . $tema->getId(). ">" . $tema->getNome() . "</option>";
                                    }
                                    else
                                    {
                                        echo "<option value=" . $tema->getId() . " selected='selected' >"
                                             . $tema->getNome() . "</option>";
                                    }
                                }
                            ?>
                    </select>
                    Categoria:
                    <select name="categoria">
                        <?php
                            foreach ($categorias as $categoria)
                            {
                                if ($_SESSION["eventoSession"]["categoria"] != $categoria->getId())
                                {
                                    echo "<option value=" . $categoria->getId(). ">" . $categoria->getNome()
                                         . "</option>";
                                }
                                else
                                {
                                    echo "<option value=" . $categoria->getId() . " selected='selected' >"
                                         . $categoria->getNome() . "</option>";
                                }
                            }
                        ?>
                    </select>
                    <br />
                    <br />
                    Coordenador:
                    <select name="coordenador">
                        <?php
                            foreach ($coordenadores as $coordenador)
                            {
                                if ($_SESSION["eventoSession"]["coordenador"] != $coordenador->getIdPessoa())
                                {
                                    echo "<option value=" . $coordenador->getIdPessoa(). ">" . $coordenador->getNome()
                                         . "</option>";
                                }
                                else
                                {
                                    echo "<option value=" . $coordenador->getIdPessoa() . "selected='selected' >"
                                         . $coordenador->getNome() . "</option>";
                                }
                            }
                        ?>
                    </select>
					<br />
					<br />
                    <input type='submit' value='Cadastrar' name='submit'
                           onclick='return confirm("Deseja confirmar a inclus�o?");'/>
                    <input type='button' value='Voltar' onclick='window.location="index.php"' />
                </form>
                    <?php
                    }
                ?>
                <br />
                <?php
                    if ($permissao == "coordenador")
                    {
                        include($BASE_DIR . "/sce/includes/legenda.html");
                    }
                ?>
        </div>
        <?php
            include($BASE_DIR . "/sce/includes/footer.html");
            unset($_SESSION["eventoSession"]);
        ?>
</body>
</html>