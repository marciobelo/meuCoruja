<?php
    require_once("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once($BASE_DIR . "/sce/includes/require_atividade.php");
    require_once($BASE_DIR . "/sce/includes/require_evento.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacao.php");
    require_once($BASE_DIR . "/sce/includes/require_aspecto.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");
    require_once ("./includes/permissao.php");

    $idAtividade = $_GET["id"];

    $AtividadeMySqlDAO = new AtividadeMySqlDAO;
    $EventoMySqlDAO = new EventoMySqlDAO;
    $AvaliacaoMySqlDAO = new AvaliacaoMySqlDAO;
    $AspectoMySqlDAO = new AspectoMySqlDAO;
    $AvaliacaoAspectoMySqlDAO = new AvaliacaoaspectoMySqlDAO;

    $atividade = $AtividadeMySqlDAO->load($idAtividade);
    $idEvento = $atividade->getIdEvento();
    $evento = $EventoMySqlDAO->load($idEvento);
    $avaliacoes = $AvaliacaoMySqlDAO->queryByIdAtividadeValidada($idAtividade);

    $aspectos = array();
    $cond = false;

    foreach ($avaliacoes as $avaliacao)
    {
        $avaliacoesaspecto = $AvaliacaoAspectoMySqlDAO->queryByIdAvaliacao($avaliacao->getId());
        foreach ($avaliacoesaspecto as $avaliacaoaspecto)
        {
            foreach ($aspectos as $aspecto) {
                if ($aspecto->getId() == $avaliacaoaspecto->getIdAspecto()) {
                    $cond = true;
                }
            }
            if (!$cond) {
                $aspectos[] = $AspectoMySqlDAO->load($avaliacaoaspecto->getIdAspecto());
            } else {
                $cond = false;
            }
        }
    }

    foreach ($avaliacoes as $avaliacao)
    {
        foreach ($aspectos as $aspecto)
        {
            $avaliacaoaspecto = $AvaliacaoAspectoMySqlDAO->queryByIdAspectoIdAvaliacao($aspecto->getId(),
                                                                                       $avaliacao->getId());
            if ($avaliacaoaspecto->getResposta() != NULL)
            {
                $avaliacaoResposta[$aspecto->getId()]['count'] = 0;
                if ($avaliacaoResposta[$aspecto->getId()][$avaliacaoaspecto->getResposta()] != 1)
                {
                    $avaliacaoResposta[$aspecto->getId()][$avaliacaoaspecto->getResposta()] = 1;
                }
                else
                {
                    $numero = $avaliacaoResposta[$aspecto->getId()][$avaliacaoaspecto->getResposta()];
                    $avaliacaoResposta[$aspecto->getId()][$avaliacaoaspecto->getResposta()] = $numero+1;
                }
            }
        }
    }

    foreach ($aspectos as $aspecto)
    {
        $avRes = $avaliacaoResposta[$aspecto->getId()];
        $avaliacaoResposta[$aspecto->getId()]['count'] = $avRes[0] + $avRes[1] + $avRes[2] + $avRes[3] + $avRes[4];
        if ($avRes[0])
        {
            $avaliacaoResposta[$aspecto->getId()][0] = $avRes[0]/$avaliacaoResposta[$aspecto->getId()]['count'] * 100;
        }
        else
        {
            $avaliacaoResposta[$aspecto->getId()][0] = 0;
        }
        if ($avRes[1])
        {
            $avaliacaoResposta[$aspecto->getId()][1] = $avRes[1]/$avaliacaoResposta[$aspecto->getId()]['count'] * 100;
        }
        else
        {
            $avaliacaoResposta[$aspecto->getId()][1] = 0;
        }
        if ($avRes[2])
        {
            $avaliacaoResposta[$aspecto->getId()][2] = $avRes[2]/$avaliacaoResposta[$aspecto->getId()]['count'] * 100;
        }
        else
        {
            $avaliacaoResposta[$aspecto->getId()][2] = 0;
        }
        if ($avRes[3])
        {
            $avaliacaoResposta[$aspecto->getId()][3] = $avRes[3]/$avaliacaoResposta[$aspecto->getId()]['count'] * 100;
        }
        else
        {
            $avaliacaoResposta[$aspecto->getId()][3] = 0;
        }
        if ($avRes[4])
        {
            $avaliacaoResposta[$aspecto->getId()][4] = $avRes[4]/$avaliacaoResposta[$aspecto->getId()]['count'] * 100;
        }
        else
        {
            $avaliacaoResposta[$aspecto->getId()][4] = 0;
        }
    }

    $nomeAtividade = $atividade->getNome();
    $nomeEvento = $evento->getNome();

    include ($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
        ?>
        <div id="mainContent">
            <?php
                $horaInicial = $atividade->getHoraInicial();
                $horaFinal = $atividade->getHoraFinal();
                $data = date("d-m-Y", strtotime($atividade->getData()));
            ?>
            <h4>Evento: <?php echo $nomeEvento ?></h4>
            <h4>Atividade: <?php echo $nomeAtividade ?></h4>
            <b>Data:</b> <?php echo $data ?>
            <b>&nbsp;&nbsp;Hora:</b> <?php echo "$horaInicial - $horaFinal" ?>
            <br />
            <br />
            <?php
				if ((is_array($aspectos)) && count($aspectos) > 0)
				{
					foreach ($aspectos as $aspecto)
					{
						echo "<b>" . $aspecto->getNome() . ": </b>";
						echo "<br />";
						for ($i = 0; $i < 5; $i++)
						{
							echo "<br />";
							if ($i == 0)
							{
								echo "Péssimo: ";
							}
							elseif ($i == 1)
							{
								echo "Ruim: ";
							}
							elseif ($i == 2)
							{
								echo "Regular: ";
							}
							elseif ($i == 3)
							{
								echo "Bom: ";
							}
							elseif ($i == 4)
							{
								echo "Ótimo: ";
							}
							echo round($avaliacaoResposta[$aspecto->getId()][$i], 2) . "%";
						}
						echo "<br />";
						echo "<br />";
					}
				}
				else
				{
					echo "Não há estatísticas.";
				}
            ?>

            <br />
            <br />
<?php
    echo "<input type='button' value='Voltar' "
         . "onclick='window.location=\"atividade_estatistica.php?id=$idEvento&pag=1\"' />";
?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>