<?php
    require_once ("../includes/comum.php");
    require_once($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }

    require_once($BASE_DIR . "/sce/includes/require_aspecto.php");
    require_once($BASE_DIR . "/sce/includes/require_avaliacaoaspecto.php");
    
    $AspectoMySqlDAO = new AspectoMySqlDao;
    $aspectos = $AspectoMySqlDAO->queryAll();
    
    $AvaliacaoAspectoMySqlDAO = new AvaliacaoAspectoMySqlDao;

    include($BASE_DIR . "/sce/includes/header.html");
?>
<body class="twoColFixLtHdr">
    <div id="container">
        <?php
            include($BASE_DIR . "/sce/includes/menu.html");
            include($BASE_DIR . "/sce/includes/mensagem.php");
?>
        <div id="mainContent">
            <h4>Aspectos</h4>
            <?php
                if($aspectos)
                {
    ?>
            <table>
                <tr>
                    <th>Nome</th>
                    <th>Alterar</th>
                    <th>Excluir</th>
                </tr>
<?php
    foreach ($aspectos as $aspecto)
    {
        echo "<tr>";
        echo "<td>" . $aspecto->getNome() . "</td>";
        $id = $aspecto->getId();
        echo "<td> <a href='alterar_aspecto.php?id=$id'>Clique</a> </td>";
        $deletavel = $AvaliacaoAspectoMySqlDAO->queryByIdAspecto($id);
        if (!empty($deletavel))
        {
            echo "<td> <a href='excluir_aspecto.php?id=$id' onclick='return confirm(\"Deseja realmente excluir o aspecto? As avalia��es vinculadas tamb�m ser�o exclu�das.\")'>Clique</a> </td>";
        }
        else
        {
            echo "<td> <a href='excluir_aspecto.php?id=$id' onclick='return confirm(\"Deseja realmente excluir o aspecto?\")'>Clique</a> </td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    echo "<br>";
}
else
{
    echo "N�o h� aspectos cadastradas! Cadastre um aspecto usando o formul�rio abaixo.";
}
?>
                <form action="proc_cadastrar_aspecto.php" method="post" name="cadastro_categoria_aspecto">
                    Nome: (*) <input name="nome" type="text" />
                    <input type="submit" value="Cadastrar" name="enviar" />
                    <input type="button" value="Voltar" onclick="window.location='index.php'" />
                </form>
<?php
            include($BASE_DIR . "/sce/includes/legenda.html");
        ?>
        </div>
<?php
    include($BASE_DIR . "/sce/includes/footer.html");
?>
</body>
</html>