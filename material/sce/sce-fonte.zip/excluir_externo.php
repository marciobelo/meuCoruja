<?php
    require_once ("../includes/comum.php");
    require_once ($BASE_DIR . "/sce/includes/sql/ConnectionFactory.class.php");
    require_once ("./includes/permissao.php");
    if ($permissao != "coordenador")
    {
        $_SESSION["erro"] = "Acesso negado.";
        header ("Location: index.php");
        break;
    }
    require_once ($BASE_DIR . "/sce/includes/require_externo.php");
    require_once ($BASE_DIR . "/sce/includes/require_atividade.php");

    $id = $_GET["id"];
    $ExternoMySqlDAO = new ExternoMySqlDao;
    $AtividadeMySqlDAO = new AtividadeMySqlDao;
    $atividades = $AtividadeMySqlDAO->queryAll($id);
    $externoEvento = false;
    foreach ($atividades as $atividade)
    {
        if ($atividade->getTipoPalestrante() == "E")
        {
            if ($atividade->getIdPalestrante() == $id)
            {
                $nomeAtividade = $atividade->getNome();
                $_SESSION["erro"] = "O externo est� vinculado � atividade $nomeAtividade";
                $externoEvento = true;
            }
        }
    }
    
    if ($externoEvento == false)
    {
        $Externo = $ExternoMySqlDAO->delete($id);
        
        if ($Externo == 0)
        {
            trigger_error(mysql_error(), E_USER_ERROR);
        }
        else
        {
            $_SESSION["sucesso"] = "Externo exclu�do com sucesso!";
            header("Location: manter_externos.php?pag=1");
        }
    }
    else
    {
        header("Location: manter_externos.php?pag=1");
    }
?>